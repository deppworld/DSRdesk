// npm run backup  → writes a full backup to BACKUP_DIR (works whether or not the app is running)
const db = require('../server/db/pool');
const { runBackup } = require('../server/services/backup');
(async () => {
  try {
    await db.connect();
    const f = await runBackup();
    console.log('Backup written:', f);
  } catch (e) { console.error('Backup failed:', e.message); process.exitCode = 1; }
  finally { await db.close(); }
})();
