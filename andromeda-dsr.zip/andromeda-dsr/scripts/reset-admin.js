// npm run reset-admin  → sets a new temporary password for the "admin" account (or: npm run reset-admin -- <username>)
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const db = require('../server/db/pool');
(async () => {
  const username = process.argv[2] || 'admin';
  try {
    await db.connect();
    const pw = 'Reset' + crypto.randomBytes(4).toString('hex') + '#7';
    const r = await db.one(
      `UPDATE users SET password_hash=$2, must_change_password=TRUE, failed_attempts=0, locked_until=NULL, is_active=TRUE,
         token_version=token_version+1 WHERE lower(username)=lower($1) RETURNING username, role`, [username, await bcrypt.hash(pw, 12)]);
    if (!r) console.log(`No user called "${username}".`);
    else console.log(`\nUser: ${r.username} (${r.role})\nTemporary password: ${pw}\nSign in and set a new password.\n`);
  } catch (e) { console.error('Failed:', e.message); process.exitCode = 1; }
  finally { await db.close(); }
})();
