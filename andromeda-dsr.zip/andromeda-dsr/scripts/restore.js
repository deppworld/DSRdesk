// npm run restore -- backups/dsr-backup-XXXX.json.gz
// REPLACES all current data with the backup. Stop the app first.
const path = require('path');
const readline = require('readline');
const db = require('../server/db/pool');
const { restore } = require('../server/services/backup');
const { migrate } = require('../server/db/migrate');
(async () => {
  const file = process.argv[2];
  if (!file) { console.log('Usage: npm run restore -- <path to backup .json.gz>'); process.exit(1); }
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  const ans = await new Promise((r) => rl.question(`This REPLACES all current data with ${path.basename(file)}. Type YES to continue: `, r));
  rl.close();
  if (ans.trim() !== 'YES') { console.log('Cancelled.'); process.exit(0); }
  try {
    await db.connect();
    await migrate();
    const counts = await restore(path.resolve(file));
    console.log('Restored rows:', counts);
  } catch (e) { console.error('Restore failed:', e.message); process.exitCode = 1; }
  finally { await db.close(); }
})();
