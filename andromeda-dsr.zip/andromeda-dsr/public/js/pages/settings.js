import { html, useState, useEffect, get, post, put, download, useData, Loading, ErrorBox, Field, toast, fail, fmtDateTime, loadSettings } from '../lib.js';

const LISTS = [['loan_statuses', 'Loan case statuses'], ['products', 'Products'], ['contact_statuses', 'Calling list statuses'], ['dsa_statuses', 'DSA partner statuses'], ['dsa_profiles', 'DSA profiles']];

export function SettingsPage() {
  const { data, error, reload } = useData(() => get('/settings'), []);
  const bk = useData(() => get('/backups'), []);
  const [vals, setVals] = useState(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (data) setVals({ ...Object.fromEntries(LISTS.map(([k]) => [k, (data[k] || []).join('\n')])), dsr_due_time: data.dsr_due_time, dsr_edit_days: data.dsr_edit_days, groups: data.loan_status_groups || {} });
  }, [data]);
  if (error) return html`<${ErrorBox} error=${error} />`;
  if (!vals) return html`<${Loading} />`;
  const save = async (key, value) => {
    try { await put('/settings/' + key, { value }); toast('Saved', 'ok'); await loadSettings(); reload(); } catch (e) { fail(e); }
  };
  const statuses = vals.loan_statuses.split('\n').map((x) => x.trim()).filter(Boolean);
  const toggleGroup = (g, s) => {
    const cur = vals.groups[g] || [];
    setVals({ ...vals, groups: { ...vals.groups, [g]: cur.includes(s) ? cur.filter((x) => x !== s) : [...cur, s] } });
  };
  const backupNow = async () => { setBusy(true); try { const r = await post('/backups'); toast('Backup created: ' + r.file, 'ok'); bk.reload(); } catch (e) { fail(e); } finally { setBusy(false); } };
  return html`
    <div class="page-head"><div><h1>Settings & Backup</h1><p>Drop-down lists, DSR rules and data backups</p></div></div>
    <div class="row">
      <div class="grow stack">
        <div class="card stack"><h2>Drop-down lists</h2><p class="small muted" style="margin:0">One item per line. Existing records keep their value even if you remove it from the list.</p>
          <div class="fgrid">${LISTS.map(([k, l]) => html`<div class="stack"><${Field} label=${l}><textarea class="in" rows="8" value=${vals[k]} onInput=${(e) => setVals({ ...vals, [k]: e.target.value })}></textarea><//>
            <button class="btn sm" onClick=${() => save(k, vals[k].split('\n'))}>Save ${l.toLowerCase()}</button></div>`)}</div></div>
        <div class="card stack"><h2>How loan statuses are counted</h2>
          <div class="tbl-wrap"><table class="tbl"><thead><tr><th>Status</th><th>Approved</th><th>Rejected</th><th>Converted (disbursed)</th></tr></thead>
            <tbody>${statuses.map((s) => html`<tr><td>${s}</td>${['approved', 'rejected', 'converted'].map((g) => html`<td><input type="checkbox" aria-label=${g + ' ' + s} checked=${(vals.groups[g] || []).includes(s)} onChange=${() => toggleGroup(g, s)} /></td>`)}</tr>`)}</tbody></table></div>
          <p class="small muted" style="margin:0">Anything not approved or rejected counts as pending. Conversion ratio = converted ÷ all cases logged.</p>
          <div><button class="btn sm" onClick=${() => save('loan_status_groups', vals.groups)}>Save counting rules</button></div></div>
      </div>
      <div class="side-col stack">
        <div class="card stack"><h2>DSR rules</h2>
          <${Field} label="DSR due by (pending alert after this time)"><input class="in" type="time" value=${vals.dsr_due_time} onInput=${(e) => setVals({ ...vals, dsr_due_time: e.target.value })} /><//>
          <button class="btn sm" onClick=${() => save('dsr_due_time', vals.dsr_due_time)}>Save time</button>
          <${Field} label="Employees may edit past days" hint="0 = only today. Admins can always edit."><input class="in" type="number" min="0" max="31" value=${vals.dsr_edit_days} onInput=${(e) => setVals({ ...vals, dsr_edit_days: e.target.value })} /><//>
          <button class="btn sm" onClick=${() => save('dsr_edit_days', vals.dsr_edit_days)}>Save</button></div>
        <div class="card stack"><h2>Backups</h2>
          ${bk.data ? html`<p class="small muted" style="margin:0">Automatic backup every night at ${bk.data.time}. The last ${bk.data.keep} are kept in:<br /><code>${bk.data.dir}</code><br />Copy this folder to Google Drive / a USB disk regularly.</p>
            <button class="btn pri" disabled=${busy} onClick=${backupNow}>Back up now</button>
            <div class="stack small">${bk.data.files.slice(0, 10).map((f) => html`<div class="hstack" style="justify-content:space-between"><span>${fmtDateTime(f.created_at)} · ${(f.bytes / 1024).toFixed(0)} KB</span>
              <button class="btn sm" onClick=${() => download('/backups/' + f.file).catch(fail)}>Download</button></div>`)}
              ${!bk.data.files.length ? html`<span class="muted">No backups yet.</span>` : null}</div>` : html`<${Loading} />`}
        </div>
      </div>
    </div>`;
}
