import { html, useState, useEffect, useRef, get, download, qs, onLive, useData, Loading, ErrorBox, Pill, RolePill,
  fmtTime, money, num, ago, fail, ROLE_LABEL, navigate } from '../lib.js';

function BarChart({ series }) {
  const ref = useRef(null);
  const chart = useRef(null);
  useEffect(() => {
    if (!window.Chart || !ref.current) return;
    const labels = series.days.map((d) => d.slice(8) + '/' + d.slice(5, 7));
    if (chart.current) {
      chart.current.data.labels = labels;
      chart.current.data.datasets[0].data = series.cso;
      chart.current.data.datasets[1].data = series.hre;
      chart.current.update();
      return;
    }
    chart.current = new window.Chart(ref.current, {
      type: 'bar',
      data: { labels, datasets: [
        { label: 'CSO', data: series.cso, backgroundColor: '#1a5fad', borderRadius: 3 },
        { label: 'HRE', data: series.hre, backgroundColor: '#e8913a', borderRadius: 3 }] },
      options: { responsive: true, maintainAspectRatio: false, animation: false,
        plugins: { legend: { position: 'bottom' } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } }, x: { grid: { display: false } } } }
    });
  }, [series]);
  useEffect(() => () => chart.current && chart.current.destroy(), []);
  return html`<div class="chart-box"><canvas ref=${ref} role="img" aria-label="Activity entries per day for CSO and HRE over the last 14 days"></canvas></div>`;
}

function Kpi({ l, v, s, color }) {
  return html`<div class="kpi"><div class="l">${l}</div><div class="v" style=${color ? 'color:' + color : ''}>${v}</div><div class="s">${s}</div></div>`;
}

export function DashboardPage() {
  const [period, setPeriod] = useState('today');
  const [role, setRole] = useState('');
  const [feed, setFeed] = useState([]);
  const { data, error, reload } = useData(() => get('/dashboard' + qs({ period, role })), [period, role]);

  useEffect(() => { if (data) setFeed(data.recent.map((r) => ({ ...r, old: true }))); }, [data && data.range.from, data && data.range.to, role]);

  useEffect(() => {
    let t = null;
    const soon = () => { clearTimeout(t); t = setTimeout(reload, 1500); };
    const offs = [
      onLive('activity', (a) => { setFeed((f) => [{ at: a.at, name: a.name, role: a.role, text: a.text, level: a.level, fresh: true }, ...f].slice(0, 60)); soon(); }),
      onLive('dsr', soon), onLive('records', soon), onLive('hourly', soon), onLive('presence', soon)
    ];
    const iv = setInterval(reload, 60000);
    return () => { offs.forEach((f) => f()); clearTimeout(t); clearInterval(iv); };
  }, [period, role]);

  const exp = (format) => download('/reports' + qs({ type: period === 'today' ? 'daily' : period === 'week' ? 'weekly' : 'monthly', role, format })).catch(fail);

  if (error) return html`<${ErrorBox} error=${error} />`;
  if (!data) return html`<${Loading} />`;
  const k = data.kpis;
  const range = data.range.from === data.range.to ? data.range.from : `${data.range.from} → ${data.range.to}`;
  return html`
    <div class="page-head">
      <div><h1>Management Dashboard</h1><p>${range} · updates appear instantly without refresh</p></div>
      <div class="hstack">
        <div class="seg" role="group" aria-label="Period">
          ${[['today', 'Today'], ['week', 'This week'], ['month', 'This month']].map(([v, l]) => html`<button class=${period === v ? 'on' : ''} onClick=${() => setPeriod(v)}>${l}</button>`)}
        </div>
        <select class="in" style="width:auto" aria-label="Team" value=${role} onChange=${(e) => setRole(e.target.value)}>
          <option value="">All teams</option><option value="cso">CSO</option><option value="hre">HRE</option></select>
        <button class="btn" onClick=${() => exp('xlsx')}>Excel</button>
        <button class="btn" onClick=${() => exp('pdf')}>PDF</button>
      </div>
    </div>

    <section class="grid kpis" aria-label="Key figures">
      <${Kpi} l="Total leads" v=${num(k.totalLeads)} s=${`${num(k.loans)} loan cases · ${num(k.contacts)} contacts`} />
      <${Kpi} l="Activity entries" v=${num(k.activity)} s=${`${k.dsrSubmittedToday}/${k.activeEmployees} DSR submitted today`} />
      <${Kpi} l="Pending cases" v=${num(k.pending)} s=${`${num(k.openPipeline)} open in pipeline overall`} color="#8a4a06" />
      <${Kpi} l="Approved / disbursed" v=${num(k.approved)} s=${money(k.amountApproved) || '₹0'} color="#0b6b3e" />
      <${Kpi} l="Rejected" v=${num(k.rejected)} s="cases in period" color="#a0281d" />
      <${Kpi} l="Conversion ratio" v=${k.conversion + '%'} s="cases disbursed ÷ cases logged" />
      <${Kpi} l="Calls made" v=${num(k.calls)} s=${`${num(k.interested)} interested / converted`} />
    </section>

    <div class="row">
      <div class="card grow"><div class="hd"><h2>Daily activity – last 14 days</h2><span class="muted small">entries saved per day</span></div><${BarChart} series=${data.series} /></div>
      <div class="card side-col">
        <div class="hd"><h2>Live activity</h2><${Pill} kind="ok">● streaming<//></div>
        <div class="feed" aria-live="polite">
          ${feed.length ? feed.map((f, i) => html`<div class=${'it' + (f.level === 'warn' ? ' warn' : '') + (f.fresh ? ' new' : '')} key=${f.at + i}>
            <span class="t">${fmtTime(f.at)}</span><span><b>${f.name}</b> <span class="muted small">${ROLE_LABEL[f.role] || ''}</span> ${f.text}</span></div>`)
            : html`<div class="muted">No activity yet.</div>`}
        </div>
      </div>
    </div>

    <div class="row">
      <div class="card grow">
        <div class="hd"><h2>Employee-wise performance</h2><span class="muted small">${range}</span></div>
        <div class="tbl-wrap" style="border:0">
          <table class="tbl"><thead><tr><th>Employee</th><th>Role</th><th>Today</th><th class="num">Calls</th><th class="num">Interested/Conv.</th>
            <th class="num">Mined</th><th class="num">Loans</th><th class="num">Approved</th><th class="num">Conv. %</th><th class="num">DSA added</th><th>Hourly</th></tr></thead>
          <tbody>${data.employees.map((e) => html`<tr class="click" onClick=${() => navigate('#/employees/' + e.id)}>
            <td><b>${e.full_name}</b></td><td><${RolePill} role=${e.role} /></td>
            <td>${e.today && e.today.status === 'submitted' ? html`<${Pill} kind="ok">Submitted ${fmtTime(e.today.check_out_at)}<//>`
              : e.today && e.today.check_in_at ? html`<${Pill} kind="warn">In ${fmtTime(e.today.check_in_at)}<//>` : html`<${Pill}>Not started<//>`}</td>
            <td class="num">${e.metrics.calls}</td><td class="num">${e.metrics.interested + e.metrics.converted}</td><td class="num">${e.metrics.mined}</td>
            <td class="num">${e.loans}</td><td class="num">${e.approved}</td><td class="num">${e.conversion}%</td><td class="num">${e.dsa_added}</td>
            <td>${e.hourly_done + e.hourly_late + e.hourly_missed ? html`<span class="small">${e.hourly_done}✓ ${e.hourly_late ? e.hourly_late + ' late ' : ''}${e.hourly_missed ? html`<b style="color:var(--bad)">${e.hourly_missed} missed</b>` : ''}</span>` : html`<span class="muted">—</span>`}</td>
          </tr>`)}</tbody></table>
          ${!data.employees.length ? html`<div class="empty">No CSO/HRE employees yet. <a href="#/employees">Add employees</a></div>` : null}
        </div>
      </div>
      <div class="card side-col stack">
        <div class="hd" style="margin:0"><h2>Hourly-schedule employees</h2><a href="#/employees" class="small">Manage</a></div>
        ${data.hourly.length ? data.hourly.map((s) => html`<div style="border:1px solid var(--line);border-radius:8px;padding:10px 12px" class="click" onClick=${() => navigate('#/employees/' + s.userId)}>
          <div class="hstack" style="justify-content:space-between"><b>${s.name} · ${ROLE_LABEL[s.role]}</b><span class="muted small">${s.day ? 'Day ' + s.day : ''}</span></div>
          <div class="muted small" style="margin:2px 0 8px">${s.window}${s.activeToday ? '' : ' · not scheduled today'}</div>
          ${s.board.length ? html`<div class="slots" aria-label=${s.board.map((b) => b.label + ' ' + b.status).join(', ')}>${s.board.map((b) => html`<span class=${b.status} title=${b.label + ' – ' + b.status}></span>`)}</div>` : null}
        </div>`) : html`<div class="muted small">Nobody is on an hourly schedule. New joiners can be put on one from their profile.</div>`}
        <div class="small muted hstack"><span class="dot" style="background:#0f7b4a"></span>done <span class="dot" style="background:#e8913a"></span>due <span class="dot" style="background:#b42318"></span>missed <span class="dot" style="background:#dde1e6"></span>upcoming</div>
      </div>
    </div>

    <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(280px,1fr))">
      <div class="card"><div class="hd"><h2>CSO vs HRE</h2></div>
        <table class="tbl"><thead><tr><th>Team</th><th class="num">People</th><th class="num">Calls</th><th class="num">Int./Conv.</th><th class="num">Loans</th><th class="num">DSA</th></tr></thead>
        <tbody>${data.roleTotals.map((r) => html`<tr><td><${RolePill} role=${r.role} /></td><td class="num">${r.people}</td><td class="num">${r.calls}</td><td class="num">${r.interested}</td><td class="num">${r.loans}</td><td class="num">${r.dsa}</td></tr>`)}</tbody></table></div>
      <div class="card"><div class="hd"><h2>Case status (period)</h2></div>
        ${data.statusSplit.length ? html`<div class="stack small">${data.statusSplit.map((s) => html`<div class="hstack" style="justify-content:space-between"><span>${s.status}</span><b>${s.n}</b></div>`)}</div>` : html`<div class="muted small">No loan cases in this period.</div>`}</div>
      <div class="card"><div class="hd"><h2>Follow-ups due / overdue</h2><a class="small" href="#/loans">Open</a></div>
        ${data.followups.length ? html`<div class="stack small">${data.followups.map((f) => html`<div class="hstack" style="justify-content:space-between">
          <span><b>${f.name || 'Contact'}</b> · ${f.detail || ''} · <span class="muted">${f.owner}</span></span>
          <${Pill} kind=${f.next_follow_up < data.range.to ? 'bad' : 'warn'}>${f.next_follow_up}<//></div>`)}</div>` : html`<div class="muted small">Nothing due.</div>`}</div>
      <div class="card"><div class="hd"><h2>Security (24 h)</h2><a class="small" href="#/audit">Audit log</a></div>
        <div class="stack small">
          <div class="hstack" style="justify-content:space-between"><span>Active sessions</span><b>${data.security.sessions}</b></div>
          <div class="hstack" style="justify-content:space-between"><span>Failed sign-ins</span><b>${data.security.failed}</b></div>
          <div class="hstack" style="justify-content:space-between"><span>Locked accounts</span><b>${data.security.locked}</b></div>
          <div class="hstack" style="justify-content:space-between"><span>Blocked access attempts</span><b style=${data.security.denied ? 'color:var(--bad)' : ''}>${data.security.denied}</b></div>
        </div></div>
    </div>`;
}
