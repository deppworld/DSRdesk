import { html, useState, api, session, toast, Field } from '../lib.js';

export function LoginPage({ onDone }) {
  const [u, setU] = useState('');
  const [p, setP] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault();
    setErr(''); setBusy(true);
    try {
      const r = await api('POST', '/auth/login', { username: u, password: p });
      session.token = r.accessToken; session.user = r.user; session.today = r.today; session.tz = r.timezone;
      await onDone();
    } catch (x) { setErr(x.message); } finally { setBusy(false); }
  };
  return html`<div class="login">
    <div class="brand"><img src="/img/logo-full.png" alt="Andromeda – India's Largest Loan Distributor" />
      <p class="muted" style="font-size:15px;margin-top:18px">Daily Sales Record system</p></div>
    <form onSubmit=${submit}>
      <h1>Sign in</h1>
      ${err ? html`<div class="err" role="alert">${err}</div>` : null}
      <${Field} label="Username or employee ID"><input class="in" autocomplete="username" value=${u} onInput=${(e) => setU(e.target.value)} required autofocus /><//>
      <${Field} label="Password"><input class="in" type="password" autocomplete="current-password" value=${p} onInput=${(e) => setP(e.target.value)} required /><//>
      <button class="btn pri" style="height:44px" disabled=${busy}>${busy ? 'Signing in…' : 'Sign in'}</button>
      <p class="muted small" style="margin:0">Forgot your password? Ask your administrator to reset it. Every sign-in is recorded with IP address and device. 5 wrong attempts lock the account for 15 minutes.</p>
    </form>
  </div>`;
}

export function ChangePasswordPage({ forced, onDone, onLogout }) {
  const [cur, setCur] = useState('');
  const [n1, setN1] = useState('');
  const [n2, setN2] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault(); setErr('');
    if (n1 !== n2) return setErr('The two new passwords do not match');
    setBusy(true);
    try {
      const r = await api('POST', '/auth/change-password', { currentPassword: cur, newPassword: n1 });
      session.token = r.accessToken; session.user = r.user;
      toast('Password changed', 'ok');
      setCur(''); setN1(''); setN2('');
      if (onDone) await onDone();
    } catch (x) { setErr(x.message); } finally { setBusy(false); }
  };
  const form = html`<form class="card stack" style="max-width:420px;width:100%" onSubmit=${submit}>
    <h1>${forced ? 'Set your own password' : 'Change password'}</h1>
    ${forced ? html`<p class="muted" style="margin:0">You signed in with a temporary password. Choose a new one to continue.</p>` : null}
    ${err ? html`<div class="err" role="alert">${err}</div>` : null}
    <${Field} label=${forced ? 'Temporary password' : 'Current password'}><input class="in" type="password" autocomplete="current-password" value=${cur} onInput=${(e) => setCur(e.target.value)} required /><//>
    <${Field} label="New password" hint="At least 8 characters with letters and numbers"><input class="in" type="password" autocomplete="new-password" value=${n1} onInput=${(e) => setN1(e.target.value)} required /><//>
    <${Field} label="Repeat new password"><input class="in" type="password" autocomplete="new-password" value=${n2} onInput=${(e) => setN2(e.target.value)} required /><//>
    <button class="btn pri" disabled=${busy}>${busy ? 'Saving…' : 'Save password'}</button>
    ${forced ? html`<button type="button" class="btn ghost" onClick=${onLogout}>Sign out</button>` : null}
  </form>`;
  if (forced) return html`<div class="login"><div class="brand"><img src="/img/logo-full.png" alt="Andromeda" /></div>${form}</div>`;
  return form;
}
