import { html, useState, useEffect, get, post, useData, onLive, Loading, ErrorBox, Pill, RolePill, Field, Modal,
  fail, fmtTime, ago, today, navigate } from '../lib.js';
import { ScheduleEditor, defaultSchedule, TempPassword } from './profile.js';

function NewEmployee({ onClose, onCreated }) {
  const [f, setF] = useState({ full_name: '', mobile: '', email: '', emp_code: '', joining_date: today(), role: 'cso', branch: '', username: '' });
  const [hourly, setHourly] = useState(true);
  const [sched, setSched] = useState(defaultSchedule());
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const save = async () => {
    setErr(''); setBusy(true);
    try {
      const r = await post('/users', { ...f, hourly: hourly && f.role !== 'super_admin' ? { ...sched, enabled: true } : null });
      onCreated(r);
    } catch (e) { setErr(e.message); } finally { setBusy(false); }
  };
  return html`<${Modal} title="New employee profile" wide onClose=${onClose} footer=${html`<button class="btn" onClick=${onClose}>Cancel</button>
    <button class="btn pri" disabled=${busy} onClick=${save}>${busy ? 'Creating…' : 'Create employee'}</button>`}>
    ${err ? html`<div class="err">${err}</div>` : null}
    <div class="small" style="font-weight:700;color:var(--muted)">PERSONAL</div>
    <div class="fgrid">
      <${Field} label="Full name *"><input class="in" value=${f.full_name} onInput=${set('full_name')} placeholder="e.g. Rahul Verma" autofocus /><//>
      <${Field} label="Mobile"><input class="in" value=${f.mobile} onInput=${set('mobile')} inputmode="tel" /><//>
      <${Field} label="Email"><input class="in" type="email" value=${f.email} onInput=${set('email')} /><//>
      <${Field} label="Joining date"><input class="in" type="date" value=${f.joining_date} onInput=${set('joining_date')} /><//>
    </div>
    <div class="small" style="font-weight:700;color:var(--muted)">ROLE & ACCESS</div>
    <div class="chips" role="radiogroup" aria-label="Role">${[['cso', 'CSO'], ['hre', 'HRE'], ['super_admin', 'Super Admin']].map(([v, l]) =>
      html`<button type="button" role="radio" aria-checked=${f.role === v} class=${'chip' + (f.role === v ? ' on' : '')} onClick=${() => setF({ ...f, role: v })}>${l}</button>`)}</div>
    <div class="fgrid">
      <${Field} label="Branch / location"><input class="in" value=${f.branch} onInput=${set('branch')} placeholder="e.g. Bareilly" /><//>
      <${Field} label="Employee ID" hint="Empty = next number automatically"><input class="in" value=${f.emp_code} onInput=${set('emp_code')} placeholder="EMP-0XX" /><//>
      <${Field} label="Username" hint="Empty = made from the name"><input class="in" value=${f.username} onInput=${set('username')} placeholder="rahul.verma" /><//>
    </div>
    <p class="small muted" style="margin:0">A temporary password is generated. The employee must change it at first sign-in.</p>
    ${f.role !== 'super_admin' ? html`<div class="note stack">
      <div class="hstack" style="justify-content:space-between"><div><b>Hourly update schedule</b><div class="small muted">Recommended for new joiners. Stays on until you release them.</div></div>
        <label class="check"><input type="checkbox" checked=${hourly} onChange=${(e) => setHourly(e.target.checked)} /> On</label></div>
      ${hourly ? html`<${ScheduleEditor} value=${sched} onChange=${setSched} compact />` : null}
    </div>` : null}
  <//>`;
}

export function EmployeesPage() {
  const { data, error, reload } = useData(() => get('/users'), []);
  const [q, setQ] = useState('');
  const [role, setRole] = useState('');
  const [status, setStatus] = useState('active');
  const [creating, setCreating] = useState(false);
  const [created, setCreated] = useState(null);
  useEffect(() => { const offs = [onLive('presence', reload), onLive('dsr', reload)]; return () => offs.forEach((f) => f()); }, []);
  if (error) return html`<${ErrorBox} error=${error} />`;
  if (!data) return html`<${Loading} />`;
  const rows = data.filter((u) => (!role || u.role === role) && (status === 'all' || (status === 'active') === u.is_active) &&
    (!q || (u.full_name + ' ' + u.emp_code + ' ' + (u.mobile || '') + ' ' + u.username).toLowerCase().includes(q.toLowerCase())));
  return html`
    <div class="page-head"><div><h1>Employees & Schedules</h1><p>Create profiles, switch roles, set hourly schedules, disable access</p></div>
      <button class="btn pri" onClick=${() => setCreating(true)}>+ New employee</button></div>
    <div class="hstack">
      <input class="in" style="max-width:280px" placeholder="Search name, ID, mobile" aria-label="Search employees" value=${q} onInput=${(e) => setQ(e.target.value)} />
      <select class="in" style="width:auto" aria-label="Role" value=${role} onChange=${(e) => setRole(e.target.value)}><option value="">All roles</option><option value="cso">CSO</option><option value="hre">HRE</option><option value="super_admin">Super Admin</option></select>
      <select class="in" style="width:auto" aria-label="Status" value=${status} onChange=${(e) => setStatus(e.target.value)}><option value="active">Active</option><option value="disabled">Disabled</option><option value="all">All</option></select>
    </div>
    <div class="tbl-wrap"><table class="tbl">
      <thead><tr><th>Employee</th><th>ID</th><th>Role</th><th>Schedule</th><th>Today's DSR</th><th>Last activity</th><th>Status</th></tr></thead>
      <tbody>${rows.map((u) => html`<tr class="click" onClick=${() => navigate('#/employees/' + u.id)}>
        <td><b>${u.full_name}</b> ${u.online ? html`<span class="dot" style="background:#0f7b4a" title="online"></span>` : null}<div class="muted small">${u.username}</div></td>
        <td>${u.emp_code}</td><td><${RolePill} role=${u.role} /></td>
        <td>${u.hourly ? html`<${Pill} kind="warn">Hourly · ${u.hourly}<//>` : u.role === 'super_admin' ? '—' : 'Standard'}</td>
        <td>${u.role === 'super_admin' ? '—' : u.dsr_status === 'submitted' ? html`<${Pill} kind="ok">Submitted<//>` : u.check_in_at ? html`<${Pill} kind="warn">Started ${fmtTime(u.check_in_at)}<//>` : html`<${Pill}>Not started<//>`}</td>
        <td class="muted">${u.last_activity ? ago(u.last_activity) + ' ago' : 'never'}</td>
        <td>${u.is_active ? (u.locked_until && new Date(u.locked_until) > new Date() ? html`<${Pill} kind="bad">Locked<//>` : html`<${Pill} kind="ok">Active<//>`) : html`<${Pill}>Disabled<//>`}</td>
      </tr>`)}</tbody></table>
      ${!rows.length ? html`<div class="empty">No employees match.</div>` : null}
    </div>
    <p class="muted small" style="margin:0">Disabled employees cannot sign in. Their DSR history stays in reports.</p>
    ${creating ? html`<${NewEmployee} onClose=${() => setCreating(false)} onCreated=${(r) => { setCreating(false); setCreated(r); reload(); }} />` : null}
    ${created ? html`<${TempPassword} title=${`${created.user.full_name} created – username ${created.user.username}`} pw=${created.tempPassword} onClose=${() => setCreated(null)} />` : null}`;
}
