import { html, useState, get, qs, useData, Loading, ErrorBox, Field, Modal, fmtDateTime, ROLE_LABEL } from '../lib.js';

export function AuditPage() {
  const [q, setQ] = useState('');
  const [action, setAction] = useState('');
  const [user, setUser] = useState('');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [limit, setLimit] = useState(100);
  const [open, setOpen] = useState(null);
  const people = useData(() => get('/employees/basic'), []);
  const { data, error } = useData(() => get('/audit' + qs({ q, action, user_id: user, from, to, limit })), [q, action, user, from, to, limit]);
  return html`
    <div class="page-head"><div><h1>Audit Log</h1><p>Every sign-in, change, export and blocked access – with IP address and device</p></div></div>
    <div class="hstack" style="align-items:flex-end">
      <${Field} label="Search text or IP"><input class="in" value=${q} onInput=${(e) => setQ(e.target.value)} /><//>
      <${Field} label="Action"><select class="in" value=${action} onChange=${(e) => setAction(e.target.value)}><option value="">All</option>${((data && data.actions) || []).map((a) => html`<option>${a}</option>`)}</select><//>
      <${Field} label="Person"><select class="in" value=${user} onChange=${(e) => setUser(e.target.value)}><option value="">Everyone</option>${(people.data || []).map((p) => html`<option value=${p.id}>${p.full_name}</option>`)}</select><//>
      <${Field} label="From"><input class="in" type="date" value=${from} onChange=${(e) => setFrom(e.target.value)} /><//>
      <${Field} label="To"><input class="in" type="date" value=${to} onChange=${(e) => setTo(e.target.value)} /><//>
    </div>
    ${error ? html`<${ErrorBox} error=${error} />` : !data ? html`<${Loading} />` : html`
      <div class="tbl-wrap"><table class="tbl"><thead><tr><th>When</th><th>Who</th><th>Action</th><th>What</th><th>IP</th></tr></thead>
        <tbody>${data.rows.map((r) => html`<tr class="click" onClick=${() => setOpen(r)}>
          <td>${fmtDateTime(r.created_at)}</td><td>${r.full_name || '—'} <span class="muted small">${ROLE_LABEL[r.role] || ''}</span></td>
          <td><span class=${'pill ' + (/failed|denied|reuse|disabled|delete/.test(r.action) ? 'p-bad' : /login|logout/.test(r.action) ? 'p-gray' : 'p-info')}>${r.action}</span></td>
          <td class="wrap">${r.summary}</td><td class="muted">${r.ip}</td></tr>`)}</tbody></table></div>
      <div class="hstack small muted">Showing ${data.rows.length} of ${data.total} ${data.rows.length < data.total ? html`<button class="btn sm" onClick=${() => setLimit(limit + 200)}>Show more</button>` : null}</div>`}
    ${open ? html`<${Modal} wide title="Audit entry" onClose=${() => setOpen(null)}>
      <div class="small"><b>${fmtDateTime(open.created_at)}</b> · ${open.full_name || '—'} · ${open.action} · ${open.entity || ''} ${open.entity_id || ''}<br />IP ${open.ip}<br /><span class="muted">${open.user_agent}</span></div>
      <div>${open.summary}</div>
      ${open.before_data || open.after_data ? html`<div class="fgrid">
        <div><b class="small">Before</b><pre class="small" style="white-space:pre-wrap;background:var(--bg);padding:10px;border-radius:8px;max-height:320px;overflow:auto">${JSON.stringify(open.before_data, null, 1)}</pre></div>
        <div><b class="small">After</b><pre class="small" style="white-space:pre-wrap;background:var(--bg);padding:10px;border-radius:8px;max-height:320px;overflow:auto">${JSON.stringify(open.after_data, null, 1)}</pre></div></div>` : null}
    <//>` : null}`;
}
