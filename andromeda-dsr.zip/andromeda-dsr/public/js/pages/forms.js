import { html, useState, useEffect, get, post, useData, Loading, ErrorBox, Field, Pill, toast, fail, fmtDateTime } from '../lib.js';
import { DsrForm } from './dsr.js';

const TYPES = [['number', 'Number'], ['text', 'Short text'], ['textarea', 'Long text'], ['select', 'Drop-down'], ['time', 'Time'], ['date', 'Date'], ['checkbox', 'Yes / no']];
const METRICS = [['', '— not counted —'], ['calls', 'Calls'], ['interested', 'Interested'], ['converted', 'Converted'], ['connects', 'DSA connects'], ['kits', 'DSA kits'],
  ['files_login', 'Files login'], ['meetings', 'Meetings'], ['mined', 'Data mined'], ['registrations', 'DSA registrations']];

export function FormsPage() {
  const [role, setRole] = useState('cso');
  const all = useData(() => get('/forms'), []);
  const active = useData(() => get('/forms/active?role=' + role), [role]);
  const [secs, setSecs] = useState(null);
  const [preview, setPreview] = useState(false);
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (active.data) setSecs(JSON.parse(JSON.stringify(active.data.sections))); }, [active.data]);

  if (active.error) return html`<${ErrorBox} error=${active.error} />`;
  if (!secs) return html`<${Loading} />`;
  const upd = (i, patch) => setSecs(secs.map((s, j) => (j === i ? { ...s, ...patch } : s)));
  const updF = (i, k, patch) => upd(i, { fields: secs[i].fields.map((f, j) => (j === k ? { ...f, ...patch } : f)) });
  const move = (arr, i, d) => { const a = [...arr]; const t = a[i + d]; if (t === undefined) return a; a[i + d] = a[i]; a[i] = t; return a; };
  const publish = async () => {
    if (!confirm(`Publish a new ${role.toUpperCase()} form? Employees get it on their next DSR day. Past entries keep the form they were filled with.`)) return;
    setBusy(true);
    try { await post('/forms/' + role, { sections: secs }); toast('New form version published', 'ok'); active.reload(); all.reload(); } catch (e) { fail(e); } finally { setBusy(false); }
  };

  return html`
    <div class="page-head"><div><h1>Form Builder</h1><p>Change the DSR form without any programming. Each publish creates a new version; old entries are never lost.</p></div>
      <div class="hstack"><div class="seg">${['cso', 'hre'].map((r) => html`<button class=${role === r ? 'on' : ''} onClick=${() => { setSecs(null); setRole(r); }}>${r.toUpperCase()} form</button>`)}</div>
        <button class="btn" onClick=${() => setPreview(!preview)}>${preview ? 'Edit' : 'Preview'}</button>
        <button class="btn pri" disabled=${busy} onClick=${publish}>Publish new version</button></div></div>
    <div class="small muted">Currently live: <b>v${active.data.version}</b> · ${fmtDateTime(active.data.created_at)}</div>
    ${preview ? html`<${DsrForm} template=${{ sections: secs }} data=${{}} setData=${() => {}} />` : html`
      ${secs.map((s, i) => html`<div class="card stack">
        <div class="hstack" style="align-items:flex-end">
          <${Field} label="Section title"><input class="in" value=${s.title} onInput=${(e) => upd(i, { title: e.target.value })} /><//>
          <${Field} label="Time block (optional)"><input class="in" value=${s.time || ''} placeholder="e.g. 10:00 AM - 01:30 PM" onInput=${(e) => upd(i, { time: e.target.value })} /><//>
          <span style="flex:1"></span>
          <button class="btn sm" aria-label="Move section up" onClick=${() => setSecs(move(secs, i, -1))}>↑</button>
          <button class="btn sm" aria-label="Move section down" onClick=${() => setSecs(move(secs, i, 1))}>↓</button>
          <button class="btn sm danger" onClick=${() => confirm('Remove this section?') && setSecs(secs.filter((_, j) => j !== i))}>Remove section</button>
        </div>
        <div class="tbl-wrap"><table class="tbl"><thead><tr><th>Field label</th><th>Type</th><th>Counts towards (dashboard)</th><th>Options (drop-down, comma separated)</th><th>Required</th><th></th></tr></thead>
          <tbody>${s.fields.map((f, k) => html`<tr>
            <td><input class="in" aria-label="Field label" value=${f.label} onInput=${(e) => updF(i, k, { label: e.target.value })} /><div class="muted small">key: ${f.key || '(new)'}</div></td>
            <td><select class="in" aria-label="Type" value=${f.type} onChange=${(e) => updF(i, k, { type: e.target.value })}>${TYPES.map(([v, l]) => html`<option value=${v}>${l}</option>`)}</select></td>
            <td>${f.type === 'number' ? html`<select class="in" aria-label="Metric" value=${f.metric || ''} onChange=${(e) => updF(i, k, { metric: e.target.value })}>${METRICS.map(([v, l]) => html`<option value=${v}>${l}</option>`)}</select>` : html`<span class="muted">—</span>`}</td>
            <td>${f.type === 'select' ? html`<input class="in" aria-label="Options" value=${(f.options || []).join(', ')} onInput=${(e) => updF(i, k, { options: e.target.value.split(',').map((x) => x.trim()) })} />` : html`<span class="muted">—</span>`}</td>
            <td><input type="checkbox" aria-label="Required" checked=${!!f.required} onChange=${(e) => updF(i, k, { required: e.target.checked })} /></td>
            <td class="nowrap"><button class="btn sm" aria-label="Up" onClick=${() => upd(i, { fields: move(s.fields, k, -1) })}>↑</button>
              <button class="btn sm" aria-label="Down" onClick=${() => upd(i, { fields: move(s.fields, k, 1) })}>↓</button>
              <button class="btn sm danger" aria-label="Remove field" onClick=${() => upd(i, { fields: s.fields.filter((_, j) => j !== k) })}>✕</button></td>
          </tr>`)}</tbody></table></div>
        <div><button class="btn sm" onClick=${() => upd(i, { fields: [...s.fields, { label: '', type: 'number' }] })}>+ Add field</button></div>
      </div>`)}
      <div><button class="btn" onClick=${() => setSecs([...secs, { title: 'New section', time: '', fields: [{ label: 'Count', type: 'number' }] }])}>+ Add section</button></div>
      <div class="info small">Tip: renaming a field keeps its internal key, so reports keep adding up across versions. Deleting a field and adding a new one creates a new key. Only number fields marked “Counts towards” feed the dashboard and reports.</div>`}
    ${all.data ? html`<div class="card"><h2 style="margin-bottom:8px">Version history</h2>${all.data.filter((f) => f.role === role).map((f) => html`<div class="small">v${f.version} · ${fmtDateTime(f.created_at)} ${f.created_by_name ? '· ' + f.created_by_name : '· initial'} ${f.is_active ? html`<${Pill} kind="ok">live<//>` : ''}</div>`)}</div>` : null}`;
}
