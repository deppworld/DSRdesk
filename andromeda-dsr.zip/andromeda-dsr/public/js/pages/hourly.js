import { html, useState, useEffect, get, post, useData, onLive, Loading, ErrorBox, Pill, Field, toast, fail, fmtTime } from '../lib.js';

const KIND = { done: 'ok', late: 'warn', missed: 'bad', due: 'warn', break: 'gray', upcoming: 'gray', skipped: 'gray' };
const LABEL = { done: 'Done', late: 'Late', missed: 'Missed', due: 'Due now', break: 'Break', upcoming: 'Upcoming', skipped: 'Before start' };
const fmt12 = (m) => { const h = Math.floor(m / 60), mm = m % 60, ap = h >= 12 ? 'PM' : 'AM', h12 = h % 12 || 12; return `${String(h12).padStart(2, '0')}:${String(mm).padStart(2, '0')} ${ap}`; };

function Countdown({ target, base, loadedAt }) {
  const [, tick] = useState(0);
  useEffect(() => { const t = setInterval(() => tick((x) => x + 1), 1000); return () => clearInterval(t); }, []);
  const nowSec = base * 60 + (Date.now() - loadedAt) / 1000;
  const left = Math.max(0, Math.round(target * 60 - nowSec));
  const mm = Math.floor(left / 60), ss = left % 60;
  return html`<span>${String(mm).padStart(2, '0')}:${String(ss).padStart(2, '0')}</span>`;
}

export function HourlyPage() {
  const { data, error, reload } = useData(() => get('/hourly/mine').then((d) => ({ ...d, loadedAt: Date.now() })), []);
  const [sel, setSel] = useState(null);
  const [form, setForm] = useState({ activity: '', data: {}, remarks: '' });
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const iv = setInterval(reload, 60000);
    const offs = [onLive('notification', reload), onLive('schedule', reload)];
    return () => { clearInterval(iv); offs.forEach((f) => f()); };
  }, []);

  useEffect(() => {
    if (!data || !data.board.length) return;
    const current = data.board.find((b) => b.slot === sel) || data.board.find((b) => b.status === 'due') || data.board.find((b) => b.status === 'missed');
    if (current && current.slot !== sel) pick(current);
  }, [data]);

  function pick(b) {
    if (b.status === 'break' || b.status === 'upcoming' || b.status === 'skipped') return;
    setSel(b.slot);
    const u = b.update;
    const firstSec = data.template ? data.template.sections[0].title : '';
    setForm(u ? { activity: u.activity || firstSec, data: u.data || {}, remarks: u.remarks || '' } : { activity: firstSec, data: {}, remarks: '' });
  }

  if (error) return html`<${ErrorBox} error=${error} />`;
  if (!data) return html`<${Loading} />`;
  if (!data.schedule || data.released) return html`<div class="card"><h1>Hourly updates</h1><p>${data.released ? 'You have been released from hourly updates. Continue with your normal daily DSR.' : 'You are not on an hourly update schedule.'}</p><a class="btn pri" href="#/my-dsr">Open my DSR</a></div>`;
  if (!data.active) return html`<div class="card"><h1>Hourly updates</h1><p>No hourly updates are scheduled for today.</p></div>`;

  const s = data.schedule;
  const cell = data.board.find((b) => b.slot === sel);
  const nextDue = data.board.find((b) => b.status === 'due');
  const section = data.template && data.template.sections.find((x) => x.title === form.activity);
  const numFields = section ? section.fields.filter((f) => f.type === 'number') : [];
  const done = data.board.filter((b) => b.status === 'done' || b.status === 'late').length;
  const total = data.board.filter((b) => b.status !== 'break' && b.status !== 'skipped').length;

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await post('/hourly/mine', { slot: sel, activity: form.activity, data: form.data, remarks: form.remarks });
      toast(`Update for ${cell.label} sent`, 'ok');
      reload();
    } catch (x) { fail(x); } finally { setBusy(false); }
  };

  return html`
    <div class="note hstack" role="status" style="justify-content:space-between">
      <div><b style="font-size:15px">You are on an hourly update schedule</b>
        <div class="small muted">Set by management: ${fmt12(s.start_min)} – ${fmt12(s.end_min)}, every ${s.interval_min} minutes. It stays until your manager releases you.</div></div>
      ${nextDue ? html`<div class="right"><div class="small muted">${nextDue.label} update due in</div><div style="font-size:26px;font-weight:700;color:var(--warn)">
        <${Countdown} target=${nextDue.slot + s.grace_min} base=${data.nowMin} loadedAt=${data.loadedAt} /></div></div>` : html`<div class="right small muted">${done}/${total} done today</div>`}
    </div>
    <div class="row">
      <section class="side-col" aria-labelledby="tl">
        <h2 id="tl" style="margin-bottom:10px">Today · ${done}/${total} done</h2>
        <div class="slotlist">${data.board.map((b) => html`<button type="button" class=${'slot ' + (b.status === 'due' ? 'due ' : '') + (b.status === 'break' ? 'break ' : '') + (b.slot === sel ? 'sel' : '')}
          disabled=${b.status === 'break' || b.status === 'upcoming' || b.status === 'skipped'} onClick=${() => pick(b)}>
          <${Pill} kind=${KIND[b.status]}>${LABEL[b.status]}<//><b>${b.label}</b>
          <span class="muted small" style="margin-left:auto">${b.update ? 'sent ' + fmtTime(b.update.submitted_at) : b.status === 'break' ? b.fromLabel + ' – ' + b.label : ''}</span></button>`)}</div>
        <p class="small muted">A missed slot turns red and your manager is alerted. You can still send it — it is marked “late”.</p>
      </section>
      <section class="card grow" aria-labelledby="fm">
        ${cell ? html`<form class="stack" onSubmit=${submit}>
          <div class="hstack" style="justify-content:space-between"><h2 id="fm">Update for ${cell.fromLabel} – ${cell.label}</h2>${cell.update ? html`<${Pill} kind=${KIND[cell.status]}>${LABEL[cell.status]} – you can correct it<//>` : null}</div>
          <${Field} label="What did you work on?"><select class="in" value=${form.activity} onChange=${(e) => setForm({ ...form, activity: e.target.value })}>
            ${(data.template ? data.template.sections : []).map((x) => html`<option>${x.title}</option>`)}<option>Other</option></select><//>
          ${numFields.length ? html`<div class="fgrid">${numFields.map((f) => html`<${Field} label=${f.label}><input class="in" type="number" min="0" inputmode="numeric" value=${form.data[f.key] ?? ''}
            onInput=${(e) => setForm({ ...form, data: { ...form.data, [f.key]: e.target.value === '' ? '' : Number(e.target.value) } })} /><//>`)}</div>` : null}
          <${Field} label="Details – names, cities, what happened"><textarea class="in" rows="4" value=${form.remarks} onInput=${(e) => setForm({ ...form, remarks: e.target.value })} placeholder="e.g. 1. Sanjay / Lucknow – interested, 2. …"></textarea><//>
          <div class="hstack" style="justify-content:flex-end"><button class="btn pri" disabled=${busy}>${busy ? 'Sending…' : cell.update ? 'Update' : 'Submit update'}</button></div>
          <p class="small muted" style="margin:0">Numbers you send here can be filled into your daily DSR with one click (“Fill totals into DSR”).</p>
        </form>` : html`<div class="empty">Nothing due right now. The next slot opens automatically.</div>`}
      </section>
    </div>`;
}
