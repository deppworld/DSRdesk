// One screen used for Loan Cases, Calling Lists and DSA Partners.
import { html, useState, useEffect, get, post, patch, del, download, qs, useData, onLive, Loading, ErrorBox, Pill, Field, Modal,
  toast, fail, fmtDate, money, today, session, shared, loanStatusKind } from '../lib.js';

const S = () => shared.settings || {};

const KINDS = {
  loans: {
    title: 'Loan Cases', mine: 'My Loan Cases', path: '/loans', noun: 'loan case', titleKey: 'customer_name',
    statusOptions: () => S().loan_statuses || [],
    columns: [
      ['case_date', 'Date', (r) => fmtDate(r.case_date)], ['customer_name', 'Customer', (r) => html`<b>${r.customer_name}</b>`],
      ['lead_by', 'Lead by'], ['product', 'Product'], ['loan_amount', 'Amount', (r) => money(r.loan_amount)], ['bank', 'Bank / NBFC'],
      ['status', 'Status', (r) => html`<${Pill} kind=${loanStatusKind(r.status, S().loan_status_groups)}>${r.status}<//>`],
      ['next_follow_up', 'Next follow-up', (r) => fu(r.next_follow_up)]
    ],
    fields: [
      ['case_date', 'Date', 'date'], ['customer_name', 'Customer name *', 'text'], ['company_name', 'Company name', 'text'],
      ['contact_no', 'Contact no.', 'text'], ['email', 'Email', 'text'], ['pan', 'PAN (stored encrypted)', 'text'], ['location', 'Location', 'text'],
      ['lead_by', 'Lead by (DSA)', 'text'], ['product', 'Product', 'select', () => S().products], ['loan_amount', 'Loan amount (₹)', 'number'],
      ['bank', 'Login bank / NBFC', 'text'], ['application_no', 'Application no.', 'text'], ['login_date', 'Login date', 'date'],
      ['status', 'Case status', 'select', () => S().loan_statuses], ['rejected_reason', 'Rejected reason', 'text'],
      ['next_follow_up', 'Next follow-up', 'date'], ['banker', 'Banker', 'text'], ['payout', 'Payout (₹)', 'number'],
      ['last_update', 'Last update / comments', 'textarea']
    ],
    defaults: () => ({ case_date: today(), status: (S().loan_statuses || [])[0] || '' })
  },
  contacts: {
    title: 'Calling Lists', mine: 'My Calling Lists', path: '/contacts', noun: 'contact', titleKey: 'name',
    statusOptions: () => S().contact_statuses || [],
    tabs: [['dsa_calling', 'DSA calling'], ['data_mining', 'Data mining']], tabKey: 'list_type',
    columns: [
      ['contact_date', 'Date', (r) => fmtDate(r.contact_date)], ['name', 'Name', (r) => html`<b>${r.name || '—'}</b>`], ['mobile1', 'Mobile'],
      ['company', 'Company / industry'], ['city', 'City', (r) => [r.city, r.state].filter(Boolean).join(', ')],
      ['status', 'Status', (r) => (r.status ? html`<${Pill} kind=${/interested|collected/i.test(r.status) && !/not/i.test(r.status) ? 'ok' : /not|wrong|exist/i.test(r.status) ? 'bad' : 'warn'}>${r.status}<//>` : '')],
      ['next_follow_up', 'Follow-up', (r) => fu(r.next_follow_up)]
    ],
    fields: [
      ['list_type', 'List', 'select', () => ['dsa_calling', 'data_mining']], ['contact_date', 'Date', 'date'], ['name', 'Name', 'text'],
      ['mobile1', 'Mobile 1 *', 'text'], ['mobile2', 'Mobile 2', 'text'], ['designation', 'Designation', 'text'], ['company', 'Company / industry', 'text'],
      ['city', 'City / town', 'text'], ['state', 'State', 'text'], ['status', 'Status', 'select', () => S().contact_statuses],
      ['next_follow_up', 'Next follow-up', 'date'], ['remarks', 'Remarks', 'textarea']
    ],
    defaults: (tab) => ({ contact_date: today(), list_type: tab || 'dsa_calling' })
  },
  dsa: {
    title: 'DSA Partners', mine: 'My DSA Partners', path: '/dsa', noun: 'DSA partner', titleKey: 'name',
    statusOptions: () => S().dsa_statuses || [],
    columns: [
      ['onboard_date', 'Date', (r) => fmtDate(r.onboard_date)], ['name', 'DSA name', (r) => html`<b>${r.name}</b>`], ['andro_code', 'OneAndro code'],
      ['erp_code', 'ERP code'], ['location', 'Location'], ['mobile', 'Mobile'], ['profile', 'Profile'],
      ['status', 'Status', (r) => (r.status ? html`<${Pill} kind=${/success|active/i.test(r.status) && !/not/i.test(r.status) ? 'ok' : /not|0 billing/i.test(r.status) ? 'bad' : 'warn'}>${r.status}<//>` : '')]
    ],
    fields: [
      ['onboard_date', 'Date', 'date'], ['name', 'DSA name *', 'text'], ['birthday', 'Birthday', 'date'], ['mobile', 'Mobile', 'text'],
      ['location', 'Location', 'text'], ['andro_code', 'OneAndro code', 'text'], ['dsa_code', 'DSA code', 'text'], ['erp_code', 'ERP code', 'text'],
      ['on_app', 'On OneAndro app', 'select', () => ['Yes', 'No']], ['profile', 'Profile', 'select', () => S().dsa_profiles],
      ['status', 'Status', 'select', () => S().dsa_statuses], ['irda', 'IRDA', 'textarea'], ['remarks', 'Remarks', 'textarea']
    ],
    defaults: () => ({ onboard_date: today() })
  }
};

function fu(d) {
  if (!d) return '';
  const t = today();
  return html`<${Pill} kind=${d < t ? 'bad' : d === t ? 'warn' : 'gray'}>${d < t ? 'Overdue · ' : d === t ? 'Today · ' : ''}${fmtDate(d)}<//>`;
}

function RecordForm({ cfg, value, onClose, onSaved, people }) {
  const isNew = !value.id;
  const [f, setF] = useState(value);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const admin = session.user.role === 'super_admin';
  const save = async () => {
    setErr(''); setBusy(true);
    try {
      const body = { ...f };
      if (!isNew && cfg.path === '/loans' && body.pan && body.pan.startsWith('••')) delete body.pan;
      delete body.owner_name; delete body.created_at; delete body.updated_at; delete body.id;
      const r = isNew ? await post(cfg.path, body) : await patch(`${cfg.path}/${value.id}`, body);
      onSaved(r);
    } catch (e) { setErr(e.message); } finally { setBusy(false); }
  };
  const remove = async () => {
    if (!confirm(`Delete this ${cfg.noun} permanently?`)) return;
    try { await del(`${cfg.path}/${value.id}`); toast('Deleted'); onSaved(null); } catch (e) { fail(e); }
  };
  const reveal = async () => { try { const r = await get(`${cfg.path}/${value.id}?reveal=1`); setF({ ...f, pan: r.pan || '' }); } catch (e) { fail(e); } };
  return html`<${Modal} wide title=${isNew ? `New ${cfg.noun}` : `${value[cfg.titleKey] || cfg.noun}`} onClose=${onClose}
    footer=${html`${!isNew && admin ? html`<button class="btn danger" style="margin-right:auto" onClick=${remove}>Delete</button>` : null}
      <button class="btn" onClick=${onClose}>Cancel</button><button class="btn pri" disabled=${busy} onClick=${save}>${busy ? 'Saving…' : 'Save'}</button>`}>
    ${err ? html`<div class="err">${err}</div>` : null}
    ${!isNew ? html`<div class="small muted">Owner: <b>${value.owner_name}</b> · last changed ${new Date(value.updated_at).toLocaleString()}</div>` : null}
    ${admin && isNew ? html`<${Field} label="Belongs to employee"><select class="in" value=${f.owner_id || ''} onChange=${(e) => setF({ ...f, owner_id: e.target.value })}>
      <option value="">Me (admin)</option>${people.filter((p) => p.is_active).map((p) => html`<option value=${p.id}>${p.full_name}</option>`)}</select><//>` : null}
    <div class="fgrid">${cfg.fields.map(([k, label, type, opts]) => html`<${Field} label=${label} wide=${type === 'textarea'}>
      ${type === 'textarea' ? html`<textarea class="in" rows="3" value=${f[k] ?? ''} onInput=${(e) => setF({ ...f, [k]: e.target.value })}></textarea>`
        : type === 'select' ? html`<select class="in" value=${f[k] ?? ''} onChange=${(e) => setF({ ...f, [k]: e.target.value })}><option value="">—</option>
            ${[...new Set([...(opts() || []), ...(f[k] ? [f[k]] : [])])].map((o) => html`<option value=${o}>${o.replace('_', ' ')}</option>`)}</select>`
        : html`<div class="hstack" style="flex-wrap:nowrap"><input class="in" type=${type === 'number' ? 'number' : type} step="any" value=${f[k] ?? ''} onInput=${(e) => setF({ ...f, [k]: e.target.value })} />
            ${k === 'pan' && !isNew && f.pan && f.pan.startsWith('••') ? html`<button type="button" class="btn sm" onClick=${reveal}>Show</button>` : null}</div>`}<//>`)}</div>
  <//>`;
}

export function RecordsPage({ kind }) {
  const cfg = KINDS[kind];
  const admin = session.user.role === 'super_admin';
  const [tab, setTab] = useState(cfg.tabs ? cfg.tabs[0][0] : '');
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('');
  const [follow, setFollow] = useState('');
  const [owner, setOwner] = useState('');
  const [limit, setLimit] = useState(50);
  const [editing, setEditing] = useState(null);
  const people = useData(() => (admin ? get('/employees/basic') : Promise.resolve([])), []);
  const params = { q, status, follow_up: follow, owner_id: owner, limit, ...(cfg.tabKey ? { [cfg.tabKey]: tab } : {}) };
  const { data, error, reload } = useData(() => get(cfg.path + qs(params)), [q, status, follow, owner, limit, tab]);
  useEffect(() => { let t; const off = onLive('records', () => { clearTimeout(t); t = setTimeout(reload, 700); }); return () => { off(); clearTimeout(t); }; }, [q, status, follow, owner, limit, tab]);

  const exportX = () => download(cfg.path + qs({ ...params, format: 'xlsx', limit: undefined })).catch(fail);
  return html`
    <div class="page-head"><div><h1>${admin ? cfg.title : cfg.mine}</h1><p>${admin ? 'All employees' : 'Only you and management can see these'}</p></div>
      <div class="hstack">${admin ? html`<button class="btn" onClick=${exportX}>Export Excel</button>` : null}
        <button class="btn pri" onClick=${() => setEditing(cfg.defaults(tab))}>+ New ${cfg.noun}</button></div></div>
    ${cfg.tabs ? html`<div class="tabs" role="tablist">${cfg.tabs.map(([v, l]) => html`<button role="tab" aria-selected=${tab === v} class=${tab === v ? 'on' : ''} onClick=${() => setTab(v)}>${l}</button>`)}</div>` : null}
    <div class="hstack">
      <input class="in" style="max-width:260px" placeholder="Search" aria-label="Search" value=${q} onInput=${(e) => setQ(e.target.value)} />
      <select class="in" style="width:auto" aria-label="Status" value=${status} onChange=${(e) => setStatus(e.target.value)}><option value="">All statuses</option>
        ${cfg.statusOptions().map((s) => html`<option>${s}</option>`)}</select>
      ${kind !== 'dsa' ? html`<select class="in" style="width:auto" aria-label="Follow-up" value=${follow} onChange=${(e) => setFollow(e.target.value)}>
        <option value="">Any follow-up</option><option value="today">Due today</option><option value="overdue">Overdue</option><option value="upcoming">Upcoming</option></select>` : null}
      ${admin ? html`<select class="in" style="width:auto" aria-label="Employee" value=${owner} onChange=${(e) => setOwner(e.target.value)}><option value="">All employees</option>
        ${(people.data || []).map((p) => html`<option value=${p.id}>${p.full_name}</option>`)}</select>` : null}
    </div>
    ${error ? html`<${ErrorBox} error=${error} />` : !data ? html`<${Loading} />` : html`
      <div class="tbl-wrap"><table class="tbl">
        <thead><tr>${admin ? html`<th>Employee</th>` : null}${cfg.columns.map((c) => html`<th>${c[1]}</th>`)}</tr></thead>
        <tbody>${data.rows.map((r) => html`<tr class="click" onClick=${() => setEditing(r)}>
          ${admin ? html`<td>${r.owner_name}</td>` : null}${cfg.columns.map((c) => html`<td>${c[2] ? c[2](r) : r[c[0]] ?? ''}</td>`)}</tr>`)}</tbody></table>
        ${!data.rows.length ? html`<div class="empty">Nothing here yet. Click “New ${cfg.noun}” to add one.</div>` : null}</div>
      <div class="hstack small muted">Showing ${data.rows.length} of ${data.total}
        ${data.rows.length < data.total ? html`<button class="btn sm" onClick=${() => setLimit(limit + 100)}>Show more</button>` : null}</div>`}
    ${editing ? html`<${RecordForm} cfg=${cfg} value=${editing} people=${people.data || []} onClose=${() => setEditing(null)}
      onSaved=${() => { setEditing(null); toast('Saved', 'ok'); reload(); }} />` : null}`;
}
