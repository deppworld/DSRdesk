import { html, useState, useEffect, get, post, put, patch, useData, onLive, Loading, ErrorBox, Pill, RolePill, Field, Modal,
  toast, fail, fmtDateTime, fmtDate, minToHHMM, ROLE_LABEL, today, session } from '../lib.js';

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const toMin = (s) => { const m = /^(\d{1,2}):(\d{2})$/.exec(s || ''); return m ? +m[1] * 60 + +m[2] : null; };
const fmt12 = (m) => { const h = Math.floor(m / 60), mm = m % 60, ap = h >= 12 ? 'PM' : 'AM', h12 = h % 12 || 12; return `${String(h12).padStart(2, '0')}:${String(mm).padStart(2, '0')} ${ap}`; };

export function defaultSchedule() {
  return { enabled: true, start: '10:00', end: '18:30', interval_min: 60, grace_min: 10, days: [1, 2, 3, 4, 5, 6],
    break_start: '13:30', break_end: '14:00', until_date: '', remind_before: true, alert_admin: true };
}
export function scheduleFromServer(s) {
  if (!s) return defaultSchedule();
  return { enabled: s.enabled, start: minToHHMM(s.start_min), end: minToHHMM(s.end_min), interval_min: s.interval_min, grace_min: s.grace_min,
    days: s.days, break_start: minToHHMM(s.break_start_min), break_end: minToHHMM(s.break_end_min), until_date: s.until_date || '',
    remind_before: s.remind_before, alert_admin: s.alert_admin };
}

// Mirrors server/services/schedule.js buildSlots so the preview matches exactly.
export function previewSlots(s) {
  const st = toMin(s.start), en = toMin(s.end), bs = toMin(s.break_start), be = toMin(s.break_end);
  if (st === null || en === null || en <= st) return [];
  const step = Math.max(15, +s.interval_min);
  const out = [];
  for (let t = st + step; t <= en; t += step) out.push(t);
  if (!out.length || out[out.length - 1] < en) out.push(en);
  return out.map((t) => ({ t, isBreak: bs !== null && be !== null && t > bs && t <= be }));
}

export function ScheduleEditor({ value, onChange, compact }) {
  const s = value;
  const set = (k, v) => onChange({ ...s, [k]: v });
  const slots = previewSlots(s);
  const due = slots.filter((x) => !x.isBreak).length;
  return html`<div class="stack">
    <div class="fgrid">
      <${Field} label="Start time"><input class="in" type="time" value=${s.start} onInput=${(e) => set('start', e.target.value)} /><//>
      <${Field} label="End time"><input class="in" type="time" value=${s.end} onInput=${(e) => set('end', e.target.value)} /><//>
      <${Field} label="Grace after each slot"><select class="in" value=${s.grace_min} onChange=${(e) => set('grace_min', +e.target.value)}>
        ${[0, 5, 10, 15, 20, 30].map((g) => html`<option value=${g}>${g} min</option>`)}</select><//>
    </div>
    <div class="f">Update every
      <div class="chips">${[15, 30, 45, 60, 90, 120].map((n) => html`<button type="button" class=${'chip' + (+s.interval_min === n ? ' on' : '')} aria-pressed=${+s.interval_min === n} onClick=${() => set('interval_min', n)}>${n} min</button>`)}</div></div>
    <div class="f">Working days
      <div class="chips">${DAYS.map((d, i) => html`<label class=${'chip' + (s.days.includes(i) ? ' on' : '')}><input type="checkbox" class="sr" checked=${s.days.includes(i)}
        onChange=${() => set('days', s.days.includes(i) ? s.days.filter((x) => x !== i) : [...s.days, i].sort())} />${d}</label>`)}</div></div>
    <div class="fgrid">
      <${Field} label="Break from (no update needed)"><input class="in" type="time" value=${s.break_start} onInput=${(e) => set('break_start', e.target.value)} /><//>
      <${Field} label="Break to"><input class="in" type="time" value=${s.break_end} onInput=${(e) => set('break_end', e.target.value)} /><//>
      <${Field} label="Schedule lasts" hint="Leave empty = until you release them manually"><input class="in" type="date" value=${s.until_date} onInput=${(e) => set('until_date', e.target.value)} /><//>
    </div>
    <div class="info">
      <div class="hstack" style="justify-content:space-between;margin-bottom:8px"><b>${due} update${due === 1 ? '' : 's'} per day</b><span class="muted small">an update is due at each time</span></div>
      <div class="chips">${slots.map((x) => html`<span class="pill ${x.isBreak ? 'p-gray' : 'p-info'}" style=${x.isBreak ? 'text-decoration:line-through' : ''}>${fmt12(x.t)}${x.isBreak ? ' · break' : ''}</span>`)}</div>
      ${!slots.length ? html`<span class="err">End time must be after start time.</span>` : null}
    </div>
    ${compact ? null : html`<div class="stack">
      <label class="check"><input type="checkbox" checked=${s.remind_before} onChange=${(e) => set('remind_before', e.target.checked)} /> Remind the employee 5 minutes before each slot</label>
      <label class="check"><input type="checkbox" checked=${s.alert_admin} onChange=${(e) => set('alert_admin', e.target.checked)} /> Alert me when a slot is missed</label>
    </div>`}
  </div>`;
}

function TempPassword({ title, pw, onClose }) {
  return html`<${Modal} title=${title} onClose=${onClose} footer=${html`<button class="btn pri" onClick=${onClose}>Done</button>`}>
    <p style="margin:0">Give this temporary password to the employee. They must change it at first sign-in. It will not be shown again.</p>
    <div class="hstack"><code style="font-size:20px;background:var(--bg);padding:10px 14px;border-radius:8px;user-select:all">${pw}</code>
      <button class="btn" onClick=${() => navigator.clipboard && navigator.clipboard.writeText(pw).then(() => toast('Copied'))}>Copy</button></div>
  <//>`;
}
export { TempPassword };

export function ProfilePage({ id }) {
  const { data, error, reload } = useData(() => get('/users/' + id), [id]);
  const [sched, setSched] = useState(null);
  const [roleForm, setRoleForm] = useState({ role: '', reason: '', effective_from: today() });
  const [edit, setEdit] = useState(null);
  const [pw, setPw] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => { if (data) { setSched(scheduleFromServer(data.schedule)); setRoleForm((r) => ({ ...r, role: r.role || (data.user.role === 'cso' ? 'hre' : 'cso') })); } }, [data]);
  useEffect(() => onLive('hourly', (e) => { if (String(e.userId) === String(id)) reload(); }), [id]);

  if (error) return html`<${ErrorBox} error=${error} />`;
  if (!data || !sched) return html`<${Loading} />`;
  const u = data.user;
  const s = data.schedule;
  const hourlyOn = s && s.enabled && !s.released_at;
  const isSelf = u.id === session.user.id;
  const act = async (fn, msg) => { setBusy(true); try { const r = await fn(); if (msg) toast(msg, 'ok'); reload(); return r; } catch (e) { fail(e); } finally { setBusy(false); } };

  const saveSchedule = () => act(() => put(`/users/${u.id}/schedule`, { ...sched, enabled: true }), 'Schedule saved – employee notified');
  const release = () => confirm(`Release ${u.full_name} from hourly updates?`) && act(() => post(`/users/${u.id}/schedule/release`), 'Released from hourly updates');
  const reapply = () => act(() => post(`/users/${u.id}/schedule/reapply`), 'Hourly updates switched on again');
  const switchRole = () => confirm(`Change ${u.full_name}'s role to ${ROLE_LABEL[roleForm.role]}? They will be signed out and see the new form next time.`) &&
    act(() => post(`/users/${u.id}/role`, roleForm), 'Role changed');
  const resetPw = async () => { if (!confirm('Reset password? The employee is signed out everywhere.')) return; const r = await act(() => post(`/users/${u.id}/reset-password`)); if (r) setPw(r.tempPassword); };

  return html`
    <a href="#/employees" class="small">← All employees</a>
    <div class="page-head">
      <div class="hstack" style="gap:14px">
        <div aria-hidden="true" style="width:52px;height:52px;border-radius:50%;background:var(--brand-tint);color:var(--brand-dark);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:18px">${u.full_name.split(' ').map((x) => x[0]).slice(0, 2).join('')}</div>
        <div><h1>${u.full_name}</h1>
          <div class="hstack small muted" style="margin-top:4px">${u.emp_code} · ${u.username}${u.branch ? ' · ' + u.branch : ''} · joined ${fmtDate(u.joining_date)}
            <${RolePill} role=${u.role} />
            ${u.is_active ? (data.online ? html`<${Pill} kind="ok">● Online<//>` : null) : html`<${Pill} kind="bad">Disabled<//>`}
            ${hourlyOn ? html`<${Pill} kind="warn">Hourly updates<//>` : s && s.released_at ? html`<${Pill} kind="ok">Released ${fmtDate(s.released_at)}<//>` : null}
            ${u.locked_until && new Date(u.locked_until) > new Date() ? html`<${Pill} kind="bad">Locked<//>` : null}
          </div></div>
      </div>
      <div class="hstack">
        <button class="btn" onClick=${() => setEdit({ full_name: u.full_name, mobile: u.mobile || '', email: u.email || '', branch: u.branch || '', joining_date: u.joining_date || '' })}>Edit details</button>
        <button class="btn" disabled=${busy} onClick=${resetPw}>Reset password</button>
        ${u.locked_until && new Date(u.locked_until) > new Date() ? html`<button class="btn" onClick=${() => act(() => post(`/users/${u.id}/unlock`), 'Unlocked')}>Unlock</button>` : null}
        <button class="btn" disabled=${busy || isSelf} onClick=${() => act(() => post(`/users/${u.id}/sign-out`), 'Signed out of all devices')}>Force sign-out</button>
        ${!isSelf ? html`<button class=${'btn ' + (u.is_active ? 'danger' : 'ok')} disabled=${busy}
          onClick=${() => confirm(u.is_active ? `Disable ${u.full_name}? They can no longer sign in. Their records stay.` : `Enable ${u.full_name}?`) && act(() => post(`/users/${u.id}/status`, { active: !u.is_active }), u.is_active ? 'Disabled' : 'Enabled')}>${u.is_active ? 'Disable user' : 'Enable user'}</button>` : null}
      </div>
    </div>

    <div class="row">
      ${u.role !== 'super_admin' ? html`<section class="card grow stack" aria-labelledby="sch">
        <div class="hd" style="margin:0"><div><h2 id="sch">Hourly update schedule</h2><p class="muted small" style="margin:2px 0 0">You choose the time window. The employee must post an update in every slot until you release them.</p></div>
          ${hourlyOn ? html`<${Pill} kind="warn">Active<//>` : html`<${Pill}>Not active<//>`}</div>
        <${ScheduleEditor} value=${sched} onChange=${setSched} />
        <div class="hstack" style="justify-content:space-between;border-top:1px solid var(--line-2);padding-top:14px">
          <div class="hstack">
            ${hourlyOn ? html`<button class="btn ok" disabled=${busy} onClick=${release}>Release from hourly updates</button>` : null}
            ${s && !hourlyOn ? html`<button class="btn" disabled=${busy} onClick=${reapply}>Put back on hourly schedule</button>` : null}
          </div>
          <button class="btn pri" disabled=${busy} onClick=${saveSchedule}>${hourlyOn ? 'Save schedule' : s ? 'Save & switch on' : 'Start hourly updates'}</button>
        </div>
        ${data.board ? html`<div><h3 style="margin-bottom:8px">Today</h3>
          <div class="slots" style="margin-bottom:10px">${data.board.map((b) => html`<span class=${b.status} title=${b.label + ' – ' + b.status}></span>`)}</div>
          <div class="stack">${data.board.filter((b) => ['done', 'late', 'missed', 'due'].includes(b.status)).map((b) => html`<div class="hstack small" style="justify-content:space-between;border-bottom:1px solid var(--line-2);padding-bottom:6px">
          <span><b>${b.label}</b> ${b.update ? html`<span class="muted">${b.update.activity || ''}${b.update.remarks ? ' · ' + b.update.remarks : ''}</span>` : null}</span>
          <${Pill} kind=${{ done: 'ok', late: 'warn', missed: 'bad', due: 'warn' }[b.status]}>${b.status}<//></div>`)}</div>
          <div class="small muted" style="margin-top:6px">${data.board.filter((b) => b.status === 'upcoming').length} upcoming slot(s) later today</div></div>` : null}
      </section>` : null}

      <div class="side-col stack">
        <section class="card stack" aria-labelledby="rl">
          <h2 id="rl">Switch role</h2>
          <div class="small muted">Current role: <b style="color:var(--ink)">${ROLE_LABEL[u.role]}</b></div>
          <div class="stack">${[['cso', 'DSA calling, loan calling, files login'], ['hre', 'Data mining, DSA registration, feedback calls'], ['super_admin', 'Full access to everything']].map(([r, d]) =>
            html`<button type="button" class=${'chip' + (roleForm.role === r ? ' on' : '')} style="text-align:left;display:flex;flex-direction:column" disabled=${r === u.role}
              onClick=${() => setRoleForm({ ...roleForm, role: r })}><span>${ROLE_LABEL[r]}${r === u.role ? ' (current)' : ''}</span><span class="small muted" style="font-weight:400">${d}</span></button>`)}</div>
          <${Field} label="Effective from"><input class="in" type="date" value=${roleForm.effective_from} onInput=${(e) => setRoleForm({ ...roleForm, effective_from: e.target.value })} /><//>
          <${Field} label="Reason (saved to the audit log)"><input class="in" value=${roleForm.reason} onInput=${(e) => setRoleForm({ ...roleForm, reason: e.target.value })} placeholder="e.g. moved to recruitment" /><//>
          <p class="small muted" style="margin:0">Old DSR entries stay under the old role. New entries use the new role's form.</p>
          <button class="btn pri" disabled=${busy || roleForm.role === u.role || (isSelf && roleForm.role !== 'super_admin')} onClick=${switchRole}>Change role to ${ROLE_LABEL[roleForm.role] || '…'}</button>
        </section>

        <section class="card stack">
          <h2>Contact</h2>
          <div class="small">Mobile: ${u.mobile || '—'}<br />Email: ${u.email || '—'}<br />Last sign-in: ${u.last_login_at ? fmtDateTime(u.last_login_at) + ' from ' + (u.last_login_ip || '?') : 'never'}</div>
        </section>

        <section class="card stack">
          <h2>Active sessions (${data.sessions.length})</h2>
          ${data.sessions.length ? data.sessions.map((x) => html`<div class="small"><b>${x.ip}</b> · ${fmtDateTime(x.created_at)}<div class="muted" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${x.user_agent}</div></div>`) : html`<div class="small muted">None</div>`}
        </section>

        <section class="card stack">
          <h2>History</h2>
          ${data.roleChanges.map((r) => html`<div class="small"><b>${fmtDate(r.effective_from)}</b> · ${r.old_role ? `${ROLE_LABEL[r.old_role]} → ` : ''}${ROLE_LABEL[r.new_role]}${r.reason ? ' · ' + r.reason : ''} <span class="muted">${r.changed_by_name ? 'by ' + r.changed_by_name : ''}</span></div>`)}
          ${data.history.slice(0, 15).map((h) => html`<div class="small"><b>${fmtDateTime(h.created_at)}</b> · ${h.summary} <span class="muted">${h.by_name ? 'by ' + h.by_name : ''} · ${h.ip || ''}</span></div>`)}
          <div class="hstack"><a class="small" href=${'#/dsr?user=' + u.id}>DSR history</a><a class="small" href=${'#/reports?type=employee&user=' + u.id}>Employee report</a></div>
        </section>
      </div>
    </div>

    ${edit ? html`<${Modal} title="Edit details" onClose=${() => setEdit(null)} footer=${html`<button class="btn" onClick=${() => setEdit(null)}>Cancel</button>
      <button class="btn pri" onClick=${async () => { await act(() => patch('/users/' + u.id, edit), 'Saved'); setEdit(null); }}>Save</button>`}>
      <div class="fgrid">
        ${[['full_name', 'Full name'], ['mobile', 'Mobile'], ['email', 'Email'], ['branch', 'Branch / location']].map(([k, l]) =>
          html`<${Field} label=${l}><input class="in" value=${edit[k]} onInput=${(e) => setEdit({ ...edit, [k]: e.target.value })} /><//>`)}
        <${Field} label="Joining date"><input class="in" type="date" value=${edit.joining_date} onInput=${(e) => setEdit({ ...edit, joining_date: e.target.value })} /><//>
      </div><//>` : null}
    ${pw ? html`<${TempPassword} title="New temporary password" pw=${pw} onClose=${() => setPw(null)} />` : null}`;
}
