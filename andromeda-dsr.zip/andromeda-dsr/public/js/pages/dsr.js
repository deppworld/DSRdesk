import { html, useState, useEffect, useRef, get, post, put, useData, onLive, Loading, ErrorBox, Pill, RolePill, Field,
  toast, fail, fmtTime, fmtDate, today, addDays, qs, hashQuery, navigate, ROLE_LABEL } from '../lib.js';

function FieldInput({ f, value, onChange, disabled }) {
  const common = { class: 'in', disabled, 'aria-label': f.label };
  if (f.type === 'textarea') return html`<textarea ...${common} rows="2" placeholder=${f.placeholder || ''} value=${value ?? ''} onInput=${(e) => onChange(e.target.value)}></textarea>`;
  if (f.type === 'number') return html`<input ...${common} type="number" inputmode="numeric" min="0" step="any" value=${value ?? ''} placeholder="0" onInput=${(e) => onChange(e.target.value === '' ? '' : Number(e.target.value))} />`;
  if (f.type === 'select') return html`<select ...${common} value=${value ?? ''} onChange=${(e) => onChange(e.target.value)}><option value="">—</option>${(f.options || []).map((o) => html`<option>${o}</option>`)}</select>`;
  if (f.type === 'checkbox') return html`<label class="check"><input type="checkbox" disabled=${disabled} checked=${!!value} onChange=${(e) => onChange(e.target.checked)} /> Yes</label>`;
  if (f.type === 'time' || f.type === 'date') return html`<input ...${common} type=${f.type} value=${value ?? ''} onInput=${(e) => onChange(e.target.value)} />`;
  return html`<input ...${common} value=${value ?? ''} placeholder=${f.placeholder || ''} onInput=${(e) => onChange(e.target.value)} />`;
}

export function DsrForm({ template, data, setData, disabled }) {
  return html`<div class="stack">${template.sections.map((s) => html`<section class="dsr-sec" aria-label=${s.title}>
    <div class="tm"><b>${s.title}</b><span class="muted small">${s.time || ''}</span></div>
    <div class="fs">${s.fields.map((f) => html`<label class=${'f' + (f.type === 'textarea' ? ' wide' : '')}>${f.label}${f.required ? ' *' : ''}
      <${FieldInput} f=${f} value=${data[f.key]} disabled=${disabled} onChange=${(v) => setData({ ...data, [f.key]: v })} /></label>`)}</div>
  </section>`)}</div>`;
}

function HourlyPanel({ hourly, template, onApply, disabled }) {
  if (!hourly || !hourly.updates.length) return null;
  const labels = {};
  template.sections.forEach((s) => s.fields.forEach((f) => { labels[f.key] = f.label; }));
  const totals = Object.entries(hourly.totals).filter(([k]) => labels[k]);
  return html`<div class="info stack">
    <div class="hstack" style="justify-content:space-between"><b>Hourly updates today (${hourly.updates.length})</b>
      ${totals.length && !disabled ? html`<button class="btn sm" onClick=${() => onApply(hourly.totals)}>Fill totals into DSR</button>` : null}</div>
    ${totals.length ? html`<div class="small">${totals.map(([k, v]) => `${labels[k]}: ${v}`).join(' · ')}</div>` : null}
    <div class="small muted">${hourly.updates.map((u) => `${u.slotLabel} ${u.activity || ''}${u.is_late ? ' (late)' : ''}`).join(' · ')}</div>
  </div>`;
}

function DsrEditor({ load, save, submit, title, sub, isAdmin }) {
  const { data, error, reload } = useData(load, []);
  const [vals, setVals] = useState({});
  const [saving, setSaving] = useState('');
  const dirty = useRef(false);
  const timer = useRef(null);
  useEffect(() => { if (data) { setVals((data.entry && data.entry.data) || {}); dirty.current = false; } }, [data]);
  useEffect(() => () => clearTimeout(timer.current), []);
  useEffect(() => onLive('dsr', () => { if (!dirty.current) reload(); }), []);

  const change = (v) => {
    setVals(v); dirty.current = true; setSaving('');
    clearTimeout(timer.current);
    if (!isAdmin) timer.current = setTimeout(async () => {
      try { setSaving('Saving…'); await save(v); dirty.current = false; setSaving('Saved ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })); } catch (e) { setSaving(''); fail(e); }
    }, 1800);
  };
  const doSave = async () => { clearTimeout(timer.current); try { await save(vals); dirty.current = false; toast('Saved', 'ok'); reload(); } catch (e) { fail(e); } };
  const doSubmit = async () => {
    clearTimeout(timer.current);
    try { await submit(vals); dirty.current = false; toast('DSR submitted', 'ok'); reload(); } catch (e) { fail(e); }
  };

  if (error) return html`<${ErrorBox} error=${error} />`;
  if (!data) return html`<${Loading} />`;
  if (!data.template) return html`<div class="card">This employee's role has no DSR form.</div>`;
  const e = data.entry;
  const disabled = !data.editable;
  return html`
    <div class="page-head">
      <div><h1>${title(data)}</h1>
        <p>${e && e.check_in_at ? html`Entry time <b style="color:var(--ink)">${fmtTime(e.check_in_at)}</b>` : 'Not started'}
          ${e && e.check_out_at ? html` · submitted <b style="color:var(--ink)">${fmtTime(e.check_out_at)}</b>` : ''} ${saving ? html` · <span class="muted">${saving}</span>` : ''}</p></div>
      <div class="hstack">${sub(data)}
        ${e && e.status === 'submitted' ? html`<${Pill} kind="ok">Submitted<//>` : e ? html`<${Pill} kind="warn">In progress<//>` : html`<${Pill}>No entry<//>`}</div>
    </div>
    ${disabled ? html`<div class="note small">This day is locked for editing. Ask your administrator if something needs to change.</div>` : null}
    <${HourlyPanel} hourly=${data.hourly} template=${data.template} disabled=${disabled}
      onApply=${(t) => { const v = { ...vals }; for (const [k, n] of Object.entries(t)) v[k] = n; change(v); toast('Hourly totals filled in – check and save'); }} />
    <${DsrForm} template=${data.template} data=${vals} setData=${change} disabled=${disabled} />
    ${!disabled ? html`<div class="hstack" style="justify-content:flex-end">
      <span class="muted small" style="margin-right:auto">${isAdmin ? 'You are editing as administrator – the change is logged.' : 'Changes save automatically. You can keep editing after submitting today.'}</span>
      <button class="btn" onClick=${doSave}>Save</button>
      <button class="btn pri" onClick=${doSubmit}>${e && e.status === 'submitted' ? 'Re-submit' : "Submit day's DSR"}</button></div>` : null}`;
}

export function MyDsrPage() {
  const [date, setDate] = useState(today());
  return html`<${DsrEditor} key=${date}
    load=${async () => { if (date === today()) await post('/dsr/mine/check-in').catch(() => {}); return get('/dsr/mine' + qs({ date })); }}
    save=${(v) => put('/dsr/mine' + qs({ date }), { data: v })}
    submit=${(v) => post('/dsr/mine/submit' + qs({ date }), { data: v })}
    title=${() => 'My Daily DSR'}
    sub=${() => html`<input class="in" type="date" style="width:170px" aria-label="Date" max=${today()} value=${date} onChange=${(e) => e.target.value && setDate(e.target.value)} />`} />`;
}

export function DsrAdminEdit({ uid, date }) {
  return html`<a href="#/dsr" class="small">← DSR records</a><${DsrEditor} isAdmin
    load=${() => get(`/dsr/user/${uid}/${date}`)}
    save=${(v) => put(`/dsr/user/${uid}/${date}`, { data: v })}
    submit=${(v) => put(`/dsr/user/${uid}/${date}`, { data: v, submit: true })}
    title=${(d) => `${d.user.full_name} – DSR ${fmtDate(date)}`}
    sub=${(d) => html`<${RolePill} role=${d.user.role} /><button class="btn sm" onClick=${() => navigate(`#/dsr/${uid}/${addDays(date, -1)}`)}>← Prev day</button>
      <button class="btn sm" onClick=${() => navigate(`#/dsr/${uid}/${addDays(date, 1)}`)}>Next day →</button>`} />`;
}

function keyNumbers(data) {
  const out = [];
  for (const [k, v] of Object.entries(data || {})) if (typeof v === 'number' && v) out.push(`${k.replace(/_/g, ' ')}: ${v}`);
  return out.slice(0, 5).join(' · ');
}

export function DsrAdminList() {
  const hq = hashQuery();
  const [from, setFrom] = useState(hq.user ? addDays(today(), -29) : today());
  const [to, setTo] = useState(today());
  const [role, setRole] = useState('');
  const [user, setUser] = useState(hq.user || '');
  const people = useData(() => get('/employees/basic'), []);
  const { data, error, reload } = useData(() => get('/dsr' + qs({ from, to, role, user_id: user })), [from, to, role, user]);
  useEffect(() => { let t; const off = onLive('dsr', () => { clearTimeout(t); t = setTimeout(reload, 800); }); return () => { off(); clearTimeout(t); }; }, [from, to, role, user]);
  return html`
    <div class="page-head"><div><h1>DSR Records</h1><p>Every employee's daily entries. Click a row to view or edit.</p></div></div>
    <div class="hstack">
      <${Field} label="From"><input class="in" type="date" value=${from} onChange=${(e) => setFrom(e.target.value)} /><//>
      <${Field} label="To"><input class="in" type="date" value=${to} onChange=${(e) => setTo(e.target.value)} /><//>
      <${Field} label="Team"><select class="in" value=${role} onChange=${(e) => setRole(e.target.value)}><option value="">All</option><option value="cso">CSO</option><option value="hre">HRE</option></select><//>
      <${Field} label="Employee"><select class="in" value=${user} onChange=${(e) => setUser(e.target.value)}><option value="">Everyone</option>
        ${(people.data || []).filter((p) => p.role !== 'super_admin').map((p) => html`<option value=${p.id}>${p.full_name}</option>`)}</select><//>
      <div class="f">&nbsp;<button class="btn" onClick=${() => { setFrom(today()); setTo(today()); }}>Today</button></div>
    </div>
    ${error ? html`<${ErrorBox} error=${error} />` : !data ? html`<${Loading} />` : html`
      ${data.missing.length ? html`<div class="note small"><b>Not started (${data.missing.length}):</b> ${data.missing.map((m, i) => html`${i ? ', ' : ''}<a href=${`#/dsr/${m.user_id}/${from}`}>${m.full_name}</a>`)}</div>` : null}
      <div class="tbl-wrap"><table class="tbl">
        <thead><tr><th>Date</th><th>Employee</th><th>Role</th><th>Status</th><th>Entry</th><th>Submitted</th><th>Last change</th><th>Numbers</th></tr></thead>
        <tbody>${data.rows.map((r) => html`<tr class="click" onClick=${() => navigate(`#/dsr/${r.user_id}/${r.work_date}`)}>
          <td>${fmtDate(r.work_date)}</td><td><b>${r.full_name}</b></td><td><${RolePill} role=${r.role} /></td>
          <td>${r.status === 'submitted' ? html`<${Pill} kind="ok">Submitted<//>` : html`<${Pill} kind="warn">In progress<//>`}</td>
          <td>${fmtTime(r.check_in_at)}</td><td>${fmtTime(r.check_out_at)}</td><td class="muted">${fmtTime(r.updated_at)}</td>
          <td class="wrap small muted">${keyNumbers(r.data)}</td></tr>`)}</tbody></table>
        ${!data.rows.length ? html`<div class="empty">No entries for this selection.</div>` : null}</div>`}`;
}

export { ROLE_LABEL };
