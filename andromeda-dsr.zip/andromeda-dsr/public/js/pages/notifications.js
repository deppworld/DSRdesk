import { html, get, post, useData, onLive, useEffect, Loading, ErrorBox, Pill, fmtDateTime, navigate } from '../lib.js';

const KIND = { missed: 'bad', security: 'bad', reminder: 'warn', pending: 'warn', followup: 'info', schedule: 'gray' };

export function NotificationsPage() {
  const { data, error, reload } = useData(() => get('/notifications'), []);
  useEffect(() => onLive('notification', reload), []);
  if (error) return html`<${ErrorBox} error=${error} />`;
  if (!data) return html`<${Loading} />`;
  return html`
    <div class="page-head"><div><h1>Notifications</h1><p>Follow-up reminders, missed-slot alerts and pending tasks</p></div>
      <button class="btn" onClick=${() => post('/notifications/read-all').then(reload)}>Mark all read</button></div>
    <div class="card stack">${data.rows.length ? data.rows.map((n) => html`<div class="hstack" style="justify-content:space-between;border-bottom:1px solid var(--line-2);padding-bottom:10px;cursor:pointer;${n.is_read ? '' : 'font-weight:600'}"
      onClick=${() => n.link && navigate(n.link)}>
      <div><${Pill} kind=${KIND[n.kind] || 'gray'}>${n.kind}<//> ${n.title}${n.body ? html`<div class="small muted" style="font-weight:400">${n.body}</div>` : null}</div>
      <span class="small muted nowrap">${fmtDateTime(n.created_at)}</span></div>`) : html`<div class="empty">No notifications.</div>`}</div>`;
}
