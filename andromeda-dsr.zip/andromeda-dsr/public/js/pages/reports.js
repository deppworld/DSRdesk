import { html, useState, get, download, qs, useData, Loading, ErrorBox, Field, fail, today, addDays, hashQuery } from '../lib.js';

const TYPES = [['daily', 'Daily'], ['weekly', 'Weekly'], ['monthly', 'Monthly'], ['team', 'Team (date range)'], ['employee', 'Employee (date range)']];

export function ReportsPage() {
  const hq = hashQuery();
  const [type, setType] = useState(hq.type || 'daily');
  const [date, setDate] = useState(today());
  const [from, setFrom] = useState(addDays(today(), -29));
  const [to, setTo] = useState(today());
  const [role, setRole] = useState('');
  const [user, setUser] = useState(hq.user || '');
  const people = useData(() => get('/employees/basic'), []);
  const ranged = type === 'team' || type === 'employee';
  const params = { type, role: type === 'employee' ? '' : role, user_id: type === 'employee' ? user : '', ...(ranged ? { from, to } : { date }) };
  const ready = type !== 'employee' || user;
  const { data, error } = useData(() => (ready ? get('/reports' + qs(params)) : Promise.resolve(null)), [type, date, from, to, role, user]);
  const exp = (format) => download('/reports' + qs({ ...params, format })).catch(fail);
  return html`
    <div class="page-head"><div><h1>Reports & Export</h1><p>Preview below, then download as Excel or PDF</p></div>
      <div class="hstack"><button class="btn" disabled=${!ready} onClick=${() => exp('xlsx')}>Download Excel</button><button class="btn pri" disabled=${!ready} onClick=${() => exp('pdf')}>Download PDF</button></div></div>
    <div class="card hstack" style="align-items:flex-end">
      <${Field} label="Report"><select class="in" value=${type} onChange=${(e) => setType(e.target.value)}>${TYPES.map(([v, l]) => html`<option value=${v}>${l}</option>`)}</select><//>
      ${ranged ? html`<${Field} label="From"><input class="in" type="date" value=${from} onChange=${(e) => setFrom(e.target.value)} /><//>
        <${Field} label="To"><input class="in" type="date" value=${to} onChange=${(e) => setTo(e.target.value)} /><//>`
        : html`<${Field} label=${type === 'daily' ? 'Day' : type === 'weekly' ? 'Any day in the week' : 'Any day in the month'}><input class="in" type="date" value=${date} onChange=${(e) => setDate(e.target.value)} /><//>`}
      ${type === 'employee' ? html`<${Field} label="Employee"><select class="in" value=${user} onChange=${(e) => setUser(e.target.value)}><option value="">Choose…</option>
          ${(people.data || []).filter((p) => p.role !== 'super_admin').map((p) => html`<option value=${p.id}>${p.full_name}${p.is_active ? '' : ' (disabled)'}</option>`)}</select><//>`
        : html`<${Field} label="Team"><select class="in" value=${role} onChange=${(e) => setRole(e.target.value)}><option value="">CSO + HRE</option><option value="cso">CSO only</option><option value="hre">HRE only</option></select><//>`}
    </div>
    ${!ready ? html`<div class="empty">Choose an employee.</div>` : error ? html`<${ErrorBox} error=${error} />` : !data ? html`<${Loading} />` : html`
      <h2>${data.title}</h2>
      <div class="tbl-wrap"><table class="tbl">
        <thead><tr>${data.columns.map((c) => html`<th>${c.label}</th>`)}</tr></thead>
        <tbody>${data.rows.map((r) => html`<tr>${data.columns.map((c) => html`<td class=${typeof r[c.key] === 'number' ? 'num' : c.key === 'remarks' ? 'wrap' : ''}>${typeof r[c.key] === 'number' && c.key.startsWith('amount') ? r[c.key].toLocaleString('en-IN') : r[c.key]}</td>`)}</tr>`)}
          ${data.totals ? html`<tr class="tot">${data.columns.map((c) => html`<td class=${typeof data.totals[c.key] === 'number' ? 'num' : ''}>${typeof data.totals[c.key] === 'number' && c.key.startsWith('amount') ? data.totals[c.key].toLocaleString('en-IN') : data.totals[c.key]}</td>`)}</tr>` : null}</tbody>
      </table>${!data.rows.length ? html`<div class="empty">No data.</div>` : null}</div>
      <p class="small muted">Numbers come from the DSR fields marked with a metric in the Form Builder, plus loan cases, calling lists and DSA partners added in the period. The Excel file also has a sheet with every DSR entry.</p>`}`;
}
