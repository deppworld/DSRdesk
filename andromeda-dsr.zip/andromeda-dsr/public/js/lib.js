// Shared front-end helpers: rendering, API calls, realtime, small UI components.
import { h, render, Fragment, createContext } from '/vendor/preact.mjs';
import { useState, useEffect, useRef, useMemo, useCallback, useContext } from '/vendor/hooks.mjs';
import htm from '/vendor/htm.mjs';

export const html = htm.bind(h);
export { h, render, Fragment, createContext, useState, useEffect, useRef, useMemo, useCallback, useContext };

// ---------------- API ----------------
const state = { token: null, user: null, today: null, tz: 'Asia/Kolkata', onAuthLost: null };
export const session = state;

let refreshing = null;
async function refresh() {
  if (!refreshing) {
    refreshing = fetch('/api/auth/refresh', { method: 'POST', credentials: 'same-origin' })
      .then(async (r) => {
        if (!r.ok) throw new Error('expired');
        const j = await r.json();
        if (!j.accessToken) throw new Error('not signed in');
        state.token = j.accessToken; state.user = j.user; state.today = j.today; state.tz = j.timezone;
        return j;
      })
      .finally(() => { setTimeout(() => { refreshing = null; }, 0); });
  }
  return refreshing;
}
export { refresh };

export async function api(method, path, body, opts = {}) {
  const doFetch = () => fetch('/api' + path, {
    method,
    credentials: 'same-origin',
    headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(state.token ? { Authorization: 'Bearer ' + state.token } : {}) },
    body: body !== undefined ? JSON.stringify(body) : undefined
  });
  let r = await doFetch();
  if (r.status === 401 && !path.startsWith('/auth/login')) {
    try { await refresh(); r = await doFetch(); } catch { if (state.onAuthLost) state.onAuthLost(); throw new Error('Your session ended. Please sign in again.'); }
  }
  if (opts.raw) return r;
  let j = null;
  try { j = await r.json(); } catch { /* empty */ }
  if (!r.ok) {
    const e = new Error((j && j.error) || `Request failed (${r.status})`);
    e.status = r.status;
    if (r.status === 401 && state.onAuthLost) state.onAuthLost();
    throw e;
  }
  return j;
}
export const get = (p) => api('GET', p);
export const post = (p, b = {}) => api('POST', p, b);
export const put = (p, b = {}) => api('PUT', p, b);
export const patch = (p, b = {}) => api('PATCH', p, b);
export const del = (p) => api('DELETE', p);

// Download a file (Excel/PDF) using the auth header.
export async function download(path) {
  const r = await api('GET', path, undefined, { raw: true });
  if (!r.ok) { let m = 'Download failed'; try { m = (await r.json()).error; } catch { /* */ } throw new Error(m); }
  const cd = r.headers.get('Content-Disposition') || '';
  const name = (cd.match(/filename="([^"]+)"/) || [])[1] || 'download';
  const blob = await r.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

export const qs = (o) => {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(o)) if (v !== undefined && v !== null && v !== '') p.set(k, v);
  const s = p.toString();
  return s ? '?' + s : '';
};

// ---------------- realtime ----------------
const listeners = new Map();
let socket = null;
export function connectSocket(onStatus) {
  if (socket) socket.disconnect();
  // eslint-disable-next-line no-undef
  socket = io({ auth: (cb) => cb({ token: state.token }), transports: ['websocket', 'polling'] });
  socket.on('connect', () => onStatus && onStatus(true));
  socket.on('disconnect', () => onStatus && onStatus(false));
  socket.on('connect_error', async (e) => {
    onStatus && onStatus(false);
    if (e.message === 'unauthorized') { try { await refresh(); socket.connect(); } catch { if (state.onAuthLost) state.onAuthLost(); } }
  });
  socket.onAny((event, payload) => (listeners.get(event) || []).forEach((fn) => fn(payload)));
  return socket;
}
export function disconnectSocket() { if (socket) { socket.disconnect(); socket = null; } }
export function useLive(event, fn, deps = []) {
  useEffect(() => {
    const arr = listeners.get(event) || [];
    arr.push(fn); listeners.set(event, arr);
    return () => listeners.set(event, (listeners.get(event) || []).filter((x) => x !== fn));
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
}
export function onLive(event, fn) {
  const arr = listeners.get(event) || []; arr.push(fn); listeners.set(event, arr);
  return () => listeners.set(event, (listeners.get(event) || []).filter((x) => x !== fn));
}

// ---------------- formatting ----------------
export const ROLE_LABEL = { super_admin: 'Super Admin', cso: 'CSO', hre: 'HRE' };
export const fmtTime = (ts) => (ts ? new Date(ts).toLocaleTimeString('en-IN', { timeZone: state.tz, hour: '2-digit', minute: '2-digit' }) : '');
export const fmtDateTime = (ts) => (ts ? new Date(ts).toLocaleString('en-IN', { timeZone: state.tz, day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '');
export const fmtDate = (d) => { if (!d) return ''; const x = new Date(d.length === 10 ? d + 'T00:00:00Z' : d); return x.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', timeZone: d.length === 10 ? 'UTC' : state.tz }); };
export const money = (n) => (n === null || n === undefined || n === '' ? '' : '₹' + Number(n).toLocaleString('en-IN', { maximumFractionDigits: 0 }));
export const num = (n) => (n === null || n === undefined ? '0' : Number(n).toLocaleString('en-IN'));
export function ago(ts) {
  const s = Math.max(0, (Date.now() - new Date(ts).getTime()) / 1000);
  if (s < 45) return 'now';
  if (s < 3600) return Math.round(s / 60) + 'm';
  if (s < 86400) return Math.round(s / 3600) + 'h';
  return Math.round(s / 86400) + 'd';
}
export const today = () => state.today || new Date().toISOString().slice(0, 10);
export function addDays(d, n) { const x = new Date(d + 'T00:00:00Z'); x.setUTCDate(x.getUTCDate() + n); return x.toISOString().slice(0, 10); }
export const minToHHMM = (m) => (m === null || m === undefined ? '' : String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0'));

// ---------------- toasts ----------------
let toastSetter = null;
export function toast(msg, kind = '') {
  if (!toastSetter) return;
  const id = Math.random();
  toastSetter((t) => [...t, { id, msg, kind }]);
  setTimeout(() => toastSetter((t) => t.filter((x) => x.id !== id)), kind === 'bad' ? 6000 : 3500);
}
export function Toasts() {
  const [items, set] = useState([]);
  toastSetter = set;
  return html`<div class="toasts" role="status" aria-live="polite">${items.map((t) => html`<div class=${'toast ' + t.kind} key=${t.id}>${t.msg}</div>`)}</div>`;
}
export const fail = (e) => toast(e.message || String(e), 'bad');

// ---------------- components ----------------
export function Modal({ title, onClose, children, footer, wide }) {
  useEffect(() => {
    const k = (e) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', k);
    return () => document.removeEventListener('keydown', k);
  }, []);
  return html`<div class="overlay" onMouseDown=${(e) => { if (e.target === e.currentTarget) onClose(); }}>
    <div class=${'modal' + (wide ? ' wide' : '')} role="dialog" aria-modal="true" aria-label=${title}>
      <div class="mh"><h2>${title}</h2><button class="iconbtn" aria-label="Close" onClick=${onClose}>${Icon('x')}</button></div>
      <div class="mb">${children}</div>
      ${footer ? html`<div class="mf">${footer}</div>` : null}
    </div></div>`;
}

export function Field({ label, children, wide, hint }) {
  return html`<label class=${'f' + (wide ? ' wide' : '')} style=${wide ? 'grid-column:1/-1' : ''}>${label}${children}${hint ? html`<span class="muted small" style="font-weight:400">${hint}</span>` : null}</label>`;
}

export function Pill({ kind = 'gray', children }) { return html`<span class=${'pill p-' + kind}>${children}</span>`; }

export function RolePill({ role }) {
  return html`<${Pill} kind=${role === 'cso' ? 'info' : role === 'hre' ? 'warn' : 'gray'}>${ROLE_LABEL[role] || role}<//>`;
}

export function loanStatusKind(s, groups) {
  if (!s) return 'gray';
  if (groups && (groups.rejected || []).includes(s)) return 'bad';
  if (groups && (groups.approved || []).includes(s)) return 'ok';
  if (/reject/i.test(s)) return 'bad';
  if (/sanction|disburs|approv/i.test(s)) return 'ok';
  if (/hold/i.test(s)) return 'gray';
  return 'warn';
}

export function Loading() { return html`<div class="empty">Loading…</div>`; }
export function Empty({ children }) { return html`<div class="empty">${children || 'Nothing here yet.'}</div>`; }

// Inline stroke icons (no external icon font needed)
const ICONS = {
  x: 'M6 6l12 12M18 6L6 18',
  bell: 'M6 8a6 6 0 1112 0c0 7 3 9 3 9H3s3-2 3-9M10 21a2 2 0 004 0',
  menu: 'M4 6h16M4 12h16M4 18h16',
  home: 'M3 11l9-8 9 8M5 10v10h14V10',
  users: 'M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2M9 11a4 4 0 100-8 4 4 0 000 8M22 21v-2a4 4 0 00-3-3.9M16 3.1a4 4 0 010 7.8',
  file: 'M14 3H6a2 2 0 00-2 2v14a2 2 0 002 2h12a2 2 0 002-2V9zM14 3v6h6M8 13h8M8 17h6',
  clock: 'M12 22a10 10 0 100-20 10 10 0 000 20M12 6v6l4 2',
  briefcase: 'M3 7h18v13H3zM8 7V4h8v3',
  phone: 'M22 16.9v3a2 2 0 01-2.2 2 19.8 19.8 0 01-8.6-3.1 19.5 19.5 0 01-6-6A19.8 19.8 0 012.1 4.2 2 2 0 014.1 2h3a2 2 0 012 1.7c.1 1 .4 1.9.7 2.8a2 2 0 01-.5 2.1L8 9.9a16 16 0 006 6l1.3-1.3a2 2 0 012.1-.4c.9.3 1.8.6 2.8.7a2 2 0 011.7 2z',
  handshake: 'M12 21l-8-8 4-4 4 4 4-4 4 4zM8 9l4-4 4 4',
  chart: 'M3 3v18h18M7 15l4-4 4 4 5-6',
  shield: 'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z',
  form: 'M4 4h16v16H4zM8 9h8M8 13h8M8 17h4',
  gear: 'M12 15a3 3 0 100-6 3 3 0 000 6zM19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9a1.7 1.7 0 001.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z',
  logout: 'M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9',
  plus: 'M12 5v14M5 12h14',
  download: 'M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3',
  key: 'M21 2l-2 2m-7.6 7.6a5.5 5.5 0 11-7.8 7.8 5.5 5.5 0 017.8-7.8zM15.5 7.5l3 3L22 7l-3-3'
};
export function Icon(name, size = 18) {
  return html`<svg width=${size} height=${size} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d=${ICONS[name] || ''} /></svg>`;
}

// Generic async data hook
export function useData(loader, deps = []) {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [n, setN] = useState(0);
  useEffect(() => {
    let alive = true;
    setError(null);
    loader().then((d) => { if (alive) setData(d); }).catch((e) => { if (alive) setError(e); });
    return () => { alive = false; };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, n]);
  return { data, error, reload: () => setN((x) => x + 1), setData };
}

export function ErrorBox({ error }) { return error ? html`<div class="err">${error.message || String(error)}</div>` : null; }

// Shared settings (status lists etc.), loaded once after sign-in.
export const shared = { settings: null };
export async function loadSettings() { shared.settings = await get('/settings'); return shared.settings; }

export function hashQuery() { return Object.fromEntries(new URLSearchParams((location.hash.split('?')[1]) || '')); }

export function navigate(hash) { if (location.hash !== hash) location.hash = hash; }
