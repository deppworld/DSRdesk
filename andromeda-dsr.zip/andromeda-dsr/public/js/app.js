// App shell: sign-in state, role-based menu, router, notifications bell, live connection.
import { html, render, useState, useEffect, session, api, get, post, refresh, connectSocket, disconnectSocket, onLive,
  Toasts, toast, Icon, ROLE_LABEL, loadSettings, ago, navigate } from './lib.js';
import { LoginPage, ChangePasswordPage } from './pages/auth.js';
import { DashboardPage } from './pages/dashboard.js';
import { EmployeesPage } from './pages/employees.js';
import { ProfilePage } from './pages/profile.js';
import { MyDsrPage, DsrAdminList, DsrAdminEdit } from './pages/dsr.js';
import { HourlyPage } from './pages/hourly.js';
import { RecordsPage } from './pages/records.js';
import { ReportsPage } from './pages/reports.js';
import { AuditPage } from './pages/audit.js';
import { FormsPage } from './pages/forms.js';
import { SettingsPage } from './pages/settings.js';
import { NotificationsPage } from './pages/notifications.js';

function useHash() {
  const [hash, setHash] = useState(location.hash || '');
  useEffect(() => {
    const f = () => setHash(location.hash || '');
    window.addEventListener('hashchange', f);
    return () => window.removeEventListener('hashchange', f);
  }, []);
  return hash;
}

function menuFor(user, hasHourly) {
  if (user.role === 'super_admin') {
    return [
      { grp: 'Overview' },
      { href: '#/dashboard', label: 'Dashboard', icon: 'home' },
      { href: '#/dsr', label: 'DSR Records', icon: 'file' },
      { grp: 'Team' },
      { href: '#/employees', label: 'Employees & Schedules', icon: 'users' },
      { grp: 'Business' },
      { href: '#/loans', label: 'Loan Cases', icon: 'briefcase' },
      { href: '#/contacts', label: 'Calling Lists', icon: 'phone' },
      { href: '#/dsa', label: 'DSA Partners', icon: 'handshake' },
      { grp: 'Management' },
      { href: '#/reports', label: 'Reports & Export', icon: 'chart' },
      { href: '#/audit', label: 'Audit Log', icon: 'shield' },
      { href: '#/forms', label: 'Form Builder', icon: 'form' },
      { href: '#/settings', label: 'Settings & Backup', icon: 'gear' }
    ];
  }
  return [
    ...(hasHourly ? [{ href: '#/hourly', label: 'Hourly Updates', icon: 'clock' }] : []),
    { href: '#/my-dsr', label: 'My Daily DSR', icon: 'file' },
    { href: '#/loans', label: 'My Loan Cases', icon: 'briefcase' },
    { href: '#/contacts', label: 'My Calling Lists', icon: 'phone' },
    { href: '#/dsa', label: 'My DSA Partners', icon: 'handshake' },
    { href: '#/notifications', label: 'Notifications', icon: 'bell' },
    { href: '#/account', label: 'Change Password', icon: 'key' }
  ];
}

function Bell() {
  const [data, setData] = useState({ rows: [], unread: 0 });
  const [open, setOpen] = useState(false);
  const load = () => get('/notifications').then(setData).catch(() => {});
  useEffect(() => {
    load();
    return onLive('notification', (n) => {
      setData((d) => ({ rows: [n, ...d.rows].slice(0, 60), unread: d.unread + 1 }));
      toast(n.title, n.kind === 'missed' || n.kind === 'security' ? 'bad' : '');
    });
  }, []);
  const openIt = async () => {
    setOpen(!open);
    if (!open && data.unread) { await post('/notifications/read-all'); setData((d) => ({ ...d, unread: 0 })); }
  };
  return html`<div style="position:relative">
    <button class="iconbtn" aria-label=${`Notifications, ${data.unread} unread`} onClick=${openIt}>${Icon('bell', 20)}${data.unread ? html`<span class="badge">${data.unread > 99 ? '99+' : data.unread}</span>` : null}</button>
    ${open ? html`<div class="dropdown" onMouseLeave=${() => setOpen(false)}>
      <div class="hstack" style="justify-content:space-between;padding:10px 14px;border-bottom:1px solid var(--line)"><b>Notifications</b><a href="#/notifications" onClick=${() => setOpen(false)}>See all</a></div>
      ${data.rows.length ? data.rows.slice(0, 15).map((n) => html`<div class=${'n' + (n.is_read ? '' : ' unread')} onClick=${() => { setOpen(false); if (n.link) navigate(n.link); }}>
        <b>${n.title}</b>${n.body ? html`<span class="muted">${n.body}</span>` : null}<div class="muted small">${ago(n.created_at)} ago</div></div>`) : html`<div class="empty">No notifications</div>`}
    </div>` : null}
  </div>`;
}

function Shell({ user, children, hasHourly, onLogout, live }) {
  const hash = useHash();
  const [open, setOpen] = useState(false);
  const items = menuFor(user, hasHourly);
  const active = (href) => { const hp = hash.split('?')[0]; return hp === href || hp.startsWith(href + '/'); };
  return html`<div class="shell">
    <aside class=${'side' + (open ? ' open' : '')}>
      <div class="logo"><img src="/img/logo-full.png" alt="Andromeda – India's Largest Loan Distributor" /></div>
      <nav aria-label="Main">${items.map((it) => it.grp
        ? html`<div class="grp">${it.grp}</div>`
        : html`<a href=${it.href} class=${active(it.href) ? 'on' : ''} onClick=${() => setOpen(false)}>${Icon(it.icon)} ${it.label}</a>`)}</nav>
      <div class="me"><b>${user.full_name}</b>${ROLE_LABEL[user.role]} · ${user.emp_code}
        <div style="margin-top:8px"><button class="btn sm" onClick=${onLogout}>${Icon('logout', 15)} Sign out</button></div></div>
    </aside>
    <div class="main">
      <header class="top">
        <button class="iconbtn burger" aria-label="Menu" onClick=${() => setOpen(!open)}>${Icon('menu')}</button>
        <span class=${'small ' + (live ? 'live' : 'live off')} title="Real-time connection">● ${live ? 'Live' : 'Reconnecting…'}</span>
        <span class="spacer"></span>
        <${Bell} />
      </header>
      <main class="content">${children}</main>
    </div>
  </div>`;
}

function route(hash, user) {
  const parts = hash.replace(/^#\/?/, '').split('?')[0].split('/');
  const p = parts[0] || '';
  const admin = user.role === 'super_admin';
  if (admin) {
    switch (p) {
      case 'dashboard': return html`<${DashboardPage} />`;
      case 'employees': return parts[1] ? html`<${ProfilePage} id=${parts[1]} key=${parts[1]} />` : html`<${EmployeesPage} />`;
      case 'dsr': return parts[1] ? html`<${DsrAdminEdit} uid=${parts[1]} date=${parts[2]} key=${parts[1] + parts[2]} />` : html`<${DsrAdminList} />`;
      case 'loans': return html`<${RecordsPage} kind="loans" key="loans" />`;
      case 'contacts': return html`<${RecordsPage} kind="contacts" key="contacts" />`;
      case 'dsa': return html`<${RecordsPage} kind="dsa" key="dsa" />`;
      case 'reports': return html`<${ReportsPage} />`;
      case 'audit': return html`<${AuditPage} />`;
      case 'forms': return html`<${FormsPage} />`;
      case 'settings': return html`<${SettingsPage} />`;
      case 'notifications': return html`<${NotificationsPage} />`;
      case 'account': return html`<${ChangePasswordPage} />`;
      default: navigate('#/dashboard'); return null;
    }
  }
  switch (p) {
    case 'my-dsr': return html`<${MyDsrPage} />`;
    case 'hourly': return html`<${HourlyPage} />`;
    case 'loans': return html`<${RecordsPage} kind="loans" key="loans" />`;
    case 'contacts': return html`<${RecordsPage} kind="contacts" key="contacts" />`;
    case 'dsa': return html`<${RecordsPage} kind="dsa" key="dsa" />`;
    case 'notifications': return html`<${NotificationsPage} />`;
    case 'account': return html`<${ChangePasswordPage} />`;
    default: navigate('#/my-dsr'); return null;
  }
}

function App() {
  const [phase, setPhase] = useState('boot'); // boot | login | change | app
  const [user, setUser] = useState(null);
  const [hasHourly, setHasHourly] = useState(false);
  const [live, setLive] = useState(false);
  const hash = useHash();

  const startSession = async () => {
    const u = session.user;
    setUser(u);
    if (u.must_change_password) { setPhase('change'); return; }
    await loadSettings().catch(() => {});
    if (u.role !== 'super_admin') {
      try { const hr = await get('/hourly/mine'); setHasHourly(!!(hr.schedule && !hr.released)); } catch { /* */ }
    }
    connectSocket(setLive);
    setPhase('app');
  };

  useEffect(() => {
    session.onAuthLost = () => { disconnectSocket(); session.token = null; setPhase('login'); };
    refresh().then(startSession).catch(() => setPhase('login'));
    const offs = [
      onLive('force-logout', () => { toast('You were signed out by an administrator.', 'bad'); session.onAuthLost(); }),
      onLive('schedule', async () => {
        try { const hr = await get('/hourly/mine'); setHasHourly(!!(hr.schedule && !hr.released)); } catch { /* */ }
      })
    ];
    return () => offs.forEach((f) => f());
  }, []);

  const logout = async () => {
    await api('POST', '/auth/logout').catch(() => {});
    disconnectSocket(); session.token = null; session.user = null;
    setPhase('login'); location.hash = '';
  };

  if (phase === 'boot') return html`<div class="empty">Loading…</div>`;
  if (phase === 'login') return html`<${LoginPage} onDone=${startSession} /><${Toasts} />`;
  if (phase === 'change') return html`<${ChangePasswordPage} forced onDone=${startSession} onLogout=${logout} /><${Toasts} />`;
  return html`<${Shell} user=${user} hasHourly=${hasHourly} onLogout=${logout} live=${live}>${route(hash, user)}<//><${Toasts} />`;
}

render(html`<${App} />`, document.getElementById('app'));
