// Authentication (JWT access token in the Authorization header) and role checks.
// The user row is re-read on every request so disabling a user or changing their role takes effect immediately.
const jwt = require('jsonwebtoken');
const config = require('../config');
const db = require('../db/pool');

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

async function authenticate(req, res, next) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (!token) return next(new HttpError(401, 'Not signed in'));
  let p;
  try { p = jwt.verify(token, config.jwtAccessSecret); } catch { return next(new HttpError(401, 'Session expired')); }
  const u = await db.one(
    `SELECT id, emp_code, full_name, username, role, branch, is_active, token_version, must_change_password
     FROM users WHERE id=$1`, [p.sub]);
  if (!u || !u.is_active || u.token_version !== p.tv) return next(new HttpError(401, 'Session ended'));
  req.user = u;
  // Until the temporary password is changed, only account endpoints are usable.
  if (u.must_change_password && !req.originalUrl.startsWith('/api/auth/')) {
    return next(new HttpError(403, 'Please change your temporary password first'));
  }
  next();
}

const isAdmin = (req) => req.user && req.user.role === 'super_admin';

function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) return next(new HttpError(403, 'You do not have access to this'));
    next();
  };
}

const requireAdmin = requireRole('super_admin');

module.exports = { authenticate, requireRole, requireAdmin, isAdmin, HttpError };
