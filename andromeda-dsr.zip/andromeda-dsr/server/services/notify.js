// In-app notifications (stored + pushed live) and the audit trail.
const db = require('../db/pool');
const rt = require('./realtime');

async function notify(userId, kind, title, body = '', link = '') {
  const n = await db.one(
    'INSERT INTO notifications(user_id, kind, title, body, link) VALUES ($1,$2,$3,$4,$5) RETURNING *',
    [userId, kind, title, body, link]);
  rt.emitUser(userId, 'notification', n);
  return n;
}

async function notifyAdmins(kind, title, body = '', link = '') {
  const admins = await db.many("SELECT id FROM users WHERE role='super_admin' AND is_active");
  for (const a of admins) await notify(a.id, kind, title, body, link);
}

// Sends an alert only once per key (e.g. "missed:12:2026-11-19:660").
async function once(key) {
  const r = await db.query('INSERT INTO sent_alerts(key) VALUES ($1) ON CONFLICT DO NOTHING', [key]);
  return r.rowCount === 1;
}

function clientIp(req) {
  const ip = req.ip || (req.socket && req.socket.remoteAddress) || '';
  return ip.replace(/^::ffff:/, '');
}

async function audit(req, action, entity, entityId, summary, before = null, after = null, userIdOverride) {
  try {
    await db.query(
      `INSERT INTO audit_logs(user_id, action, entity, entity_id, summary, ip, user_agent, before_data, after_data)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
      [userIdOverride !== undefined ? userIdOverride : (req.user ? req.user.id : null), action, entity,
        entityId === null || entityId === undefined ? null : String(entityId), summary,
        req ? clientIp(req) : null, req ? String(req.headers['user-agent'] || '').slice(0, 300) : null,
        before ? JSON.stringify(strip(before)) : null, after ? JSON.stringify(strip(after)) : null]);
  } catch (e) {
    console.error('[audit] failed', e.message);
  }
}

function strip(o) {
  const c = { ...o };
  delete c.password_hash; delete c.pan_enc; delete c.token_hash;
  return c;
}

module.exports = { notify, notifyAdmins, once, audit, clientIp };
