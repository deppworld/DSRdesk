// Numbers for the management dashboard and reports.
const db = require('../db/pool');
const time = require('./time');
const sched = require('./schedule');
const settings = require('./settings');

const METRICS = ['calls', 'interested', 'converted', 'connects', 'kits', 'files_login', 'meetings', 'mined', 'registrations'];
const METRIC_LABELS = { calls: 'Calls', interested: 'Interested', converted: 'Converted', connects: 'DSA connects', kits: 'DSA kits',
  files_login: 'Files login', meetings: 'DSA meetings', mined: 'Data mined', registrations: 'DSA registrations' };

function periodRange(period, from, to) {
  const t = time.today();
  if (from && to && time.isDate(from) && time.isDate(to)) return { from, to };
  if (period === 'week') { const wd = time.weekdayOf(t); return { from: time.addDays(t, -((wd + 6) % 7)), to: t }; }
  if (period === 'month') return { from: t.slice(0, 8) + '01', to: t };
  if (period === 'last7') return { from: time.addDays(t, -6), to: t };
  if (period === 'last30') return { from: time.addDays(t, -29), to: t };
  return { from: t, to: t };
}

async function metricMap() {
  const tpls = await db.many('SELECT id, sections FROM form_templates');
  const m = {};
  for (const t of tpls) {
    m[t.id] = {};
    for (const s of t.sections) for (const f of s.fields) if (f.metric) m[t.id][f.key] = f.metric;
  }
  return m;
}

function blankMetrics() { return Object.fromEntries(METRICS.map((k) => [k, 0])); }

async function statusGroups() {
  const g = (await settings.get('loan_status_groups')) || {};
  return { approved: g.approved || [], rejected: g.rejected || [], converted: g.converted || [] };
}

// Per-employee totals between two dates (inclusive).
async function employeeTotals(from, to, { role, userId } = {}) {
  const params = []; let w = "u.role IN ('cso','hre')";
  if (role) { params.push(role); w += ` AND u.role=$${params.length}`; }
  if (userId) { params.push(userId); w += ` AND u.id=$${params.length}`; }
  const users = await db.many(`SELECT id, emp_code, full_name, role, is_active FROM users u WHERE ${w} ORDER BY role, full_name`, params);
  const ids = users.map((u) => u.id);
  if (!ids.length) return [];
  const map = await metricMap();
  const groups = await statusGroups();
  const rows = Object.fromEntries(users.map((u) => [u.id, {
    ...u, days_started: 0, dsr_submitted: 0, metrics: blankMetrics(),
    loans: 0, approved: 0, rejected: 0, pending: 0, converted: 0, amount_logged: 0, amount_approved: 0,
    contacts: 0, dsa_added: 0, hourly_done: 0, hourly_late: 0, hourly_missed: 0, first_check_in: null
  }]));

  const entries = await db.many('SELECT user_id, template_id, data, status, check_in_at FROM dsr_entries WHERE user_id = ANY($1) AND work_date BETWEEN $2 AND $3', [ids, from, to]);
  for (const e of entries) {
    const r = rows[e.user_id];
    r.days_started++;
    if (e.status === 'submitted') r.dsr_submitted++;
    const mm = map[e.template_id] || {};
    for (const [k, metric] of Object.entries(mm)) if (typeof e.data[k] === 'number') r.metrics[metric] += e.data[k];
    if (e.check_in_at && (!r.first_check_in || e.check_in_at < r.first_check_in)) r.first_check_in = e.check_in_at;
  }
  const loans = await db.many('SELECT owner_id, status, loan_amount FROM loan_cases WHERE owner_id = ANY($1) AND case_date BETWEEN $2 AND $3', [ids, from, to]);
  for (const l of loans) {
    const r = rows[l.owner_id];
    r.loans++; r.amount_logged += l.loan_amount || 0;
    if (groups.approved.includes(l.status)) { r.approved++; r.amount_approved += l.loan_amount || 0; }
    else if (groups.rejected.includes(l.status)) r.rejected++;
    else r.pending++;
    if (groups.converted.includes(l.status)) r.converted++;
  }
  for (const c of await db.many('SELECT owner_id, count(*)::int AS n FROM contacts WHERE owner_id = ANY($1) AND contact_date BETWEEN $2 AND $3 GROUP BY owner_id', [ids, from, to])) rows[c.owner_id].contacts = c.n;
  for (const c of await db.many('SELECT owner_id, count(*)::int AS n FROM dsa_partners WHERE owner_id = ANY($1) AND onboard_date BETWEEN $2 AND $3 GROUP BY owner_id', [ids, from, to])) rows[c.owner_id].dsa_added = c.n;

  // hourly compliance (uses each person's current schedule)
  const scheds = await db.many('SELECT * FROM hourly_schedules WHERE user_id = ANY($1)', [ids]);
  const ups = await db.many('SELECT user_id, work_date, slot_min, is_late FROM hourly_updates WHERE user_id = ANY($1) AND work_date BETWEEN $2 AND $3', [ids, from, to]);
  for (const s of scheds) {
    const mine = ups.filter((u) => u.user_id === s.user_id);
    for (let d = from; d <= to; d = time.addDays(d, 1)) {
      const relDate = s.released_at ? time.nowParts(new Date(s.released_at)).date : null;
      if (!s.enabled || (relDate && d >= relDate) || (s.until_date && d > s.until_date) || !(s.days || []).includes(time.weekdayOf(d))) continue;
      const board = sched.slotBoard({ ...s, released_at: null }, d, mine.filter((u) => u.work_date === d));
      for (const b of board) {
        if (b.status === 'done') rows[s.user_id].hourly_done++;
        else if (b.status === 'late') rows[s.user_id].hourly_late++;
        else if (b.status === 'missed') rows[s.user_id].hourly_missed++;
      }
    }
  }
  return Object.values(rows).map((r) => ({
    ...r,
    conversion: r.loans ? Math.round((r.converted / r.loans) * 1000) / 10 : 0,
    interest_rate: r.metrics.calls ? Math.round(((r.metrics.interested + r.metrics.converted) / r.metrics.calls) * 1000) / 10 : 0
  }));
}

async function dashboard(period, role, from, to) {
  const range = periodRange(period, from, to);
  const t = time.today();
  const emp = await employeeTotals(range.from, range.to, { role });
  const sum = (k) => emp.reduce((a, r) => a + (k.includes('.') ? r.metrics[k.split('.')[1]] : r[k]), 0);
  const groups = await statusGroups();
  const roleSql = role ? ' AND u.role = $3' : '';
  const rp = role ? [range.from, range.to, role] : [range.from, range.to];

  const openPipeline = (await db.one(
    `SELECT count(*)::int AS n FROM loan_cases l JOIN users u ON u.id=l.owner_id WHERE NOT (l.status = ANY($1)) AND NOT (l.status = ANY($2))${role ? ' AND u.role=$3' : ''}`,
    role ? [groups.approved, groups.rejected, role] : [groups.approved, groups.rejected])).n;

  const tz = require('../config').timezone;
  const activityCount = (await db.one(
    `SELECT count(*)::int AS n FROM audit_logs a JOIN users u ON u.id=a.user_id
     WHERE a.created_at >= ($1::date::timestamp AT TIME ZONE $3) AND a.created_at < (($2::date + 1)::timestamp AT TIME ZONE $3)
       AND a.action IN ('create','update','dsr_saved','dsr_submitted','hourly_submitted','check_in')${role ? ' AND u.role=$4' : ''}`,
    role ? [range.from, range.to, tz, role] : [range.from, range.to, tz])).n;

  // Last 14 days activity by role
  const start14 = time.addDays(t, -13);
  const series = await db.many(
    `SELECT to_char((a.created_at AT TIME ZONE $3)::date, 'YYYY-MM-DD') AS d, u.role, count(*)::int AS n
     FROM audit_logs a JOIN users u ON u.id=a.user_id
     WHERE a.created_at >= ($1::date::timestamp AT TIME ZONE $3) AND a.created_at < (($2::date + 1)::timestamp AT TIME ZONE $3)
       AND a.action IN ('create','update','dsr_saved','dsr_submitted','hourly_submitted','check_in')
     GROUP BY 1,2`, [start14, t, tz]);
  const days = []; for (let d = start14; d <= t; d = time.addDays(d, 1)) days.push(d);
  const pick = (d, r) => (series.find((s) => s.d === d && s.role === r) || { n: 0 }).n;

  const statusSplit = await db.many(
    `SELECT l.status, count(*)::int AS n FROM loan_cases l JOIN users u ON u.id=l.owner_id
     WHERE l.case_date BETWEEN $1 AND $2${roleSql} GROUP BY l.status ORDER BY l.status`, rp);

  // Today's status per employee
  const todayRows = await db.many(
    `SELECT u.id, d.status, d.check_in_at, d.check_out_at FROM users u LEFT JOIN dsr_entries d ON d.user_id=u.id AND d.work_date=$1
     WHERE u.role IN ('cso','hre') AND u.is_active`, [t]);
  const todayMap = Object.fromEntries(todayRows.map((r) => [r.id, r]));

  // Hourly schedule people today
  const scheds = await db.many(
    `SELECT s.*, u.full_name, u.role FROM hourly_schedules s JOIN users u ON u.id=s.user_id
     WHERE u.is_active AND s.enabled AND s.released_at IS NULL${role ? ' AND u.role=$1' : ''} ORDER BY u.full_name`, role ? [role] : []);
  const hourly = [];
  for (const s of scheds) {
    const ups = await db.many('SELECT slot_min, is_late FROM hourly_updates WHERE user_id=$1 AND work_date=$2', [s.user_id, t]);
    const joined = await db.one('SELECT joining_date FROM users WHERE id=$1', [s.user_id]);
    hourly.push({ userId: s.user_id, name: s.full_name, role: s.role,
      window: `${time.fmtMin(s.start_min)} – ${time.fmtMin(s.end_min)} · every ${s.interval_min} min`,
      day: joined.joining_date ? Math.max(1, Math.round((Date.parse(t) - Date.parse(joined.joining_date)) / 864e5) + 1) : null,
      activeToday: sched.isActiveOn(s, t),
      board: sched.isActiveOn(s, t) ? sched.slotBoard(s, t, ups).map((b) => ({ label: b.label, status: b.status })) : [] });
  }

  const followups = await db.many(
    `SELECT 'loan' AS kind, l.id, l.customer_name AS name, l.product AS detail, l.next_follow_up, u.full_name AS owner
       FROM loan_cases l JOIN users u ON u.id=l.owner_id
       WHERE l.next_follow_up <= $1 AND NOT (l.status = ANY($2)) AND NOT (l.status = ANY($3))
     UNION ALL
     SELECT 'contact', c.id, c.name, c.status, c.next_follow_up, u.full_name FROM contacts c JOIN users u ON u.id=c.owner_id
       WHERE c.next_follow_up <= $1
     ORDER BY next_follow_up DESC LIMIT 12`, [t, groups.approved, groups.rejected]);

  const security = await db.one(
    `SELECT (SELECT count(*)::int FROM refresh_tokens WHERE revoked_at IS NULL AND expires_at > now()) AS sessions,
            (SELECT count(*)::int FROM audit_logs WHERE action='login_failed' AND created_at > now() - interval '24 hours') AS failed,
            (SELECT count(*)::int FROM users WHERE locked_until > now()) AS locked,
            (SELECT count(*)::int FROM audit_logs WHERE action='access_denied' AND created_at > now() - interval '24 hours') AS denied`);

  const recent = await db.many(
    `SELECT a.created_at AS at, a.summary AS text, u.full_name AS name, u.role, a.action FROM audit_logs a JOIN users u ON u.id=a.user_id
     WHERE a.action NOT IN ('login_failed','reveal_sensitive','export') ORDER BY a.created_at DESC LIMIT 25`);

  const loansTotal = sum('loans');
  return {
    range, period,
    kpis: {
      totalLeads: loansTotal + sum('contacts'),
      loans: loansTotal,
      contacts: sum('contacts'),
      activity: activityCount,
      pending: sum('pending'), openPipeline,
      approved: sum('approved'), rejected: sum('rejected'), converted: sum('converted'),
      amountApproved: sum('amount_approved'), amountLogged: sum('amount_logged'),
      conversion: loansTotal ? Math.round((sum('converted') / loansTotal) * 1000) / 10 : 0,
      calls: sum('metrics.calls'), interested: sum('metrics.interested') + sum('metrics.converted'),
      dsrSubmittedToday: todayRows.filter((r) => r.status === 'submitted').length, activeEmployees: todayRows.length
    },
    series: { days, cso: days.map((d) => pick(d, 'cso')), hre: days.map((d) => pick(d, 'hre')) },
    statusSplit,
    roleTotals: ['cso', 'hre'].map((r) => {
      const xs = emp.filter((e) => e.role === r);
      return { role: r, people: xs.length, calls: xs.reduce((a, e) => a + e.metrics.calls, 0),
        interested: xs.reduce((a, e) => a + e.metrics.interested + e.metrics.converted, 0),
        loans: xs.reduce((a, e) => a + e.loans, 0), approved: xs.reduce((a, e) => a + e.approved, 0),
        dsa: xs.reduce((a, e) => a + e.dsa_added, 0) };
    }),
    employees: emp.filter((e) => e.is_active).map((e) => ({ ...e, today: todayMap[e.id] || null })),
    hourly, followups, security, recent
  };
}

module.exports = { periodRange, employeeTotals, dashboard, METRICS, METRIC_LABELS, metricMap };
