// Hourly-update schedules for new joiners + the once-a-minute background job
// (slot reminders, missed-slot alerts, follow-up reminders, pending DSR alerts, nightly backup).
const db = require('../db/pool');
const time = require('./time');
const { notify, notifyAdmins, once } = require('./notify');
const rt = require('./realtime');
const settings = require('./settings');
const config = require('../config');

// Returns [{ slot, isBreak }] – each slot is the minute-of-day an update is due.
function buildSlots(s) {
  const out = [];
  const step = Math.max(15, s.interval_min);
  for (let t = s.start_min + step; t <= s.end_min; t += step) out.push(t);
  if (s.end_min > s.start_min && (out.length === 0 || out[out.length - 1] < s.end_min)) out.push(s.end_min);
  return out.map((t) => ({
    slot: t,
    isBreak: s.break_start_min !== null && s.break_start_min !== undefined && s.break_end_min !== null &&
      t > s.break_start_min && t <= s.break_end_min
  }));
}

function isActiveOn(s, date) {
  if (!s || !s.enabled || s.released_at) return false;
  if (s.until_date && date > s.until_date) return false;
  return (s.days || []).includes(time.weekdayOf(date));
}

// Status of each slot for a user on a date: done | late | missed | due | upcoming | break | skipped (before the schedule existed)
function slotBoard(s, date, updates) {
  const now = time.nowParts();
  const created = s.created_at ? time.nowParts(new Date(s.created_at)) : null;
  const byslot = new Map(updates.map((u) => [u.slot_min, u]));
  const slots = buildSlots(s);
  return slots.map(({ slot, isBreak }, i) => {
    const prev = i === 0 ? s.start_min : slots[i - 1].slot;
    const u = byslot.get(slot);
    let status;
    if (isBreak) status = 'break';
    else if (!u && created && created.date === date && slot <= created.minutes) status = 'skipped';
    else if (u) status = u.is_late ? 'late' : 'done';
    else if (date < now.date || (date === now.date && now.minutes > slot + s.grace_min)) status = 'missed';
    else if (date === now.date && now.minutes >= prev) status = 'due';
    else status = 'upcoming';
    return { slot, label: time.fmtMin(slot), from: prev, fromLabel: time.fmtMin(prev), status, update: u || null };
  });
}

async function getSchedule(userId) {
  return db.one('SELECT * FROM hourly_schedules WHERE user_id=$1', [userId]);
}

async function runJob() {
  const now = time.nowParts();
  const date = now.date;

  // 1) Hourly schedules
  const scheds = await db.many(
    `SELECT s.*, u.full_name, u.role FROM hourly_schedules s JOIN users u ON u.id=s.user_id
     WHERE u.is_active AND s.enabled AND s.released_at IS NULL`);
  for (const s of scheds) {
    if (s.until_date && date > s.until_date) {
      await db.query('UPDATE hourly_schedules SET released_at=now() WHERE user_id=$1', [s.user_id]);
      await notifyAdmins('schedule', `${s.full_name}'s hourly schedule ended`, `End date ${s.until_date} reached. They are now on the standard DSR.`, `#/employees/${s.user_id}`);
      continue;
    }
    if (!isActiveOn(s, date)) continue;
    const ups = await db.many('SELECT slot_min, is_late FROM hourly_updates WHERE user_id=$1 AND work_date=$2', [s.user_id, date]);
    for (const b of slotBoard(s, date, ups)) {
      if (b.status === 'break' || b.status === 'skipped' || b.update) continue;
      if (s.remind_before && now.minutes >= b.slot - 5 && now.minutes < b.slot) {
        if (await once(`remind:${s.user_id}:${date}:${b.slot}`)) {
          await notify(s.user_id, 'reminder', `Hourly update due at ${b.label}`, 'Post your update for this hour.', '#/hourly');
        }
      }
      if (b.status === 'missed' && now.minutes - (b.slot + s.grace_min) <= 180) {
        if (await once(`missed:${s.user_id}:${date}:${b.slot}`)) {
          await notify(s.user_id, 'missed', `You missed the ${b.label} update`, 'You can still submit it; it will be marked late.', '#/hourly');
          if (s.alert_admin) {
            await notifyAdmins('missed', `${s.full_name} missed the ${b.label} update`, '', `#/employees/${s.user_id}`);
            rt.emitAdmins('hourly', { userId: s.user_id, date, slot: b.slot, status: 'missed' });
            rt.activity({ id: s.user_id, full_name: s.full_name, role: s.role }, `missed the ${b.label} hourly update`, { level: 'warn' });
          }
        }
      }
    }
  }

  // 2) Follow-up reminders (once per record per day) and overdue digests
  const dueLoans = await db.many(
    `SELECT l.id, l.owner_id, l.customer_name FROM loan_cases l JOIN users u ON u.id=l.owner_id
     WHERE u.is_active AND l.next_follow_up = $1`, [date]);
  for (const l of dueLoans) {
    if (await once(`fu:loan:${l.id}:${date}`)) await notify(l.owner_id, 'followup', `Follow-up today: ${l.customer_name}`, 'Loan case follow-up is due today.', '#/loans');
  }
  const dueContacts = await db.many(
    `SELECT c.id, c.owner_id, c.name FROM contacts c JOIN users u ON u.id=c.owner_id
     WHERE u.is_active AND c.next_follow_up = $1`, [date]);
  for (const c of dueContacts) {
    if (await once(`fu:contact:${c.id}:${date}`)) await notify(c.owner_id, 'followup', `Follow-up today: ${c.name || 'contact'}`, 'Calling list follow-up is due today.', '#/contacts');
  }
  if (now.minutes >= 10 * 60) {
    const overdue = await db.many(
      `SELECT owner_id, count(*)::int AS n FROM (
         SELECT owner_id FROM loan_cases WHERE next_follow_up < $1 AND status NOT IN ('6 - Disbursed','0 - Rejected')
         UNION ALL SELECT owner_id FROM contacts WHERE next_follow_up < $1) x GROUP BY owner_id`, [date]);
    let total = 0;
    for (const o of overdue) {
      total += o.n;
      if (await once(`fu-overdue:${o.owner_id}:${date}`)) await notify(o.owner_id, 'missed', `${o.n} overdue follow-up(s)`, 'Update the follow-up date or status.', '#/loans');
    }
    if (total && (await once(`fu-overdue-admin:${date}`))) await notifyAdmins('missed', `${total} overdue follow-ups across the team`, '', '#/loans');
  }

  // 3) Pending DSR after the due time (Mon–Sat)
  const due = time.parseHHMM(await settings.get('dsr_due_time')) || 19 * 60;
  if (now.minutes >= due && now.weekday !== 0) {
    const pending = await db.many(
      `SELECT u.id, u.full_name FROM users u
       LEFT JOIN dsr_entries d ON d.user_id=u.id AND d.work_date=$1
       WHERE u.is_active AND u.role IN ('cso','hre') AND (d.id IS NULL OR d.status <> 'submitted')`, [date]);
    for (const p of pending) {
      if (await once(`dsr-pending:${p.id}:${date}`)) await notify(p.id, 'pending', "Today's DSR is not submitted", 'Please complete and submit your DSR.', '#/my-dsr');
    }
    if (pending.length && (await once(`dsr-pending-admin:${date}`))) {
      await notifyAdmins('pending', `${pending.length} DSR(s) not submitted today`, pending.map((p) => p.full_name).join(', '), '#/dsr');
    }
  }

  // 4) Nightly backup
  const bt = time.parseHHMM(config.backupTime);
  if (bt !== null && now.minutes >= bt && (await once(`backup:${date}`))) {
    try {
      const file = await require('./backup').runBackup();
      console.log('[backup] nightly backup written', file);
    } catch (e) {
      console.error('[backup] failed', e.message);
      await notifyAdmins('pending', 'Nightly backup FAILED', e.message, '#/settings');
    }
  }
}

let timer = null;
function start() {
  const tick = () => runJob().catch((e) => console.error('[job]', e.message));
  setTimeout(tick, 5000);
  timer = setInterval(tick, 60 * 1000);
}
function stop() { if (timer) clearInterval(timer); }

module.exports = { buildSlots, slotBoard, isActiveOn, getSchedule, runJob, start, stop };
