// Full logical backup: every table written to one gzipped JSON file in BACKUP_DIR.
// Restore with: npm run restore -- backups/<file>.json.gz
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const db = require('../db/pool');
const config = require('../config');

// Order matters for restore (parents before children).
const TABLES = ['settings', 'users', 'role_changes', 'form_templates', 'hourly_schedules', 'hourly_updates',
  'dsr_entries', 'loan_cases', 'contacts', 'dsa_partners', 'notifications', 'audit_logs', 'sent_alerts', 'refresh_tokens'];

async function runBackup() {
  fs.mkdirSync(config.backupDir, { recursive: true });
  const out = { app: 'andromeda-dsr', version: 1, created_at: new Date().toISOString(), tables: {} };
  for (const t of TABLES) out.tables[t] = (await db.query(`SELECT * FROM ${t}`)).rows;
  const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const file = path.join(config.backupDir, `dsr-backup-${stamp}.json.gz`);
  fs.writeFileSync(file, zlib.gzipSync(JSON.stringify(out)));
  prune();
  return file;
}

function listBackups() {
  if (!fs.existsSync(config.backupDir)) return [];
  return fs.readdirSync(config.backupDir)
    .filter((f) => /^dsr-backup-.*\.json\.gz$/.test(f))
    .map((f) => { const st = fs.statSync(path.join(config.backupDir, f)); return { file: f, bytes: st.size, created_at: st.mtime.toISOString() }; })
    .sort((a, b) => b.file.localeCompare(a.file));
}

function prune() {
  const files = listBackups();
  files.slice(config.backupKeep).forEach((f) => {
    try { fs.unlinkSync(path.join(config.backupDir, f.file)); } catch { /* ignore */ }
  });
}

async function restore(file) {
  const data = JSON.parse(zlib.gunzipSync(fs.readFileSync(file)).toString('utf8'));
  if (data.app !== 'andromeda-dsr') throw new Error('Not an Andromeda DSR backup file');
  const jsonCols = new Set((await db.many(
    "SELECT table_name || '.' || column_name AS k FROM information_schema.columns WHERE table_schema='public' AND data_type IN ('json','jsonb')")).map((r) => r.k));
  await db.tx(async (c) => {
    await c.query(`TRUNCATE ${[...TABLES].reverse().join(', ')} RESTART IDENTITY CASCADE`);
    for (const t of TABLES) {
      const rows = data.tables[t] || [];
      for (const r of rows) {
        const cols = Object.keys(r);
        const vals = cols.map((k) => (jsonCols.has(`${t}.${k}`) && r[k] !== null ? JSON.stringify(r[k]) : r[k]));
        await c.query(`INSERT INTO ${t}(${cols.join(',')}) VALUES (${cols.map((_, i) => '$' + (i + 1)).join(',')})`, vals);
      }
      // move id sequences past restored ids
      const hasId = rows.length && Object.prototype.hasOwnProperty.call(rows[0], 'id');
      if (hasId) await c.query(`SELECT setval(pg_get_serial_sequence('${t}','id'), COALESCE((SELECT max(id) FROM ${t}),1))`);
    }
  });
  return Object.fromEntries(TABLES.map((t) => [t, (data.tables[t] || []).length]));
}

module.exports = { runBackup, listBackups, restore, TABLES };
