const db = require('../db/pool');

let cache = null;

async function all() {
  if (!cache) {
    const rows = await db.many('SELECT key, value FROM settings');
    cache = Object.fromEntries(rows.map((r) => [r.key, r.value]));
  }
  return cache;
}

async function get(key) { return (await all())[key]; }

async function set(key, value) {
  await db.query('INSERT INTO settings(key, value) VALUES ($1,$2) ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value', [key, JSON.stringify(value)]);
  cache = null;
}

module.exports = { all, get, set };
