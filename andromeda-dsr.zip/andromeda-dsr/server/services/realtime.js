// Socket.IO: every signed-in browser joins its own room "user:<id>"; admins also join "admins".
// Employees therefore only ever receive events about themselves.
const { Server } = require('socket.io');
const jwt = require('jsonwebtoken');
const config = require('../config');
const db = require('../db/pool');

let io = null;

function init(httpServer) {
  io = new Server(httpServer, { cors: { origin: false }, serveClient: true });
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth && socket.handshake.auth.token;
      const p = jwt.verify(token, config.jwtAccessSecret);
      const u = await db.one('SELECT id, role, is_active, token_version FROM users WHERE id=$1', [p.sub]);
      if (!u || !u.is_active || u.token_version !== p.tv) return next(new Error('unauthorized'));
      socket.data.user = u;
      next();
    } catch {
      next(new Error('unauthorized'));
    }
  });
  io.on('connection', (socket) => {
    const u = socket.data.user;
    socket.join(`user:${u.id}`);
    if (u.role === 'super_admin') socket.join('admins');
    emitAdmins('presence', { userId: u.id, online: true });
    socket.on('disconnect', () => emitAdmins('presence', { userId: u.id, online: false }));
  });
  return io;
}

function emitAdmins(event, payload) { if (io) io.to('admins').emit(event, payload); }
function emitUser(userId, event, payload) { if (io) io.to(`user:${userId}`).emit(event, payload); }

// A short line for the live activity feed on the management dashboard.
function activity(user, text, extra = {}) {
  emitAdmins('activity', { at: new Date().toISOString(), userId: user.id, name: user.full_name, role: user.role, text, ...extra });
}

async function disconnectUser(userId) {
  if (!io) return;
  emitUser(userId, 'force-logout', {});
  const sockets = await io.in(`user:${userId}`).fetchSockets();
  sockets.forEach((s) => s.disconnect(true));
}

function onlineUserIds() {
  if (!io) return [];
  const ids = new Set();
  for (const [, s] of io.sockets.sockets) if (s.data.user) ids.add(s.data.user.id);
  return [...ids];
}

module.exports = { init, emitAdmins, emitUser, activity, disconnectUser, onlineUserIds };
