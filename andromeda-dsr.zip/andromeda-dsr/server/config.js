// Loads settings from .env (created automatically on first run with strong random secrets).
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ROOT = path.resolve(__dirname, '..');
const ENV_FILE = path.join(ROOT, '.env');

function parseEnv(text) {
  const out = {};
  for (const line of text.split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (!m) continue;
    let v = m[2];
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    out[m[1]] = v;
  }
  return out;
}

function ensureEnvFile() {
  if (fs.existsSync(ENV_FILE)) return;
  const rnd = (n) => crypto.randomBytes(n).toString('hex');
  const text = [
    '# Andromeda DSR settings. Generated on first run. KEEP THIS FILE PRIVATE AND BACKED UP.',
    '# Losing DATA_ENCRYPTION_KEY makes encrypted fields (PAN numbers) unreadable.',
    'PORT=8080',
    'HOST=0.0.0.0',
    '# Leave DATABASE_URL empty to use the built-in database stored in ./data/pg',
    '# For a separate PostgreSQL server use e.g. postgres://dsr:password@localhost:5432/dsr',
    'DATABASE_URL=',
    'EMBEDDED_PG_PORT=54329',
    'APP_TIMEZONE=Asia/Kolkata',
    `JWT_ACCESS_SECRET=${rnd(32)}`,
    `JWT_REFRESH_SECRET=${rnd(32)}`,
    `DATA_ENCRYPTION_KEY=${rnd(32)}`,
    `EMBEDDED_PG_PASSWORD=${rnd(16)}`,
    '# Set to true only when the app runs behind HTTPS (recommended on the internet)',
    'COOKIE_SECURE=false',
    '# Set to 1 when running behind a reverse proxy (nginx, Caddy, IIS) so real client IPs are logged',
    'TRUST_PROXY=0',
    'BACKUP_DIR=./backups',
    'BACKUP_KEEP=30',
    'BACKUP_TIME=23:30',
    ''
  ].join('\n');
  fs.writeFileSync(ENV_FILE, text, { mode: 0o600 });
  console.log('[setup] Created .env with fresh secrets');
}

ensureEnvFile();
const fileEnv = parseEnv(fs.readFileSync(ENV_FILE, 'utf8'));
const env = { ...fileEnv, ...process.env };

const config = {
  root: ROOT,
  port: parseInt(env.PORT || '8080', 10),
  host: env.HOST || '0.0.0.0',
  databaseUrl: env.DATABASE_URL || '',
  embeddedPgPort: parseInt(env.EMBEDDED_PG_PORT || '54329', 10),
  embeddedPgPassword: env.EMBEDDED_PG_PASSWORD || 'dsr-local',
  timezone: env.APP_TIMEZONE || 'Asia/Kolkata',
  jwtAccessSecret: env.JWT_ACCESS_SECRET,
  jwtRefreshSecret: env.JWT_REFRESH_SECRET,
  encryptionKey: env.DATA_ENCRYPTION_KEY,
  cookieSecure: String(env.COOKIE_SECURE).toLowerCase() === 'true',
  trustProxy: parseInt(env.TRUST_PROXY || '0', 10),
  backupDir: path.resolve(ROOT, env.BACKUP_DIR || './backups'),
  backupKeep: parseInt(env.BACKUP_KEEP || '30', 10),
  backupTime: env.BACKUP_TIME || '23:30',
  accessTtlSec: 15 * 60,
  refreshTtlDays: 7,
  maxFailedLogins: 5,
  lockMinutes: 15
};

for (const k of ['jwtAccessSecret', 'jwtRefreshSecret', 'encryptionKey']) {
  if (!config[k] || config[k].length < 32) {
    throw new Error(`Missing or too short ${k} in .env – delete .env to regenerate (see troubleshooting guide).`);
  }
}

module.exports = config;
