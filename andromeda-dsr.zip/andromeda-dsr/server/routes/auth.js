// Sign-in, token refresh (rotating refresh tokens in an httpOnly cookie), sign-out, password change.
const express = require('express');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const config = require('../config');
const db = require('../db/pool');
const { authenticate, HttpError } = require('../middleware/auth');
const { audit, clientIp, notifyAdmins, once } = require('../services/notify');
const { sha256 } = require('../services/crypto');
const rt = require('../services/realtime');
const time = require('../services/time');

const router = express.Router();
const COOKIE = 'dsr_rt';

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Too many sign-in attempts from this network. Wait 15 minutes.' } });

function accessToken(u) {
  return jwt.sign({ sub: u.id, role: u.role, tv: u.token_version }, config.jwtAccessSecret, { expiresIn: config.accessTtlSec });
}

async function issueRefresh(req, res, userId) {
  const raw = crypto.randomBytes(48).toString('base64url');
  const expires = new Date(Date.now() + config.refreshTtlDays * 864e5);
  await db.query(
    'INSERT INTO refresh_tokens(user_id, token_hash, ip, user_agent, expires_at) VALUES ($1,$2,$3,$4,$5)',
    [userId, sha256(raw), clientIp(req), String(req.headers['user-agent'] || '').slice(0, 300), expires]);
  res.cookie(COOKIE, raw, { httpOnly: true, sameSite: 'strict', secure: config.cookieSecure, path: '/api/auth', expires });
}

function publicUser(u) {
  return { id: u.id, emp_code: u.emp_code, full_name: u.full_name, username: u.username, role: u.role,
    branch: u.branch, must_change_password: u.must_change_password };
}

function validatePassword(p) {
  if (typeof p !== 'string' || p.length < 8) return 'Password must be at least 8 characters';
  if (!/[A-Za-z]/.test(p) || !/[0-9]/.test(p)) return 'Password must contain letters and numbers';
  return null;
}

router.post('/login', loginLimiter, async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) throw new HttpError(400, 'Enter username and password');
  const u = await db.one('SELECT * FROM users WHERE lower(username)=lower($1) OR lower(emp_code)=lower($1)', [String(username).trim()]);
  const fail = async (msg, uid = null) => {
    await audit(req, 'login_failed', 'user', uid, `Failed sign-in for "${String(username).slice(0, 60)}"`, null, null, uid);
    throw new HttpError(401, msg);
  };
  if (!u) return fail('Wrong username or password');
  if (!u.is_active) return fail('This account is disabled. Contact your admin.', u.id);
  if (u.locked_until && new Date(u.locked_until) > new Date()) {
    const mins = Math.ceil((new Date(u.locked_until) - new Date()) / 60000);
    return fail(`Account locked after too many wrong passwords. Try again in ${mins} min or ask admin to reset.`, u.id);
  }
  const ok = await bcrypt.compare(String(password), u.password_hash);
  if (!ok) {
    const n = u.failed_attempts + 1;
    const lock = n >= config.maxFailedLogins ? new Date(Date.now() + config.lockMinutes * 60000) : null;
    await db.query('UPDATE users SET failed_attempts=$2, locked_until=$3 WHERE id=$1', [u.id, lock ? 0 : n, lock]);
    if (lock && (await once(`lock:${u.id}:${Date.now()}`))) {
      await notifyAdmins('security', `${u.full_name}'s account was locked`, `${config.maxFailedLogins} wrong passwords from IP ${clientIp(req)}`, `#/employees/${u.id}`);
    }
    return fail('Wrong username or password', u.id);
  }
  const ip = clientIp(req);
  const knownIp = await db.one('SELECT 1 AS k FROM audit_logs WHERE user_id=$1 AND action=$2 AND ip=$3 LIMIT 1', [u.id, 'login', ip]);
  await db.query('UPDATE users SET failed_attempts=0, locked_until=NULL, last_login_at=now(), last_login_ip=$2 WHERE id=$1', [u.id, ip]);
  await issueRefresh(req, res, u.id);
  await audit(req, 'login', 'user', u.id, `Signed in${knownIp ? '' : ' from a new IP'}`, null, null, u.id);
  if (!knownIp && u.role !== 'super_admin' && u.last_login_at) {
    await notifyAdmins('security', `${u.full_name} signed in from a new IP`, ip, `#/employees/${u.id}`);
  }
  rt.activity(u, 'signed in');
  res.json({ accessToken: accessToken(u), user: publicUser(u), timezone: config.timezone, today: time.today() });
});

router.post('/refresh', async (req, res) => {
  const raw = req.cookies[COOKIE];
  if (!raw) return res.json({ signedIn: false });
  const row = await db.one('SELECT * FROM refresh_tokens WHERE token_hash=$1', [sha256(raw)]);
  if (!row || row.revoked_at || new Date(row.expires_at) < new Date()) {
    if (row && row.revoked_at) {
      // A revoked token was reused – possible theft. End every session of this user.
      await db.query('UPDATE refresh_tokens SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL', [row.user_id]);
      await audit(req, 'token_reuse', 'user', row.user_id, 'Old session token reused – all sessions ended', null, null, row.user_id);
    }
    res.clearCookie(COOKIE, { path: '/api/auth' });
    throw new HttpError(401, 'Session expired, please sign in again');
  }
  const u = await db.one('SELECT * FROM users WHERE id=$1', [row.user_id]);
  if (!u || !u.is_active) throw new HttpError(401, 'Account disabled');
  await db.query('UPDATE refresh_tokens SET revoked_at=now(), last_used_at=now() WHERE id=$1', [row.id]);
  await issueRefresh(req, res, u.id);
  res.json({ accessToken: accessToken(u), user: publicUser(u), timezone: config.timezone, today: time.today() });
});

router.post('/logout', async (req, res) => {
  const raw = req.cookies[COOKIE];
  if (raw) {
    const row = await db.one('UPDATE refresh_tokens SET revoked_at=now() WHERE token_hash=$1 RETURNING user_id', [sha256(raw)]);
    if (row) await audit(req, 'logout', 'user', row.user_id, 'Signed out', null, null, row.user_id);
  }
  res.clearCookie(COOKIE, { path: '/api/auth' });
  res.json({ ok: true });
});

router.get('/me', authenticate, async (req, res) => {
  res.json({ user: publicUser(req.user), timezone: config.timezone, today: time.today() });
});

router.post('/change-password', authenticate, async (req, res) => {
  const { currentPassword, newPassword } = req.body || {};
  const u = await db.one('SELECT * FROM users WHERE id=$1', [req.user.id]);
  if (!(await bcrypt.compare(String(currentPassword || ''), u.password_hash))) throw new HttpError(400, 'Current password is wrong');
  const err = validatePassword(newPassword);
  if (err) throw new HttpError(400, err);
  if (await bcrypt.compare(newPassword, u.password_hash)) throw new HttpError(400, 'Choose a different password from the current one');
  const hash = await bcrypt.hash(newPassword, 12);
  // bump token_version: other devices are signed out
  const nu = await db.one(
    'UPDATE users SET password_hash=$2, must_change_password=FALSE, token_version=token_version+1, updated_at=now() WHERE id=$1 RETURNING *',
    [u.id, hash]);
  await db.query('UPDATE refresh_tokens SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL', [u.id]);
  await issueRefresh(req, res, u.id);
  await audit(req, 'password_changed', 'user', u.id, 'Changed own password');
  res.json({ accessToken: accessToken(nu), user: publicUser(nu) });
});

module.exports = { router, validatePassword, publicUser };
