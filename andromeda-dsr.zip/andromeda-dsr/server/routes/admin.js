// Dashboard, audit log, settings, backups (Super Admin) and notifications (everyone, own only).
const express = require('express');
const path = require('path');
const fs = require('fs');
const db = require('../db/pool');
const config = require('../config');
const { requireAdmin, HttpError } = require('../middleware/auth');
const { audit } = require('../services/notify');
const settings = require('../services/settings');
const backup = require('../services/backup');
const an = require('../services/analytics');
const time = require('../services/time');

// ---------- dashboard ----------
const dashboard = express.Router();
dashboard.use(requireAdmin);
dashboard.get('/', async (req, res) => {
  const role = ['cso', 'hre'].includes(req.query.role) ? req.query.role : null;
  res.json(await an.dashboard(req.query.period || 'today', role, req.query.from, req.query.to));
});

// ---------- audit ----------
const auditRouter = express.Router();
auditRouter.use(requireAdmin);
auditRouter.get('/', async (req, res) => {
  const p = []; const w = [];
  const add = (sql, v) => { p.push(v); w.push(sql.replace('?', '$' + p.length)); };
  if (req.query.user_id) add('a.user_id = ?', parseInt(req.query.user_id, 10));
  if (req.query.action) add('a.action = ?', String(req.query.action));
  if (req.query.entity) add('a.entity = ?', String(req.query.entity));
  if (time.isDate(req.query.from)) add('a.created_at >= ?::date', req.query.from);
  if (time.isDate(req.query.to)) add("a.created_at < ?::date + interval '1 day'", req.query.to);
  if (req.query.q) { p.push('%' + req.query.q + '%'); w.push(`(a.summary ILIKE $${p.length} OR a.ip ILIKE $${p.length})`); }
  const where = w.length ? 'WHERE ' + w.join(' AND ') : '';
  const limit = Math.min(parseInt(req.query.limit || '100', 10) || 100, 500);
  const offset = parseInt(req.query.offset || '0', 10) || 0;
  const rows = await db.many(
    `SELECT a.id, a.created_at, a.action, a.entity, a.entity_id, a.summary, a.ip, a.user_agent, a.before_data, a.after_data,
            u.full_name, u.role FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id ${where}
     ORDER BY a.created_at DESC LIMIT ${limit} OFFSET ${offset}`, p);
  const total = (await db.one(`SELECT count(*)::int AS n FROM audit_logs a ${where}`, p)).n;
  const actions = (await db.many('SELECT DISTINCT action FROM audit_logs ORDER BY 1')).map((r) => r.action);
  res.json({ rows, total, actions });
});

// ---------- notifications ----------
const notifications = express.Router();
notifications.get('/', async (req, res) => {
  const rows = await db.many('SELECT * FROM notifications WHERE user_id=$1 ORDER BY created_at DESC LIMIT 60', [req.user.id]);
  const unread = (await db.one('SELECT count(*)::int AS n FROM notifications WHERE user_id=$1 AND NOT is_read', [req.user.id])).n;
  res.json({ rows, unread });
});
notifications.post('/read-all', async (req, res) => {
  await db.query('UPDATE notifications SET is_read=TRUE WHERE user_id=$1 AND NOT is_read', [req.user.id]);
  res.json({ ok: true });
});
notifications.post('/:id/read', async (req, res) => {
  await db.query('UPDATE notifications SET is_read=TRUE WHERE id=$1 AND user_id=$2', [parseInt(req.params.id, 10), req.user.id]);
  res.json({ ok: true });
});

// ---------- settings ----------
const settingsRouter = express.Router();
const EDITABLE = ['company_name', 'loan_statuses', 'loan_status_groups', 'products', 'contact_statuses', 'dsa_statuses', 'dsa_profiles', 'dsr_due_time', 'dsr_edit_days'];
settingsRouter.get('/', async (req, res) => {
  const s = await settings.all();
  res.json(Object.fromEntries(EDITABLE.map((k) => [k, s[k]])));
});
settingsRouter.put('/:key', requireAdmin, async (req, res) => {
  const key = req.params.key;
  if (!EDITABLE.includes(key)) throw new HttpError(400, 'Unknown setting');
  let v = req.body && req.body.value;
  if (['loan_statuses', 'products', 'contact_statuses', 'dsa_statuses', 'dsa_profiles'].includes(key)) {
    if (!Array.isArray(v)) throw new HttpError(400, 'Expected a list');
    v = [...new Set(v.map((x) => String(x).trim()).filter(Boolean))].slice(0, 100);
    if (!v.length) throw new HttpError(400, 'List cannot be empty');
  }
  if (key === 'dsr_due_time' && time.parseHHMM(v) === null) throw new HttpError(400, 'Use HH:MM, e.g. 19:00');
  if (key === 'dsr_edit_days') { v = parseInt(v, 10); if (!(v >= 0 && v <= 31)) throw new HttpError(400, '0–31 days'); }
  if (key === 'loan_status_groups' && (typeof v !== 'object' || !v)) throw new HttpError(400, 'Bad value');
  const before = await settings.get(key);
  await settings.set(key, v);
  await audit(req, 'setting_changed', 'setting', key, `Changed setting ${key}`, { value: before }, { value: v });
  res.json({ key, value: v });
});

// ---------- backups ----------
const backups = express.Router();
backups.use(requireAdmin);
backups.get('/', (req, res) => res.json({ dir: config.backupDir, keep: config.backupKeep, time: config.backupTime, files: backup.listBackups() }));
backups.post('/', async (req, res) => {
  const file = await backup.runBackup();
  await audit(req, 'backup_created', 'backup', path.basename(file), 'Created a manual backup');
  res.json({ file: path.basename(file) });
});
backups.get('/:file', async (req, res) => {
  const f = path.basename(req.params.file);
  if (!/^dsr-backup-[\w-]+\.json\.gz$/.test(f)) throw new HttpError(400, 'Bad file name');
  const full = path.join(config.backupDir, f);
  if (!fs.existsSync(full)) throw new HttpError(404, 'Backup not found');
  await audit(req, 'backup_downloaded', 'backup', f, 'Downloaded a backup file');
  res.download(full);
});

module.exports = { dashboard, audit: auditRouter, notifications, settings: settingsRouter, backups };
