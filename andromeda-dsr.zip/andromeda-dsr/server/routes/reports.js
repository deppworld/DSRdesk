// Reports (daily / weekly / monthly / team / employee) as JSON, Excel or PDF. Super Admin only.
const express = require('express');
const path = require('path');
const ExcelJS = require('exceljs');
const PDFDocument = require('pdfkit');
const db = require('../db/pool');
const config = require('../config');
const { HttpError } = require('../middleware/auth');
const { audit } = require('../services/notify');
const time = require('../services/time');
const an = require('../services/analytics');

const router = express.Router();

const fmtTime = (ts) => (ts ? new Date(ts).toLocaleTimeString('en-IN', { timeZone: config.timezone, hour: '2-digit', minute: '2-digit' }) : '');
const money = (n) => (n ? Math.round(n).toLocaleString('en-IN') : '0');

function rangeFor(type, q) {
  const base = time.isDate(q.date) ? q.date : time.today();
  if (time.isDate(q.from) && time.isDate(q.to)) return { from: q.from <= q.to ? q.from : q.to, to: q.from <= q.to ? q.to : q.from };
  if (type === 'daily') return { from: base, to: base };
  if (type === 'weekly') { const wd = time.weekdayOf(base); const from = time.addDays(base, -((wd + 6) % 7)); return { from, to: time.addDays(from, 6) }; }
  const from = base.slice(0, 8) + '01';
  const d = new Date(from + 'T00:00:00Z'); d.setUTCMonth(d.getUTCMonth() + 1); d.setUTCDate(0);
  return { from, to: d.toISOString().slice(0, 10) };
}

async function buildSummary(range, role) {
  const emp = await an.employeeTotals(range.from, range.to, { role });
  const columns = [
    { key: 'full_name', label: 'Employee', w: 18 }, { key: 'emp_code', label: 'ID', w: 9 }, { key: 'role', label: 'Role', w: 6 },
    { key: 'days_started', label: 'Days', w: 6 }, { key: 'dsr_submitted', label: 'DSR sub.', w: 8 },
    { key: 'calls', label: 'Calls', w: 7 }, { key: 'interested', label: 'Interested', w: 9 }, { key: 'converted_m', label: 'Converted', w: 9 },
    { key: 'mined', label: 'Mined', w: 7 }, { key: 'registrations', label: 'DSA reg.', w: 8 }, { key: 'files_login', label: 'Files login', w: 9 },
    { key: 'meetings', label: 'Meetings', w: 8 }, { key: 'loans', label: 'Loans', w: 7 }, { key: 'approved', label: 'Approved', w: 8 },
    { key: 'rejected', label: 'Rejected', w: 8 }, { key: 'pending', label: 'Pending', w: 8 }, { key: 'conversion', label: 'Conv. %', w: 8 },
    { key: 'amount_approved', label: 'Amt approved (Rs)', w: 14 }, { key: 'contacts', label: 'Contacts', w: 8 }, { key: 'dsa_added', label: 'DSA added', w: 9 },
    { key: 'hourly', label: 'Hourly done/late/missed', w: 14 }
  ];
  const rows = emp.map((e) => ({
    full_name: e.full_name + (e.is_active ? '' : ' (disabled)'), emp_code: e.emp_code, role: e.role.toUpperCase(),
    days_started: e.days_started, dsr_submitted: e.dsr_submitted, calls: e.metrics.calls, interested: e.metrics.interested,
    converted_m: e.metrics.converted, mined: e.metrics.mined, registrations: e.metrics.registrations, files_login: e.metrics.files_login,
    meetings: e.metrics.meetings, loans: e.loans, approved: e.approved, rejected: e.rejected, pending: e.pending, conversion: e.conversion,
    amount_approved: Math.round(e.amount_approved), contacts: e.contacts, dsa_added: e.dsa_added,
    hourly: e.hourly_done + e.hourly_late + e.hourly_missed ? `${e.hourly_done}/${e.hourly_late}/${e.hourly_missed}` : '—'
  }));
  const totals = { full_name: 'TOTAL', emp_code: '', role: '', hourly: '' };
  for (const c of columns) if (!(c.key in totals)) totals[c.key] = rows.reduce((a, r) => a + (typeof r[c.key] === 'number' ? r[c.key] : 0), 0);
  totals.conversion = totals.loans ? Math.round((emp.reduce((a, e) => a + e.converted, 0) / totals.loans) * 1000) / 10 : 0;
  return { columns, rows, totals };
}

async function buildEmployee(range, userId) {
  const user = await db.one('SELECT id, full_name, emp_code, role FROM users WHERE id=$1', [userId]);
  if (!user) throw new HttpError(404, 'Employee not found');
  const map = await an.metricMap();
  const entries = await db.many('SELECT * FROM dsr_entries WHERE user_id=$1 AND work_date BETWEEN $2 AND $3', [userId, range.from, range.to]);
  const loans = await db.many('SELECT case_date, count(*)::int AS n FROM loan_cases WHERE owner_id=$1 AND case_date BETWEEN $2 AND $3 GROUP BY case_date', [userId, range.from, range.to]);
  const ups = await db.many('SELECT work_date, count(*)::int AS n, sum(CASE WHEN is_late THEN 1 ELSE 0 END)::int AS late FROM hourly_updates WHERE user_id=$1 AND work_date BETWEEN $2 AND $3 GROUP BY work_date', [userId, range.from, range.to]);
  const columns = [
    { key: 'date', label: 'Date', w: 11 }, { key: 'day', label: 'Day', w: 5 }, { key: 'in', label: 'Check-in', w: 9 }, { key: 'out', label: 'Submitted', w: 9 },
    { key: 'status', label: 'Status', w: 10 },
    ...an.METRICS.map((m) => ({ key: m, label: an.METRIC_LABELS[m], w: 9 })),
    { key: 'loans', label: 'Loans added', w: 9 }, { key: 'hourly', label: 'Hourly (late)', w: 10 }, { key: 'remarks', label: 'Remarks', w: 30 }
  ];
  const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const rows = [];
  for (let d = range.from; d <= range.to; d = time.addDays(d, 1)) {
    const e = entries.find((x) => x.work_date === d);
    const r = { date: d, day: DAYS[time.weekdayOf(d)], in: e ? fmtTime(e.check_in_at) : '', out: e ? fmtTime(e.check_out_at) : '',
      status: e ? e.status : (time.weekdayOf(d) === 0 ? 'Sunday' : 'No entry') };
    for (const m of an.METRICS) r[m] = 0;
    if (e) for (const [k, metric] of Object.entries(map[e.template_id] || {})) if (typeof e.data[k] === 'number') r[metric] += e.data[k];
    const l = loans.find((x) => x.case_date === d); r.loans = l ? l.n : 0;
    const u = ups.find((x) => x.work_date === d); r.hourly = u ? `${u.n} (${u.late})` : '';
    r.remarks = e ? (e.data.day_remarks || e.remarks || '') : '';
    rows.push(r);
  }
  const totals = { date: 'TOTAL', day: '', in: '', out: '', status: `${entries.filter((e) => e.status === 'submitted').length} submitted`, hourly: '', remarks: '' };
  for (const m of [...an.METRICS, 'loans']) totals[m] = rows.reduce((a, r) => a + r[m], 0);
  return { user, columns, rows, totals };
}

async function toXlsx(res, title, rep, detailRows) {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'Andromeda DSR';
  const ws = wb.addWorksheet('Report', { views: [{ state: 'frozen', ySplit: 3 }] });
  ws.addRow([title]).font = { bold: true, size: 14 };
  ws.addRow([`Generated ${new Date().toLocaleString('en-IN', { timeZone: config.timezone })}`]);
  const hdr = ws.addRow(rep.columns.map((c) => c.label));
  hdr.font = { bold: true, color: { argb: 'FFFFFFFF' } };
  hdr.eachCell((c) => { c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1A5FAD' } }; });
  rep.rows.forEach((r) => ws.addRow(rep.columns.map((c) => r[c.key])));
  if (rep.totals) ws.addRow(rep.columns.map((c) => rep.totals[c.key])).font = { bold: true };
  rep.columns.forEach((c, i) => { ws.getColumn(i + 1).width = Math.max(c.w + 2, 8); });
  if (detailRows && detailRows.length) {
    const ds = wb.addWorksheet('DSR entries');
    const keys = [...new Set(detailRows.flatMap((r) => Object.keys(r.data || {})))];
    ds.addRow(['Date', 'Employee', 'Role', 'Status', 'Check-in', 'Submitted', ...keys]).font = { bold: true };
    detailRows.forEach((r) => ds.addRow([r.work_date, r.full_name, r.role.toUpperCase(), r.status, fmtTime(r.check_in_at), fmtTime(r.check_out_at), ...keys.map((k) => r.data[k] ?? '')]));
    ds.columns.forEach((c) => { c.width = 16; });
  }
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', `attachment; filename="${title.replace(/[^a-z0-9]+/gi, '-').toLowerCase()}.xlsx"`);
  await wb.xlsx.write(res);
  res.end();
}

function toPdf(res, title, rep) {
  const doc = new PDFDocument({ size: 'A4', layout: 'landscape', margin: 28 });
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="${title.replace(/[^a-z0-9]+/gi, '-').toLowerCase()}.pdf"`);
  doc.pipe(res);
  try { doc.image(path.join(config.root, 'public', 'img', 'logo-full.png'), 28, 20, { height: 46 }); } catch { /* logo optional */ }
  doc.font('Helvetica-Bold').fontSize(15).fillColor('#14181F').text(title, 110, 26);
  doc.font('Helvetica').fontSize(8.5).fillColor('#5B6472').text(`Generated ${new Date().toLocaleString('en-IN', { timeZone: config.timezone })}`, 110, 46);
  const cols = rep.columns;
  const usable = doc.page.width - 56;
  const totalW = cols.reduce((a, c) => a + c.w, 0);
  const widths = cols.map((c) => (c.w / totalW) * usable);
  let y = 80;
  const rowH = 16;
  const drawRow = (vals, opts = {}) => {
    if (y > doc.page.height - 40) { doc.addPage(); y = 30; if (!opts.header) drawRow(cols.map((c) => c.label), { header: true }); }
    let x = 28;
    if (opts.header) doc.rect(28, y - 3, usable, rowH).fill('#1A5FAD');
    else if (opts.total) doc.rect(28, y - 3, usable, rowH).fill('#E5ECFC');
    else if (opts.zebra) doc.rect(28, y - 3, usable, rowH).fill('#F6F8FB');
    doc.font(opts.header || opts.total ? 'Helvetica-Bold' : 'Helvetica').fontSize(7).fillColor(opts.header ? '#FFFFFF' : '#14181F');
    vals.forEach((v, i) => {
      doc.text(v === null || v === undefined ? '' : String(v), x + 2, y, { width: widths[i] - 4, height: rowH - 4, ellipsis: true, lineBreak: false });
      x += widths[i];
    });
    y += rowH;
  };
  drawRow(cols.map((c) => c.label), { header: true });
  rep.rows.forEach((r, i) => drawRow(cols.map((c) => (typeof r[c.key] === 'number' && c.key.startsWith('amount') ? money(r[c.key]) : r[c.key])), { zebra: i % 2 === 1 }));
  if (rep.totals) drawRow(cols.map((c) => (typeof rep.totals[c.key] === 'number' && c.key.startsWith('amount') ? money(rep.totals[c.key]) : rep.totals[c.key])), { total: true });
  doc.end();
}

router.get('/', async (req, res) => {
  const type = ['daily', 'weekly', 'monthly', 'team', 'employee', 'custom'].includes(req.query.type) ? req.query.type : 'daily';
  const range = rangeFor(type === 'team' || type === 'employee' || type === 'custom' ? (req.query.from ? 'custom' : 'monthly') : type, req.query);
  const role = ['cso', 'hre'].includes(req.query.role) ? req.query.role : null;
  let rep; let title;
  const label = range.from === range.to ? range.from : `${range.from} to ${range.to}`;
  if (type === 'employee') {
    const uid = parseInt(req.query.user_id, 10);
    if (!uid) throw new HttpError(400, 'Pick an employee');
    rep = await buildEmployee(range, uid);
    title = `Employee report – ${rep.user.full_name} (${rep.user.emp_code}) – ${label}`;
  } else {
    rep = await buildSummary(range, role);
    const names = { daily: 'Daily', weekly: 'Weekly', monthly: 'Monthly', team: 'Team', custom: 'Custom' };
    title = `${names[type]} report${role ? ' – ' + role.toUpperCase() : ''} – ${label}`;
  }
  const format = req.query.format || 'json';
  if (format !== 'json') await audit(req, 'export', 'report', null, `Exported ${title} as ${format.toUpperCase()}`);
  if (format === 'xlsx') {
    const params = [range.from, range.to];
    let w = '';
    if (type === 'employee') { params.push(rep.user.id); w = ` AND u.id=$${params.length}`; } else if (role) { params.push(role); w = ` AND u.role=$${params.length}`; }
    const detail = await db.many(
      `SELECT d.*, u.full_name FROM dsr_entries d JOIN users u ON u.id=d.user_id WHERE d.work_date BETWEEN $1 AND $2${w} ORDER BY d.work_date, u.full_name`, params);
    return toXlsx(res, title, rep, detail);
  }
  if (format === 'pdf') return toPdf(res, title, rep);
  res.json({ title, range, ...rep });
});

module.exports = router;
