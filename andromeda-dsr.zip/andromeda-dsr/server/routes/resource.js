// Generic owner-scoped record routes used for Loan Cases, Calling Lists and the DSA master.
// Employees ONLY ever see rows where owner_id = their own id; changing ids in the URL returns 404.
const express = require('express');
const ExcelJS = require('exceljs');
const db = require('../db/pool');
const { isAdmin, requireAdmin, HttpError } = require('../middleware/auth');
const { audit } = require('../services/notify');
const { encrypt, decrypt } = require('../services/crypto');
const rt = require('../services/realtime');
const time = require('../services/time');

function makeResource({ table, entity, label, titleField, dateField, fields, searchFields, filterFields = [], roles }) {
  const router = express.Router();
  const byKey = Object.fromEntries(fields.map((f) => [f.key, f]));

  if (roles) {
    router.use((req, res, next) => {
      if (isAdmin(req) || roles.includes(req.user.role)) return next();
      next(new HttpError(403, 'This list is not part of your role'));
    });
  }

  function coerce(f, v) {
    if (v === undefined) return undefined;
    if (v === null || v === '') return null;
    switch (f.type) {
      case 'number': { const n = Number(String(v).replace(/[,₹\s]/g, '')); if (!isFinite(n)) throw new HttpError(400, `${f.label} must be a number`); return n; }
      case 'date': if (!time.isDate(String(v))) throw new HttpError(400, `${f.label} must be a date`); return String(v);
      default: return String(v).trim().slice(0, f.max || 500);
    }
  }

  function input(body, partial) {
    const out = {};
    for (const f of fields) {
      if (f.readOnly) continue;
      const v = coerce(f, body[f.key]);
      if (v === undefined) continue;
      if (f.sensitive) {
        out[f.key + '_enc'] = encrypt(v ? String(v).toUpperCase() : null);
        out[f.key + '_last4'] = v ? String(v).slice(-4).toUpperCase() : null;
      } else out[f.key] = v;
    }
    for (const f of fields) {
      if (f.required && !partial && (out[f.key] === undefined || out[f.key] === null)) throw new HttpError(400, `${f.label} is required`);
      if (f.required && partial && out[f.key] === null) throw new HttpError(400, `${f.label} is required`);
    }
    return out;
  }

  function output(row, reveal) {
    if (!row) return row;
    const r = { ...row };
    for (const f of fields.filter((x) => x.sensitive)) {
      r[f.key] = reveal ? decrypt(row[f.key + '_enc']) : (row[f.key + '_last4'] ? '••••••' + row[f.key + '_last4'] : null);
      delete r[f.key + '_enc']; delete r[f.key + '_last4'];
    }
    return r;
  }

  function where(req) {
    const w = []; const p = [];
    const add = (sql, v) => { p.push(v); w.push(sql.replace('?', '$' + p.length)); };
    if (!isAdmin(req)) add('t.owner_id = ?', req.user.id);
    else if (req.query.owner_id) add('t.owner_id = ?', parseInt(req.query.owner_id, 10));
    if (req.query.q) {
      p.push('%' + String(req.query.q).trim() + '%');
      w.push('(' + searchFields.map((s) => `t.${s} ILIKE $${p.length}`).join(' OR ') + ')');
    }
    if (req.query.status) add('t.status = ?', String(req.query.status));
    for (const ff of filterFields) if (req.query[ff]) add(`t.${ff} = ?`, String(req.query[ff]));
    if (req.query.from && time.isDate(req.query.from)) add(`t.${dateField} >= ?`, req.query.from);
    if (req.query.to && time.isDate(req.query.to)) add(`t.${dateField} <= ?`, req.query.to);
    if (req.query.follow_up === 'today') add('t.next_follow_up = ?', time.today());
    if (req.query.follow_up === 'overdue') add('t.next_follow_up < ?', time.today());
    if (req.query.follow_up === 'upcoming') add('t.next_follow_up >= ?', time.today());
    return { sql: w.length ? 'WHERE ' + w.join(' AND ') : '', params: p };
  }

  router.get('/', async (req, res) => {
    const { sql, params } = where(req);
    const limit = Math.min(parseInt(req.query.limit || '50', 10) || 50, req.query.format === 'xlsx' ? 20000 : 500);
    const offset = parseInt(req.query.offset || '0', 10) || 0;
    const order = req.query.follow_up ? 't.next_follow_up ASC NULLS LAST, t.id DESC' : `t.${dateField} DESC, t.id DESC`;
    const rows = await db.many(
      `SELECT t.*, u.full_name AS owner_name FROM ${table} t JOIN users u ON u.id=t.owner_id ${sql}
       ORDER BY ${order} LIMIT ${limit} OFFSET ${offset}`, params);
    const total = (await db.one(`SELECT count(*)::int AS n FROM ${table} t ${sql}`, params)).n;
    if (req.query.format === 'xlsx') {
      if (!isAdmin(req)) throw new HttpError(403, 'Only management can export');
      const wb = new ExcelJS.Workbook();
      const ws = wb.addWorksheet(label);
      const cols = [{ header: 'Employee', key: 'owner_name', width: 20 }, ...fields.map((f) => ({ header: f.label, key: f.key, width: f.type === 'date' ? 12 : 18 }))];
      ws.columns = cols;
      rows.forEach((r) => ws.addRow(output(r, false)));
      ws.getRow(1).font = { bold: true };
      await audit(req, 'export', entity, null, `Exported ${rows.length} ${label} rows to Excel`);
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename="${table}-${time.today()}.xlsx"`);
      await wb.xlsx.write(res);
      return res.end();
    }
    res.json({ rows: rows.map((r) => output(r, false)), total });
  });

  async function load(req) {
    const id = parseInt(req.params.id, 10);
    if (!Number.isInteger(id)) throw new HttpError(404, 'Not found');
    const row = isAdmin(req)
      ? await db.one(`SELECT t.*, u.full_name AS owner_name FROM ${table} t JOIN users u ON u.id=t.owner_id WHERE t.id=$1`, [id])
      : await db.one(`SELECT t.*, u.full_name AS owner_name FROM ${table} t JOIN users u ON u.id=t.owner_id WHERE t.id=$1 AND t.owner_id=$2`, [id, req.user.id]);
    if (!row) {
      if (!isAdmin(req)) await audit(req, 'access_denied', entity, id, `Tried to open ${label} #${id} that is not theirs`);
      throw new HttpError(404, 'Not found');
    }
    return row;
  }

  router.get('/:id', async (req, res) => {
    const row = await load(req);
    const reveal = req.query.reveal === '1';
    if (reveal) await audit(req, 'reveal_sensitive', entity, row.id, `Viewed full sensitive data on ${label} #${row.id}`);
    res.json(output(row, reveal));
  });

  router.post('/', async (req, res) => {
    const data = input(req.body || {}, false);
    for (const k of Object.keys(data)) if (data[k] === null) delete data[k]; // let column defaults apply
    let owner = req.user.id;
    if (isAdmin(req) && req.body.owner_id) owner = parseInt(req.body.owner_id, 10);
    const cols = ['owner_id', ...Object.keys(data)];
    const vals = [owner, ...Object.values(data)];
    const row = await db.one(`INSERT INTO ${table}(${cols.join(',')}) VALUES (${cols.map((_, i) => '$' + (i + 1)).join(',')}) RETURNING *`, vals);
    await audit(req, 'create', entity, row.id, `Added ${label}: ${row[titleField] || '#' + row.id}`, null, output(row, false));
    rt.activity(req.user, `added ${label.toLowerCase()} “${row[titleField] || '#' + row.id}”`);
    rt.emitAdmins('records', { entity, id: row.id });
    res.status(201).json(output(row, false));
  });

  router.patch('/:id', async (req, res) => {
    const before = await load(req);
    const data = input(req.body || {}, true);
    for (const k of ['status', 'case_date', 'contact_date', 'onboard_date', 'list_type']) if (data[k] === null) delete data[k];
    const keys = Object.keys(data);
    if (!keys.length) return res.json(output(before, false));
    const sets = keys.map((k, i) => `${k}=$${i + 2}`).join(', ');
    const row = await db.one(`UPDATE ${table} SET ${sets}, updated_at=now() WHERE id=$1 RETURNING *`, [before.id, ...Object.values(data)]);
    const changed = keys.filter((k) => !k.endsWith('_enc') && String(before[k] ?? '') !== String(row[k] ?? ''));
    const lbl = changed.map((k) => (byKey[k] ? byKey[k].label : k)).join(', ');
    await audit(req, 'update', entity, row.id, `Updated ${label} “${row[titleField] || '#' + row.id}”${lbl ? ': ' + lbl : ''}`, output(before, false), output(row, false));
    if (changed.includes('status')) rt.activity(req.user, `changed “${row[titleField]}” to ${row.status}`);
    else rt.activity(req.user, `updated ${label.toLowerCase()} “${row[titleField] || '#' + row.id}”`);
    rt.emitAdmins('records', { entity, id: row.id });
    res.json(output(row, false));
  });

  router.delete('/:id', requireAdmin, async (req, res) => {
    const before = await load(req);
    await db.query(`DELETE FROM ${table} WHERE id=$1`, [before.id]);
    await audit(req, 'delete', entity, before.id, `Deleted ${label} “${before[titleField] || '#' + before.id}”`, output(before, false), null);
    res.json({ ok: true });
  });

  return router;
}

const loans = makeResource({
  table: 'loan_cases', entity: 'loan', label: 'Loan case', titleField: 'customer_name', dateField: 'case_date',
  searchFields: ['customer_name', 'company_name', 'application_no', 'contact_no', 'lead_by', 'bank', 'location'],
  filterFields: ['product'],
  fields: [
    { key: 'case_date', label: 'Date', type: 'date' },
    { key: 'customer_name', label: 'Customer name', type: 'text', required: true, max: 120 },
    { key: 'application_no', label: 'Application no.', type: 'text', max: 60 },
    { key: 'company_name', label: 'Company name', type: 'text', max: 160 },
    { key: 'pan', label: 'PAN', type: 'text', max: 10, sensitive: true },
    { key: 'location', label: 'Location', type: 'text', max: 80 },
    { key: 'email', label: 'Email', type: 'text', max: 120 },
    { key: 'contact_no', label: 'Contact no.', type: 'text', max: 40 },
    { key: 'lead_by', label: 'Lead by (DSA)', type: 'text', max: 120 },
    { key: 'product', label: 'Product', type: 'text', max: 40 },
    { key: 'loan_amount', label: 'Loan amount', type: 'number' },
    { key: 'bank', label: 'Login bank / NBFC', type: 'text', max: 120 },
    { key: 'login_date', label: 'Login date', type: 'date' },
    { key: 'status', label: 'Case status', type: 'text', max: 40 },
    { key: 'rejected_reason', label: 'Rejected reason', type: 'text', max: 300 },
    { key: 'last_update', label: 'Last update', type: 'text', max: 1000 },
    { key: 'next_follow_up', label: 'Next follow-up', type: 'date' },
    { key: 'banker', label: 'Banker', type: 'text', max: 120 },
    { key: 'payout', label: 'Payout', type: 'number' }
  ]
});

const contacts = makeResource({
  table: 'contacts', entity: 'contact', label: 'Contact', titleField: 'name', dateField: 'contact_date',
  searchFields: ['name', 'mobile1', 'mobile2', 'company', 'city', 'state'], filterFields: ['list_type', 'city'],
  fields: [
    { key: 'list_type', label: 'List', type: 'text', max: 20 },
    { key: 'contact_date', label: 'Date', type: 'date' },
    { key: 'name', label: 'Name', type: 'text', max: 120 },
    { key: 'mobile1', label: 'Mobile 1', type: 'text', max: 30, required: true },
    { key: 'mobile2', label: 'Mobile 2', type: 'text', max: 30 },
    { key: 'designation', label: 'Designation', type: 'text', max: 80 },
    { key: 'company', label: 'Company / industry', type: 'text', max: 160 },
    { key: 'city', label: 'City / town', type: 'text', max: 80 },
    { key: 'state', label: 'State', type: 'text', max: 80 },
    { key: 'status', label: 'Status', type: 'text', max: 60 },
    { key: 'remarks', label: 'Remarks', type: 'text', max: 1000 },
    { key: 'next_follow_up', label: 'Next follow-up', type: 'date' }
  ]
});

const dsa = makeResource({
  table: 'dsa_partners', entity: 'dsa', label: 'DSA partner', titleField: 'name', dateField: 'onboard_date',
  searchFields: ['name', 'andro_code', 'dsa_code', 'erp_code', 'location', 'mobile'], filterFields: ['profile'],
  fields: [
    { key: 'onboard_date', label: 'Date', type: 'date' },
    { key: 'name', label: 'DSA name', type: 'text', required: true, max: 120 },
    { key: 'birthday', label: 'Birthday', type: 'date' },
    { key: 'andro_code', label: 'OneAndro code', type: 'text', max: 40 },
    { key: 'dsa_code', label: 'DSA code', type: 'text', max: 40 },
    { key: 'erp_code', label: 'ERP code', type: 'text', max: 40 },
    { key: 'location', label: 'Location', type: 'text', max: 80 },
    { key: 'mobile', label: 'Mobile', type: 'text', max: 60 },
    { key: 'on_app', label: 'On OneAndro app', type: 'text', max: 10 },
    { key: 'profile', label: 'Profile', type: 'text', max: 40 },
    { key: 'status', label: 'Status', type: 'text', max: 60 },
    { key: 'irda', label: 'IRDA', type: 'text', max: 300 },
    { key: 'remarks', label: 'Remarks', type: 'text', max: 1000 }
  ]
});

module.exports = { loans, contacts, dsa, makeResource };
