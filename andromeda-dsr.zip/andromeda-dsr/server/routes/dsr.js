// Daily DSR entries, DSR form templates (form builder) and hourly updates.
const express = require('express');
const db = require('../db/pool');
const { isAdmin, requireAdmin, HttpError } = require('../middleware/auth');
const { audit } = require('../services/notify');
const rt = require('../services/realtime');
const time = require('../services/time');
const settings = require('../services/settings');
const sched = require('../services/schedule');

// ---------- form templates ----------
const forms = express.Router();

async function activeTemplate(role) {
  return db.one('SELECT * FROM form_templates WHERE role=$1 AND is_active ORDER BY version DESC LIMIT 1', [role]);
}

forms.get('/active', async (req, res) => {
  const role = isAdmin(req) && req.query.role ? req.query.role : req.user.role;
  if (!['cso', 'hre'].includes(role)) throw new HttpError(400, 'No DSR form for this role');
  res.json(await activeTemplate(role));
});

forms.get('/', requireAdmin, async (req, res) => {
  res.json(await db.many(
    `SELECT f.*, u.full_name AS created_by_name FROM form_templates f LEFT JOIN users u ON u.id=f.created_by ORDER BY role, version DESC`));
});

const FIELD_TYPES = ['number', 'text', 'textarea', 'select', 'time', 'date', 'checkbox'];
const METRICS = ['', 'calls', 'interested', 'converted', 'connects', 'kits', 'files_login', 'meetings', 'mined', 'registrations'];

function validateSections(sections) {
  if (!Array.isArray(sections) || !sections.length) throw new HttpError(400, 'Add at least one section');
  const keys = new Set();
  return sections.map((s, i) => {
    const title = String(s.title || '').trim().slice(0, 80);
    if (!title) throw new HttpError(400, `Section ${i + 1} needs a title`);
    const sk = String(s.key || title).toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '') || `section_${i + 1}`;
    const fields = (s.fields || []).map((f, j) => {
      const label = String(f.label || '').trim().slice(0, 80);
      if (!label) throw new HttpError(400, `Field ${j + 1} in “${title}” needs a label`);
      const key = String(f.key || `${sk}_${label}`).toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '').slice(0, 60);
      if (keys.has(key)) throw new HttpError(400, `Two fields use the internal key “${key}”. Rename one.`);
      keys.add(key);
      const type = FIELD_TYPES.includes(f.type) ? f.type : 'text';
      const out = { key, label, type };
      if (type === 'select') out.options = (Array.isArray(f.options) ? f.options : String(f.options || '').split(',')).map((o) => String(o).trim()).filter(Boolean).slice(0, 50);
      if (type === 'number' && METRICS.includes(f.metric) && f.metric) out.metric = f.metric;
      if (f.placeholder) out.placeholder = String(f.placeholder).slice(0, 80);
      if (f.required) out.required = true;
      return out;
    });
    if (!fields.length) throw new HttpError(400, `Section “${title}” has no fields`);
    return { key: sk, title, time: String(s.time || '').slice(0, 40), fields };
  });
}

forms.post('/:role', requireAdmin, async (req, res) => {
  const role = req.params.role;
  if (!['cso', 'hre'].includes(role)) throw new HttpError(400, 'Role must be cso or hre');
  const sections = validateSections(req.body.sections);
  const name = String(req.body.name || `${role.toUpperCase()} Daily DSR`).slice(0, 80);
  const row = await db.tx(async (c) => {
    const v = (await c.query('SELECT COALESCE(max(version),0)+1 AS v FROM form_templates WHERE role=$1', [role])).rows[0].v;
    await c.query('UPDATE form_templates SET is_active=FALSE WHERE role=$1', [role]);
    return (await c.query('INSERT INTO form_templates(role, version, name, sections, created_by) VALUES ($1,$2,$3,$4,$5) RETURNING *',
      [role, v, name, JSON.stringify(sections), req.user.id])).rows[0];
  });
  await audit(req, 'form_published', 'form', row.id, `Published ${role.toUpperCase()} DSR form v${row.version}`);
  res.status(201).json(row);
});

forms.get('/meta', requireAdmin, (req, res) => res.json({ types: FIELD_TYPES, metrics: METRICS.filter(Boolean) }));

// ---------- DSR entries ----------
const dsr = express.Router();

function sanitize(template, data) {
  const out = {};
  for (const s of template.sections) {
    for (const f of s.fields) {
      let v = data ? data[f.key] : undefined;
      if (v === undefined || v === null || v === '') continue;
      if (f.type === 'number') { v = Number(v); if (!isFinite(v)) throw new HttpError(400, `${f.label} must be a number`); }
      else if (f.type === 'checkbox') v = !!v;
      else v = String(v).slice(0, 4000);
      out[f.key] = v;
    }
  }
  return out;
}

async function canEditDate(req, date) {
  if (isAdmin(req)) return true;
  const days = parseInt(await settings.get('dsr_edit_days'), 10) || 0;
  const t = time.today();
  return date <= t && date >= time.addDays(t, -days);
}

async function hourlySummary(userId, date) {
  const ups = await db.many('SELECT * FROM hourly_updates WHERE user_id=$1 AND work_date=$2 ORDER BY slot_min', [userId, date]);
  const totals = {};
  for (const u of ups) for (const [k, v] of Object.entries(u.data || {})) if (typeof v === 'number') totals[k] = (totals[k] || 0) + v;
  return { updates: ups.map((u) => ({ ...u, slotLabel: time.fmtMin(u.slot_min) })), totals };
}

async function entryFor(userId, date) {
  return db.one('SELECT * FROM dsr_entries WHERE user_id=$1 AND work_date=$2', [userId, date]);
}

function changedLabels(template, before, after) {
  const out = [];
  for (const s of template.sections) for (const f of s.fields) {
    if (String((before || {})[f.key] ?? '') !== String(after[f.key] ?? '')) out.push(`${f.label}${f.type === 'number' && after[f.key] !== undefined ? ' = ' + after[f.key] : ''}`);
  }
  return out;
}

// Employee: own DSR for a date (default today)
dsr.get('/mine', async (req, res) => {
  if (!['cso', 'hre'].includes(req.user.role)) throw new HttpError(400, 'Admins do not fill a DSR');
  const date = time.isDate(req.query.date) ? req.query.date : time.today();
  const entry = await entryFor(req.user.id, date);
  const template = entry && entry.template_id
    ? await db.one('SELECT * FROM form_templates WHERE id=$1', [entry.template_id]) : await activeTemplate(req.user.role);
  res.json({ date, today: time.today(), entry, template, editable: await canEditDate(req, date), hourly: await hourlySummary(req.user.id, date) });
});

// Records entry ("check-in") time the first time today's DSR is opened.
dsr.post('/mine/check-in', async (req, res) => {
  if (!['cso', 'hre'].includes(req.user.role)) return res.json({ ok: true });
  const date = time.today();
  const tpl = await activeTemplate(req.user.role);
  const r = await db.query(
    `INSERT INTO dsr_entries(user_id, work_date, role, template_id, check_in_at, updated_by) VALUES ($1,$2,$3,$4,now(),$1)
     ON CONFLICT (user_id, work_date) DO NOTHING RETURNING *`, [req.user.id, date, req.user.role, tpl.id]);
  if (r.rowCount) {
    await audit(req, 'check_in', 'dsr', r.rows[0].id, `Started DSR for ${date}`);
    rt.activity(req.user, `checked in at ${time.fmtMin(time.nowParts().minutes)}`);
    rt.emitAdmins('dsr', { userId: req.user.id, date });
  }
  res.json(r.rows[0] || (await entryFor(req.user.id, date)));
});

async function saveEntry(req, userId, role, date, body, submit) {
  const existing = await entryFor(userId, date);
  const template = existing && existing.template_id
    ? await db.one('SELECT * FROM form_templates WHERE id=$1', [existing.template_id]) : await activeTemplate(role);
  const data = sanitize(template, body.data || {});
  if (submit) {
    for (const s of template.sections) for (const f of s.fields) {
      if (f.required && (data[f.key] === undefined || data[f.key] === '')) throw new HttpError(400, `Fill “${f.label}” before submitting`);
    }
  }
  const remarks = body.remarks !== undefined ? String(body.remarks || '').slice(0, 4000) : (existing ? existing.remarks : null);
  const status = submit ? 'submitted' : (existing ? existing.status : 'draft');
  const row = await db.one(
    `INSERT INTO dsr_entries(user_id, work_date, role, template_id, data, remarks, status, check_in_at, check_out_at, updated_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7, CASE WHEN $2::date = $9::date THEN now() END, CASE WHEN $8 THEN now() END, $10)
     ON CONFLICT (user_id, work_date) DO UPDATE SET data=EXCLUDED.data, remarks=EXCLUDED.remarks, status=EXCLUDED.status,
       check_out_at = CASE WHEN $8 THEN now() ELSE dsr_entries.check_out_at END,
       updated_at=now(), updated_by=EXCLUDED.updated_by
     RETURNING *`,
    [userId, date, role, template.id, JSON.stringify(data), remarks, status, !!submit, time.today(), req.user.id]);
  const changes = changedLabels(template, existing && existing.data, data);
  await audit(req, submit ? 'dsr_submitted' : 'dsr_saved', 'dsr', row.id,
    `${submit ? 'Submitted' : 'Saved'} DSR ${date}${userId !== req.user.id ? ' (edited by admin)' : ''}${changes.length ? ': ' + changes.slice(0, 6).join(', ') : ''}`,
    existing ? { data: existing.data, status: existing.status } : null, { data, status });
  const who = userId === req.user.id ? req.user : await db.one('SELECT id, full_name, role FROM users WHERE id=$1', [userId]);
  if (submit) rt.activity(who, `submitted DSR for ${date}`, { level: 'ok' });
  else if (changes.length) rt.activity(who, `updated ${changes.slice(0, 3).join(', ')}`);
  rt.emitAdmins('dsr', { userId, date });
  if (userId !== req.user.id) rt.emitUser(userId, 'dsr', { date });
  return row;
}

dsr.put('/mine', async (req, res) => {
  const date = time.isDate(req.query.date) ? req.query.date : time.today();
  if (!(await canEditDate(req, date))) throw new HttpError(403, 'This day is locked. Ask your admin to change it.');
  res.json(await saveEntry(req, req.user.id, req.user.role, date, req.body || {}, false));
});

dsr.post('/mine/submit', async (req, res) => {
  const date = time.isDate(req.query.date) ? req.query.date : time.today();
  if (!(await canEditDate(req, date))) throw new HttpError(403, 'This day is locked. Ask your admin to change it.');
  res.json(await saveEntry(req, req.user.id, req.user.role, date, req.body || {}, true));
});

// Admin: list entries for a date / range, including who has not started.
dsr.get('/', requireAdmin, async (req, res) => {
  const from = time.isDate(req.query.from) ? req.query.from : (time.isDate(req.query.date) ? req.query.date : time.today());
  const to = time.isDate(req.query.to) ? req.query.to : from;
  const params = [from, to];
  let extra = '';
  if (req.query.role) { params.push(req.query.role); extra += ` AND u.role=$${params.length}`; }
  if (req.query.user_id) { params.push(parseInt(req.query.user_id, 10)); extra += ` AND u.id=$${params.length}`; }
  const rows = await db.many(
    `SELECT d.id, d.work_date, d.status, d.check_in_at, d.check_out_at, d.updated_at, d.data, d.remarks,
            u.id AS user_id, u.full_name, u.emp_code, u.role
     FROM dsr_entries d JOIN users u ON u.id=d.user_id
     WHERE d.work_date BETWEEN $1 AND $2 ${extra} ORDER BY d.work_date DESC, u.full_name`, params);
  let missing = [];
  if (from === to) {
    const p2 = [from]; let ex2 = '';
    if (req.query.role) { p2.push(req.query.role); ex2 += ` AND u.role=$${p2.length}`; }
    missing = await db.many(
      `SELECT u.id AS user_id, u.full_name, u.emp_code, u.role FROM users u
       WHERE u.is_active AND u.role IN ('cso','hre') ${ex2}
       AND NOT EXISTS (SELECT 1 FROM dsr_entries d WHERE d.user_id=u.id AND d.work_date=$1) ORDER BY u.full_name`, p2);
  }
  res.json({ rows, missing });
});

// Admin: one employee's DSR for a date (view / edit any entry)
dsr.get('/user/:uid/:date', requireAdmin, async (req, res) => {
  const uid = parseInt(req.params.uid, 10);
  const date = req.params.date;
  if (!time.isDate(date)) throw new HttpError(400, 'Bad date');
  const user = await db.one('SELECT id, full_name, emp_code, role FROM users WHERE id=$1', [uid]);
  if (!user) throw new HttpError(404, 'Employee not found');
  const entry = await entryFor(uid, date);
  const role = entry ? entry.role : user.role;
  const template = entry && entry.template_id
    ? await db.one('SELECT * FROM form_templates WHERE id=$1', [entry.template_id])
    : (['cso', 'hre'].includes(role) ? await activeTemplate(role) : null);
  res.json({ user, date, entry, template, editable: true, hourly: await hourlySummary(uid, date) });
});

dsr.put('/user/:uid/:date', requireAdmin, async (req, res) => {
  const uid = parseInt(req.params.uid, 10);
  const date = req.params.date;
  if (!time.isDate(date)) throw new HttpError(400, 'Bad date');
  const user = await db.one('SELECT id, role FROM users WHERE id=$1', [uid]);
  if (!user || !['cso', 'hre'].includes(user.role)) throw new HttpError(404, 'Employee not found');
  const existing = await entryFor(uid, date);
  res.json(await saveEntry(req, uid, existing ? existing.role : user.role, date, req.body || {}, !!(req.body && req.body.submit)));
});

// ---------- hourly updates ----------
const hourly = express.Router();

async function boardFor(userId, date) {
  const s = await sched.getSchedule(userId);
  const active = s && sched.isActiveOn(s, date);
  const ups = await db.many('SELECT * FROM hourly_updates WHERE user_id=$1 AND work_date=$2 ORDER BY slot_min', [userId, date]);
  return { schedule: s, active: !!active, board: active ? sched.slotBoard(s, date, ups) : [], updates: ups,
    released: !!(s && s.released_at) };
}

hourly.get('/mine', async (req, res) => {
  const date = time.isDate(req.query.date) ? req.query.date : time.today();
  const b = await boardFor(req.user.id, date);
  const template = ['cso', 'hre'].includes(req.user.role) ? await activeTemplate(req.user.role) : null;
  res.json({ date, today: time.today(), nowMin: time.nowParts().minutes, ...b, template });
});

hourly.post('/mine', async (req, res) => {
  const date = time.today();
  const { slot, activity, data, remarks } = req.body || {};
  const b = await boardFor(req.user.id, date);
  if (!b.active) throw new HttpError(400, 'You have no hourly schedule today');
  const cell = b.board.find((x) => x.slot === parseInt(slot, 10));
  if (!cell) throw new HttpError(400, 'That time slot is not in your schedule');
  if (cell.status === 'break') throw new HttpError(400, 'No update is needed during the break');
  if (cell.status === 'skipped') throw new HttpError(400, 'This slot was before your schedule started');
  if (cell.status === 'upcoming') throw new HttpError(400, `This slot opens at ${cell.fromLabel}`);
  const clean = {};
  for (const [k, v] of Object.entries(data || {})) {
    if (!/^[a-z0-9_]{1,60}$/.test(k)) continue;
    if (v === '' || v === null || v === undefined) continue;
    const n = Number(v);
    clean[k] = typeof v === 'number' || (/^-?\d+(\.\d+)?$/.test(String(v)) && isFinite(n)) ? n : String(v).slice(0, 2000);
  }
  const now = time.nowParts().minutes;
  const late = now > cell.slot + b.schedule.grace_min;
  const row = await db.one(
    `INSERT INTO hourly_updates(user_id, work_date, slot_min, activity, data, remarks, is_late) VALUES ($1,$2,$3,$4,$5,$6,$7)
     ON CONFLICT (user_id, work_date, slot_min) DO UPDATE SET activity=EXCLUDED.activity, data=EXCLUDED.data, remarks=EXCLUDED.remarks,
       submitted_at=now()
     RETURNING *`,
    [req.user.id, date, cell.slot, String(activity || '').slice(0, 80), JSON.stringify(clean), String(remarks || '').slice(0, 2000) || null, late]);
  await audit(req, 'hourly_submitted', 'hourly', row.id, `Hourly update for ${cell.label}${late ? ' (late)' : ''}: ${activity || ''}`);
  rt.activity(req.user, `submitted ${cell.label} hourly update${late ? ' (late)' : ''}`, { level: late ? 'warn' : 'ok' });
  rt.emitAdmins('hourly', { userId: req.user.id, date, slot: cell.slot, status: late ? 'late' : 'done' });
  res.json(row);
});

hourly.get('/user/:uid', requireAdmin, async (req, res) => {
  const date = time.isDate(req.query.date) ? req.query.date : time.today();
  res.json({ date, ...(await boardFor(parseInt(req.params.uid, 10), date)) });
});

module.exports = { forms, dsr, hourly, activeTemplate };
