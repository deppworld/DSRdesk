// Employee management (Super Admin only): profiles, role switch, hourly schedules, sessions.
const express = require('express');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const db = require('../db/pool');
const { requireAdmin, HttpError } = require('../middleware/auth');
const { audit, notify } = require('../services/notify');
const rt = require('../services/realtime');
const time = require('../services/time');
const sched = require('../services/schedule');

const router = express.Router();
router.use(requireAdmin);

const ROLES = ['super_admin', 'cso', 'hre'];
const USER_COLS = `id, emp_code, full_name, username, email, mobile, role, branch, reports_to, joining_date,
  must_change_password, is_active, locked_until, last_login_at, last_login_ip, created_at`;

function tempPassword() {
  return 'Dsr' + crypto.randomBytes(4).toString('hex') + '#' + Math.floor(Math.random() * 90 + 10);
}

const clean = (v, max = 200) => (v === undefined || v === null ? null : String(v).trim().slice(0, max) || null);

function scheduleInput(b, existing = {}) {
  const s = { ...{ enabled: true, start_min: 600, end_min: 1110, interval_min: 60, grace_min: 10, days: [1, 2, 3, 4, 5, 6],
    break_start_min: 810, break_end_min: 840, until_date: null, remind_before: true, alert_admin: true }, ...existing };
  const num = (v, d) => (v === undefined || v === null || v === '' ? d : parseInt(v, 10));
  if (b.start !== undefined) s.start_min = time.parseHHMM(b.start);
  if (b.end !== undefined) s.end_min = time.parseHHMM(b.end);
  if (b.interval_min !== undefined) s.interval_min = num(b.interval_min, 60);
  if (b.grace_min !== undefined) s.grace_min = num(b.grace_min, 10);
  if (Array.isArray(b.days)) s.days = b.days.map((d) => parseInt(d, 10)).filter((d) => d >= 0 && d <= 6);
  if (b.break_start !== undefined) s.break_start_min = b.break_start ? time.parseHHMM(b.break_start) : null;
  if (b.break_end !== undefined) s.break_end_min = b.break_end ? time.parseHHMM(b.break_end) : null;
  if (b.until_date !== undefined) s.until_date = b.until_date && time.isDate(b.until_date) ? b.until_date : null;
  if (b.remind_before !== undefined) s.remind_before = !!b.remind_before;
  if (b.alert_admin !== undefined) s.alert_admin = !!b.alert_admin;
  if (b.enabled !== undefined) s.enabled = !!b.enabled;
  if (s.start_min === null || s.end_min === null) throw new HttpError(400, 'Enter valid start and end times (HH:MM)');
  if (s.end_min <= s.start_min) throw new HttpError(400, 'End time must be after start time');
  if (![15, 30, 45, 60, 90, 120, 180].includes(s.interval_min)) throw new HttpError(400, 'Interval must be 15, 30, 45, 60, 90, 120 or 180 minutes');
  if (s.grace_min < 0 || s.grace_min > 60) throw new HttpError(400, 'Grace period must be 0–60 minutes');
  if (!s.days.length) throw new HttpError(400, 'Pick at least one working day');
  if ((s.break_start_min === null) !== (s.break_end_min === null) ||
      (s.break_start_min !== null && s.break_end_min <= s.break_start_min)) throw new HttpError(400, 'Break end must be after break start');
  return s;
}

async function saveSchedule(userId, s, adminId) {
  return db.one(
    `INSERT INTO hourly_schedules(user_id, enabled, start_min, end_min, interval_min, grace_min, days, break_start_min, break_end_min,
       until_date, remind_before, alert_admin, released_at, released_by, updated_by, updated_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,NULL,NULL,$13,now())
     ON CONFLICT (user_id) DO UPDATE SET enabled=EXCLUDED.enabled, start_min=EXCLUDED.start_min, end_min=EXCLUDED.end_min,
       interval_min=EXCLUDED.interval_min, grace_min=EXCLUDED.grace_min, days=EXCLUDED.days, break_start_min=EXCLUDED.break_start_min,
       break_end_min=EXCLUDED.break_end_min, until_date=EXCLUDED.until_date, remind_before=EXCLUDED.remind_before,
       alert_admin=EXCLUDED.alert_admin, updated_by=EXCLUDED.updated_by, updated_at=now()
     RETURNING *`,
    [userId, s.enabled, s.start_min, s.end_min, s.interval_min, s.grace_min, s.days, s.break_start_min, s.break_end_min,
      s.until_date, s.remind_before, s.alert_admin, adminId]);
}

router.get('/', async (req, res) => {
  const d = time.today();
  const rows = await db.many(
    `SELECT ${USER_COLS.split(',').map((c) => 'u.' + c.trim()).join(', ')},
       s.enabled AS sched_enabled, s.released_at AS sched_released_at, s.start_min, s.end_min, s.interval_min, s.until_date,
       d.status AS dsr_status, d.check_in_at,
       (SELECT max(created_at) FROM audit_logs a WHERE a.user_id=u.id) AS last_activity
     FROM users u
     LEFT JOIN hourly_schedules s ON s.user_id=u.id
     LEFT JOIN dsr_entries d ON d.user_id=u.id AND d.work_date=$1
     ORDER BY u.is_active DESC, u.role, u.full_name`, [d]);
  const online = new Set(rt.onlineUserIds());
  res.json(rows.map((r) => ({ ...r, online: online.has(r.id),
    hourly: r.sched_enabled && !r.sched_released_at ? `${time.fmtMin(r.start_min)} – ${time.fmtMin(r.end_min)} · ${r.interval_min}m` : null })));
});

router.get('/:id', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const u = await db.one(`SELECT ${USER_COLS} FROM users WHERE id=$1`, [id]);
  if (!u) throw new HttpError(404, 'Employee not found');
  const schedule = await sched.getSchedule(id);
  const roles = await db.many(
    `SELECT r.*, a.full_name AS changed_by_name FROM role_changes r LEFT JOIN users a ON a.id=r.changed_by
     WHERE r.user_id=$1 ORDER BY r.created_at DESC`, [id]);
  const sessions = await db.many(
    `SELECT id, ip, user_agent, created_at, last_used_at, expires_at FROM refresh_tokens
     WHERE user_id=$1 AND revoked_at IS NULL AND expires_at > now() ORDER BY created_at DESC`, [id]);
  const history = await db.many(
    `SELECT a.created_at, a.action, a.summary, a.ip, x.full_name AS by_name FROM audit_logs a LEFT JOIN users x ON x.id=a.user_id
     WHERE (a.entity='user' AND a.entity_id=$1) OR (a.entity='schedule' AND a.entity_id=$1)
     ORDER BY a.created_at DESC LIMIT 40`, [String(id)]);
  let board = null;
  const d = time.today();
  if (schedule && sched.isActiveOn(schedule, d)) {
    const ups = await db.many('SELECT * FROM hourly_updates WHERE user_id=$1 AND work_date=$2', [id, d]);
    board = sched.slotBoard(schedule, d, ups);
  }
  res.json({ user: u, schedule, slots: schedule ? sched.buildSlots(schedule).map((s) => ({ ...s, label: time.fmtMin(s.slot) })) : [],
    board, roleChanges: roles, sessions, history, online: rt.onlineUserIds().includes(id) });
});

router.post('/', async (req, res) => {
  const b = req.body || {};
  const full_name = clean(b.full_name, 120);
  if (!full_name) throw new HttpError(400, 'Full name is required');
  if (!ROLES.includes(b.role)) throw new HttpError(400, 'Pick a role');
  let username = clean(b.username, 60);
  if (!username) username = full_name.toLowerCase().replace(/[^a-z0-9]+/g, '.').replace(/^\.|\.$/g, '');
  if (!/^[a-zA-Z0-9._-]{3,60}$/.test(username)) throw new HttpError(400, 'Username: 3–60 letters, numbers, dot, dash or underscore');
  if (await db.one('SELECT 1 FROM users WHERE lower(username)=lower($1)', [username])) throw new HttpError(409, `Username "${username}" is taken`);
  let emp_code = clean(b.emp_code, 30);
  if (!emp_code) {
    const n = await db.one("SELECT COALESCE(max(substring(emp_code from '[0-9]+')::int),0)+1 AS n FROM users WHERE emp_code ~ '^EMP-[0-9]+$'");
    emp_code = 'EMP-' + String(n.n).padStart(3, '0');
  }
  if (await db.one('SELECT 1 FROM users WHERE lower(emp_code)=lower($1)', [emp_code])) throw new HttpError(409, `Employee ID ${emp_code} already exists`);
  const password = tempPassword();
  const hash = await bcrypt.hash(password, 12);
  const u = await db.tx(async (c) => {
    const r = await c.query(
      `INSERT INTO users(emp_code, full_name, username, email, mobile, role, branch, reports_to, joining_date, password_hash, must_change_password)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,TRUE) RETURNING ${USER_COLS}`,
      [emp_code, full_name, username, clean(b.email), clean(b.mobile, 30), b.role, clean(b.branch, 80),
        b.reports_to ? parseInt(b.reports_to, 10) : null, time.isDate(b.joining_date) ? b.joining_date : time.today(), hash]);
    await c.query('INSERT INTO role_changes(user_id, old_role, new_role, effective_from, reason, changed_by) VALUES ($1,NULL,$2,$3,$4,$5)',
      [r.rows[0].id, b.role, time.today(), 'Profile created', req.user.id]);
    return r.rows[0];
  });
  let schedule = null;
  if (b.hourly && b.hourly.enabled && u.role !== 'super_admin') {
    schedule = await saveSchedule(u.id, scheduleInput(b.hourly), req.user.id);
  }
  await audit(req, 'user_created', 'user', u.id, `Created ${u.full_name} (${u.role.toUpperCase()})${schedule ? ' on hourly schedule' : ''}`, null, u);
  rt.activity(req.user, `created employee ${u.full_name}`);
  res.status(201).json({ user: u, tempPassword: password, schedule });
});

router.patch('/:id', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const before = await db.one(`SELECT ${USER_COLS} FROM users WHERE id=$1`, [id]);
  if (!before) throw new HttpError(404, 'Employee not found');
  const b = req.body || {};
  const f = {
    full_name: b.full_name !== undefined ? clean(b.full_name, 120) : before.full_name,
    email: b.email !== undefined ? clean(b.email) : before.email,
    mobile: b.mobile !== undefined ? clean(b.mobile, 30) : before.mobile,
    branch: b.branch !== undefined ? clean(b.branch, 80) : before.branch,
    joining_date: b.joining_date !== undefined && time.isDate(b.joining_date) ? b.joining_date : before.joining_date
  };
  if (!f.full_name) throw new HttpError(400, 'Full name is required');
  const u = await db.one(
    `UPDATE users SET full_name=$2, email=$3, mobile=$4, branch=$5, joining_date=$6, updated_at=now() WHERE id=$1 RETURNING ${USER_COLS}`,
    [id, f.full_name, f.email, f.mobile, f.branch, f.joining_date]);
  await audit(req, 'user_updated', 'user', id, `Updated profile of ${u.full_name}`, before, u);
  res.json(u);
});

async function endSessions(id) {
  await db.query('UPDATE users SET token_version=token_version+1 WHERE id=$1', [id]);
  await db.query('UPDATE refresh_tokens SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL', [id]);
  await rt.disconnectUser(id);
}

router.post('/:id/status', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (id === req.user.id) throw new HttpError(400, 'You cannot disable your own account');
  const active = !!(req.body && req.body.active);
  const u = await db.one(`UPDATE users SET is_active=$2, updated_at=now() WHERE id=$1 RETURNING ${USER_COLS}`, [id, active]);
  if (!u) throw new HttpError(404, 'Employee not found');
  if (!active) await endSessions(id);
  await audit(req, active ? 'user_enabled' : 'user_disabled', 'user', id, `${active ? 'Enabled' : 'Disabled'} ${u.full_name}`);
  res.json(u);
});

router.post('/:id/reset-password', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const password = tempPassword();
  const u = await db.one(
    `UPDATE users SET password_hash=$2, must_change_password=TRUE, failed_attempts=0, locked_until=NULL, updated_at=now()
     WHERE id=$1 RETURNING id, full_name`, [id, await bcrypt.hash(password, 12)]);
  if (!u) throw new HttpError(404, 'Employee not found');
  await endSessions(id);
  await audit(req, 'password_reset', 'user', id, `Reset password of ${u.full_name}`);
  res.json({ tempPassword: password });
});

router.post('/:id/unlock', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  await db.query('UPDATE users SET failed_attempts=0, locked_until=NULL WHERE id=$1', [id]);
  await audit(req, 'user_unlocked', 'user', id, 'Unlocked account');
  res.json({ ok: true });
});

router.post('/:id/sign-out', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  await endSessions(id);
  await audit(req, 'force_sign_out', 'user', id, 'Signed out of all devices by admin');
  res.json({ ok: true });
});

router.post('/:id/role', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const { role, reason, effective_from } = req.body || {};
  if (!ROLES.includes(role)) throw new HttpError(400, 'Pick a valid role');
  if (id === req.user.id && role !== 'super_admin') throw new HttpError(400, 'You cannot remove your own admin role');
  const before = await db.one('SELECT id, full_name, role FROM users WHERE id=$1', [id]);
  if (!before) throw new HttpError(404, 'Employee not found');
  if (before.role === role) throw new HttpError(400, `Already ${role.toUpperCase()}`);
  await db.tx(async (c) => {
    await c.query('UPDATE users SET role=$2, updated_at=now() WHERE id=$1', [id, role]);
    await c.query('INSERT INTO role_changes(user_id, old_role, new_role, effective_from, reason, changed_by) VALUES ($1,$2,$3,$4,$5,$6)',
      [id, before.role, role, time.isDate(effective_from) ? effective_from : time.today(), clean(reason, 300), req.user.id]);
  });
  await endSessions(id); // they sign in again and get the new role's screens
  await audit(req, 'role_changed', 'user', id, `Role ${before.role.toUpperCase()} → ${role.toUpperCase()}${reason ? ': ' + reason : ''}`, { role: before.role }, { role });
  rt.activity(req.user, `changed ${before.full_name}'s role to ${role.toUpperCase()}`);
  res.json({ ok: true });
});

router.put('/:id/schedule', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const u = await db.one('SELECT id, full_name, role FROM users WHERE id=$1', [id]);
  if (!u) throw new HttpError(404, 'Employee not found');
  if (u.role === 'super_admin') throw new HttpError(400, 'Admins do not have hourly schedules');
  const existing = await sched.getSchedule(id);
  const s = await saveSchedule(id, scheduleInput(req.body || {}, existing || {}), req.user.id);
  await audit(req, 'schedule_saved', 'schedule', id,
    `Hourly schedule ${time.fmtMin(s.start_min)}–${time.fmtMin(s.end_min)} every ${s.interval_min} min`, existing, s);
  await notify(id, 'schedule', 'Your hourly update schedule was updated',
    `${time.fmtMin(s.start_min)} – ${time.fmtMin(s.end_min)}, every ${s.interval_min} minutes`, '#/hourly');
  rt.emitUser(id, 'schedule', {});
  res.json(s);
});

router.post('/:id/schedule/release', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const s = await db.one('UPDATE hourly_schedules SET released_at=now(), released_by=$2 WHERE user_id=$1 RETURNING *', [id, req.user.id]);
  if (!s) throw new HttpError(404, 'No schedule for this employee');
  await audit(req, 'schedule_released', 'schedule', id, 'Released from hourly updates');
  await notify(id, 'schedule', 'You are released from hourly updates', 'Continue with the standard daily DSR.', '#/my-dsr');
  rt.emitUser(id, 'schedule', {});
  res.json(s);
});

router.post('/:id/schedule/reapply', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const s = await db.one('UPDATE hourly_schedules SET released_at=NULL, released_by=NULL, enabled=TRUE WHERE user_id=$1 RETURNING *', [id]);
  if (!s) throw new HttpError(404, 'No schedule for this employee – save one first');
  await audit(req, 'schedule_reapplied', 'schedule', id, 'Put back on hourly updates');
  await notify(id, 'schedule', 'Hourly updates are on again', `${time.fmtMin(s.start_min)} – ${time.fmtMin(s.end_min)}`, '#/hourly');
  rt.emitUser(id, 'schedule', {});
  res.json(s);
});

module.exports = router;
