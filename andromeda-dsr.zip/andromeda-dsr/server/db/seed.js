// First-run data: settings, the CSO/HRE DSR forms (taken from the Excel sheets) and the owner account.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const db = require('./pool');
const config = require('../config');

const DEFAULT_SETTINGS = {
  company_name: 'Andromeda',
  loan_statuses: ['1 - Lead', '2 - Docs Pending', '3 - Login Done', '4 - Under Process', '5 - Sanctioned', '6 - Disbursed', 'On Hold', '0 - Rejected'],
  loan_status_groups: { approved: ['5 - Sanctioned', '6 - Disbursed'], rejected: ['0 - Rejected'], converted: ['6 - Disbursed'] },
  products: ['PL', 'BL', 'HL', 'LAP', 'LAP BT Top Up', 'AL', 'MI', 'Insurance', 'MF', 'Cards'],
  contact_statuses: ['Call Not Answered/Reachable', 'Not Interested', 'Call Again Later', 'FollowUp - General', 'FollowUp - Interested', 'Switched Off', 'Wrong number', 'Number Does Not Exist', 'Documents Collected', 'After Converted NI'],
  dsa_statuses: ['Onboard Successful', 'E-Signing Pending', 'Under KYC Verification', 'Code Under process', 'Active', 'Not Active', 'Not working', 'Busy', 'CNR', '0 Billing'],
  dsa_profiles: ['DSA', 'Loan Advisor', 'Banker', 'Connector'],
  dsr_due_time: '19:00',
  dsr_edit_days: 0
};

// metric = which dashboard total a number field adds to.
const CSO_FORM = [
  { key: 'dsa_connect', title: 'DSA Connect', time: '', fields: [
    { key: 'dsa_connect_count', label: 'DSA connected', type: 'number', metric: 'connects' },
    { key: 'dsa_connect_names', label: 'DSA names', type: 'textarea' } ] },
  { key: 'new_dsa_calling', title: 'New DSA Calling', time: '', fields: [
    { key: 'ndc_calls', label: 'Calls', type: 'number', metric: 'calls' },
    { key: 'ndc_interested', label: 'Interested', type: 'number', metric: 'interested' },
    { key: 'ndc_kits', label: 'DSA kits', type: 'number', metric: 'kits' },
    { key: 'ndc_names', label: 'Interested names', type: 'textarea' } ] },
  { key: 'files_login', title: 'Files Login', time: '', fields: [
    { key: 'files_login_count', label: 'Files logged in', type: 'number', metric: 'files_login' },
    { key: 'files_login_details', label: 'Customer / product / amount', type: 'textarea' } ] },
  { key: 'new_loan_calling', title: 'New Loan Calling', time: '', fields: [
    { key: 'nlc_calls', label: 'Calls', type: 'number', metric: 'calls' },
    { key: 'nlc_leads', label: 'Leads (name / bank)', type: 'textarea' } ] },
  { key: 'dsa_meeting', title: 'DSA Meeting', time: '', fields: [
    { key: 'meeting_count', label: 'Meetings', type: 'number', metric: 'meetings' },
    { key: 'meeting_names', label: 'Met with', type: 'textarea' } ] },
  { key: 'day_close', title: 'Report Making & Day Close', time: '', fields: [
    { key: 'lunch', label: 'Lunch', type: 'text', placeholder: '01:30 - 02:00' },
    { key: 'day_remarks', label: 'Remarks', type: 'textarea' } ] }
];

const HRE_FORM = [
  { key: 'data_mining', title: 'Data Mining', time: '10:00 AM - 01:30 PM', fields: [
    { key: 'mined_count', label: 'Contacts mined', type: 'number', metric: 'mined' },
    { key: 'banker_directory', label: 'Banker directory total', type: 'number' } ] },
  { key: 'lunch', title: 'Lunch', time: '01:30 PM - 02:00 PM', fields: [
    { key: 'lunch', label: 'Lunch time', type: 'text', placeholder: '01:32 - 02:00' } ] },
  { key: 'dsa_registration', title: 'DSA Registration', time: '02:00 PM - 02:30 PM', fields: [
    { key: 'reg_count', label: 'Registrations', type: 'number', metric: 'registrations' },
    { key: 'reg_names', label: 'Name / city', type: 'textarea' } ] },
  { key: 'new_dsa_calling', title: 'New DSA Calling', time: '02:30 PM - 06:30 PM', fields: [
    { key: 'feedback_calls', label: 'Feedback calls', type: 'number', metric: 'calls' },
    { key: 'converted', label: 'Converted', type: 'number', metric: 'converted' },
    { key: 'converted_names', label: 'Converted name / city', type: 'textarea' } ] },
  { key: 'report_making', title: 'Report Making', time: '06:30 PM - 06:35 PM', fields: [
    { key: 'day_remarks', label: 'Remarks', type: 'textarea' } ] }
];

async function seed() {
  for (const [k, v] of Object.entries(DEFAULT_SETTINGS)) {
    await db.query('INSERT INTO settings(key, value) VALUES ($1, $2) ON CONFLICT (key) DO NOTHING', [k, JSON.stringify(v)]);
  }
  const t = await db.one('SELECT count(*)::int AS n FROM form_templates');
  if (t.n === 0) {
    await db.query('INSERT INTO form_templates(role, version, name, sections) VALUES ($1,1,$2,$3)', ['cso', 'CSO Daily DSR', JSON.stringify(CSO_FORM)]);
    await db.query('INSERT INTO form_templates(role, version, name, sections) VALUES ($1,1,$2,$3)', ['hre', 'HRE Daily DSR', JSON.stringify(HRE_FORM)]);
    console.log('[db] Seeded CSO and HRE DSR forms');
  }
  const u = await db.one('SELECT count(*)::int AS n FROM users');
  if (u.n === 0) {
    const password = crypto.randomBytes(6).toString('base64').replace(/[^a-zA-Z0-9]/g, 'x') + '#9';
    const hash = await bcrypt.hash(password, 12);
    await db.query(
      `INSERT INTO users(emp_code, full_name, username, role, password_hash, must_change_password)
       VALUES ('EMP-001', 'Owner', 'admin', 'super_admin', $1, TRUE)`, [hash]);
    const file = path.join(config.root, 'data', 'FIRST_LOGIN.txt');
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, `First sign-in\nUsername: admin\nTemporary password: ${password}\nYou will be asked to set a new password. Delete this file afterwards.\n`);
    console.log('\n==============================================');
    console.log(' Owner account created');
    console.log(' Username: admin');
    console.log(' Temporary password:', password);
    console.log(' (also saved in data/FIRST_LOGIN.txt)');
    console.log('==============================================\n');
  }
}

module.exports = { seed, DEFAULT_SETTINGS };
