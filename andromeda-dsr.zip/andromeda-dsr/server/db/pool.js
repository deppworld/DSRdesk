// PostgreSQL connection. Uses DATABASE_URL when set; otherwise starts a bundled
// PostgreSQL server (embedded-postgres) that stores its files in ./data/pg.
const path = require('path');
const fs = require('fs');
const { Pool, types } = require('pg');
const config = require('../config');

// Return DATE columns as 'YYYY-MM-DD' strings and NUMERIC as numbers.
types.setTypeParser(1082, (v) => v);
types.setTypeParser(1700, (v) => (v === null ? null : parseFloat(v)));
types.setTypeParser(20, (v) => (v === null ? null : parseInt(v, 10)));

let pool = null;
let embedded = null;

async function startEmbedded() {
  const EmbeddedPostgres = require('embedded-postgres').default;
  const dataDir = path.join(config.root, 'data', 'pg');
  const isNew = !fs.existsSync(path.join(dataDir, 'PG_VERSION'));
  fs.mkdirSync(path.dirname(dataDir), { recursive: true });
  embedded = new EmbeddedPostgres({
    databaseDir: dataDir,
    user: 'dsr',
    password: config.embeddedPgPassword,
    port: config.embeddedPgPort,
    persistent: true,
    onLog: () => {},
    onError: (e) => { const s = String(e || '').trim(); if (s) console.error('[postgres]', s); }
  });
  if (isNew) {
    console.log('[db] First run: initialising built-in PostgreSQL in', dataDir);
    await embedded.initialise();
  }
  await embedded.start();
  if (isNew) {
    try { await embedded.createDatabase('dsr'); } catch (e) { if (!/already exists/.test(String(e))) throw e; }
  }
  return `postgres://dsr:${encodeURIComponent(config.embeddedPgPassword)}@127.0.0.1:${config.embeddedPgPort}/dsr`;
}

function embeddedUrl() {
  return `postgres://dsr:${encodeURIComponent(config.embeddedPgPassword)}@127.0.0.1:${config.embeddedPgPort}/dsr`;
}

// If the built-in database is already running (e.g. the app is open and you run "npm run backup"), reuse it.
async function embeddedAlreadyRunning() {
  const p = new Pool({ connectionString: embeddedUrl(), max: 1, connectionTimeoutMillis: 1500 });
  try { await p.query('SELECT 1'); return true; } catch { return false; } finally { await p.end().catch(() => {}); }
}

async function connect() {
  let url = config.databaseUrl;
  if (!url) url = (await embeddedAlreadyRunning()) ? embeddedUrl() : await startEmbedded();
  pool = new Pool({ connectionString: url, max: 20, idleTimeoutMillis: 30000 });
  pool.on('error', (e) => console.error('[db] idle client error', e.message));
  await pool.query('SELECT 1');
  console.log('[db] Connected to', config.databaseUrl ? 'external PostgreSQL' : 'built-in PostgreSQL');
  return pool;
}

async function close() {
  if (pool) await pool.end().catch(() => {});
  if (embedded) await embedded.stop().catch(() => {});
}

function query(text, params) { return pool.query(text, params); }

async function one(text, params) { const r = await pool.query(text, params); return r.rows[0] || null; }
async function many(text, params) { const r = await pool.query(text, params); return r.rows; }

async function tx(fn) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const out = await fn(client);
    await client.query('COMMIT');
    return out;
  } catch (e) {
    await client.query('ROLLBACK').catch(() => {});
    throw e;
  } finally {
    client.release();
  }
}

module.exports = { connect, close, query, one, many, tx, getPool: () => pool };
