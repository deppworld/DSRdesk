-- Andromeda DSR – initial schema

CREATE TABLE IF NOT EXISTS users (
  id              SERIAL PRIMARY KEY,
  emp_code        TEXT UNIQUE NOT NULL,
  full_name       TEXT NOT NULL,
  username        TEXT UNIQUE NOT NULL,
  email           TEXT,
  mobile          TEXT,
  role            TEXT NOT NULL CHECK (role IN ('super_admin','cso','hre')),
  branch          TEXT,
  reports_to      INT REFERENCES users(id),
  joining_date    DATE,
  password_hash   TEXT NOT NULL,
  must_change_password BOOLEAN NOT NULL DEFAULT TRUE,
  is_active       BOOLEAN NOT NULL DEFAULT TRUE,
  token_version   INT NOT NULL DEFAULT 0,
  failed_attempts INT NOT NULL DEFAULT 0,
  locked_until    TIMESTAMPTZ,
  last_login_at   TIMESTAMPTZ,
  last_login_ip   TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS role_changes (
  id             SERIAL PRIMARY KEY,
  user_id        INT NOT NULL REFERENCES users(id),
  old_role       TEXT,
  new_role       TEXT NOT NULL,
  effective_from DATE NOT NULL,
  reason         TEXT,
  changed_by     INT REFERENCES users(id),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS refresh_tokens (
  id          SERIAL PRIMARY KEY,
  user_id     INT NOT NULL REFERENCES users(id),
  token_hash  TEXT UNIQUE NOT NULL,
  ip          TEXT,
  user_agent  TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_used_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at  TIMESTAMPTZ NOT NULL,
  revoked_at  TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_refresh_user ON refresh_tokens(user_id);

CREATE TABLE IF NOT EXISTS hourly_schedules (
  user_id          INT PRIMARY KEY REFERENCES users(id),
  enabled          BOOLEAN NOT NULL DEFAULT TRUE,
  start_min        INT NOT NULL DEFAULT 600,
  end_min          INT NOT NULL DEFAULT 1110,
  interval_min     INT NOT NULL DEFAULT 60,
  grace_min        INT NOT NULL DEFAULT 10,
  days             INT[] NOT NULL DEFAULT '{1,2,3,4,5,6}',
  break_start_min  INT,
  break_end_min    INT,
  until_date       DATE,
  remind_before    BOOLEAN NOT NULL DEFAULT TRUE,
  alert_admin      BOOLEAN NOT NULL DEFAULT TRUE,
  released_at      TIMESTAMPTZ,
  released_by      INT REFERENCES users(id),
  updated_by       INT REFERENCES users(id),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS hourly_updates (
  id           SERIAL PRIMARY KEY,
  user_id      INT NOT NULL REFERENCES users(id),
  work_date    DATE NOT NULL,
  slot_min     INT NOT NULL,
  activity     TEXT,
  data         JSONB NOT NULL DEFAULT '{}',
  remarks      TEXT,
  is_late      BOOLEAN NOT NULL DEFAULT FALSE,
  submitted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, work_date, slot_min)
);

CREATE TABLE IF NOT EXISTS form_templates (
  id          SERIAL PRIMARY KEY,
  role        TEXT NOT NULL CHECK (role IN ('cso','hre')),
  version     INT NOT NULL,
  name        TEXT NOT NULL,
  sections    JSONB NOT NULL,
  is_active   BOOLEAN NOT NULL DEFAULT TRUE,
  created_by  INT REFERENCES users(id),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (role, version)
);

CREATE TABLE IF NOT EXISTS dsr_entries (
  id           SERIAL PRIMARY KEY,
  user_id      INT NOT NULL REFERENCES users(id),
  work_date    DATE NOT NULL,
  role         TEXT NOT NULL,
  template_id  INT REFERENCES form_templates(id),
  data         JSONB NOT NULL DEFAULT '{}',
  remarks      TEXT,
  status       TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','submitted')),
  check_in_at  TIMESTAMPTZ,
  check_out_at TIMESTAMPTZ,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by   INT REFERENCES users(id),
  UNIQUE (user_id, work_date)
);
CREATE INDEX IF NOT EXISTS idx_dsr_date ON dsr_entries(work_date);

CREATE TABLE IF NOT EXISTS loan_cases (
  id              SERIAL PRIMARY KEY,
  owner_id        INT NOT NULL REFERENCES users(id),
  case_date       DATE NOT NULL DEFAULT CURRENT_DATE,
  customer_name   TEXT NOT NULL,
  application_no  TEXT,
  company_name    TEXT,
  pan_enc         TEXT,
  pan_last4       TEXT,
  location        TEXT,
  email           TEXT,
  contact_no      TEXT,
  lead_by         TEXT,
  product         TEXT,
  loan_amount     NUMERIC(14,2),
  bank            TEXT,
  login_date      DATE,
  status          TEXT NOT NULL DEFAULT '1 - Lead',
  rejected_reason TEXT,
  last_update     TEXT,
  next_follow_up  DATE,
  banker          TEXT,
  payout          NUMERIC(14,2),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_loans_owner ON loan_cases(owner_id);
CREATE INDEX IF NOT EXISTS idx_loans_followup ON loan_cases(next_follow_up);

CREATE TABLE IF NOT EXISTS contacts (
  id             SERIAL PRIMARY KEY,
  owner_id       INT NOT NULL REFERENCES users(id),
  list_type      TEXT NOT NULL DEFAULT 'dsa_calling' CHECK (list_type IN ('dsa_calling','data_mining')),
  contact_date   DATE NOT NULL DEFAULT CURRENT_DATE,
  name           TEXT,
  mobile1        TEXT,
  mobile2        TEXT,
  designation    TEXT,
  company        TEXT,
  city           TEXT,
  state          TEXT,
  status         TEXT,
  remarks        TEXT,
  next_follow_up DATE,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_contacts_owner ON contacts(owner_id);

CREATE TABLE IF NOT EXISTS dsa_partners (
  id            SERIAL PRIMARY KEY,
  owner_id      INT NOT NULL REFERENCES users(id),
  onboard_date  DATE NOT NULL DEFAULT CURRENT_DATE,
  name          TEXT NOT NULL,
  birthday      DATE,
  andro_code    TEXT,
  dsa_code      TEXT,
  erp_code      TEXT,
  location      TEXT,
  mobile        TEXT,
  on_app        TEXT,
  profile       TEXT,
  status        TEXT,
  irda          TEXT,
  remarks       TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_dsa_owner ON dsa_partners(owner_id);

CREATE TABLE IF NOT EXISTS audit_logs (
  id          BIGSERIAL PRIMARY KEY,
  user_id     INT REFERENCES users(id),
  action      TEXT NOT NULL,
  entity      TEXT,
  entity_id   TEXT,
  summary     TEXT,
  ip          TEXT,
  user_agent  TEXT,
  before_data JSONB,
  after_data  JSONB,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_logs(user_id);

CREATE TABLE IF NOT EXISTS notifications (
  id         BIGSERIAL PRIMARY KEY,
  user_id    INT NOT NULL REFERENCES users(id),
  kind       TEXT NOT NULL,
  title      TEXT NOT NULL,
  body       TEXT,
  link       TEXT,
  is_read    BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(user_id, is_read);

CREATE TABLE IF NOT EXISTS sent_alerts (
  key        TEXT PRIMARY KEY,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value JSONB NOT NULL
);
