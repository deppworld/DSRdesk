-- When a schedule is first created, slots earlier that day are not counted as missed.
ALTER TABLE hourly_schedules ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ NOT NULL DEFAULT now();
