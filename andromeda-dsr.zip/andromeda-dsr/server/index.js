// Andromeda DSR – server entry point.
const path = require('path');
const fs = require('fs');
const http = require('http');
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const config = require('./config');
const db = require('./db/pool');
const { migrate } = require('./db/migrate');
const { seed } = require('./db/seed');
const { authenticate, HttpError } = require('./middleware/auth');
const realtime = require('./services/realtime');
const schedule = require('./services/schedule');

const app = express();
app.set('trust proxy', config.trustProxy);
app.disable('x-powered-by');

app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      'default-src': ["'self'"],
      'script-src': ["'self'"],
      'style-src': ["'self'", "'unsafe-inline'"],
      'img-src': ["'self'", 'data:', 'blob:'],
      'connect-src': ["'self'", 'ws:', 'wss:'],
      'font-src': ["'self'", 'data:'],
      'upgrade-insecure-requests': config.cookieSecure ? [] : null
    }
  },
  hsts: config.cookieSecure,
  crossOriginOpenerPolicy: config.cookieSecure ? undefined : false,
  originAgentCluster: false
}));
app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());

// --- front-end libraries served from node_modules (no CDN, works offline on a LAN) ---
const nm = (p) => path.join(config.root, 'node_modules', p);
const vendor = {
  'preact.mjs': () => fs.readFileSync(nm('preact/dist/preact.mjs'), 'utf8'),
  'hooks.mjs': () => fs.readFileSync(nm('preact/hooks/dist/hooks.mjs'), 'utf8').replace(/from\s*["']preact["']/g, 'from"/vendor/preact.mjs"'),
  'htm.mjs': () => fs.readFileSync(nm('htm/dist/htm.mjs'), 'utf8'),
  'chart.umd.js': () => fs.readFileSync(nm('chart.js/dist/chart.umd.js'), 'utf8')
};
const vendorCache = {};
app.get('/vendor/:file', (req, res, next) => {
  const f = req.params.file;
  if (!vendor[f]) return next();
  if (!vendorCache[f]) vendorCache[f] = vendor[f]();
  res.type(f.endsWith('.mjs') || f.endsWith('.js') ? 'application/javascript' : 'text/plain');
  res.set('Cache-Control', 'public, max-age=86400');
  res.send(vendorCache[f]);
});

app.use(express.static(path.join(config.root, 'public'), {
  index: false,
  setHeaders: (res, p) => { if (p.endsWith('.js') || p.endsWith('.css')) res.set('Cache-Control', 'no-cache'); }
}));

app.get('/api/health', async (req, res) => {
  await db.query('SELECT 1');
  res.json({ ok: true, time: new Date().toISOString() });
});

const auth = require('./routes/auth');
const users = require('./routes/users');
const { forms, dsr, hourly } = require('./routes/dsr');
const { loans, contacts, dsa } = require('./routes/resource');
const reports = require('./routes/reports');
const admin = require('./routes/admin');
const { requireAdmin } = require('./middleware/auth');

app.use('/api/auth', auth.router);
app.use('/api', authenticate);
app.use('/api/users', users);
app.use('/api/forms', forms);
app.use('/api/dsr', dsr);
app.use('/api/hourly', hourly);
app.use('/api/loans', loans);
app.use('/api/contacts', contacts);
app.use('/api/dsa', dsa);
app.use('/api/reports', requireAdmin, reports);
app.use('/api/dashboard', admin.dashboard);
app.use('/api/audit', admin.audit);
app.use('/api/notifications', admin.notifications);
app.use('/api/settings', admin.settings);
app.use('/api/backups', admin.backups);
app.get('/api/employees/basic', requireAdmin, async (req, res) => {
  res.json(await db.many("SELECT id, full_name, emp_code, role, is_active FROM users ORDER BY is_active DESC, full_name"));
});
app.use('/api', (req, res) => res.status(404).json({ error: 'Unknown API route' }));

// Single-page app: every other GET returns index.html
app.get(/^\/(?!api\/|socket\.io\/).*/, (req, res) => {
  res.set('Cache-Control', 'no-cache');
  res.sendFile(path.join(config.root, 'public', 'index.html'));
});

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (err instanceof HttpError) return res.status(err.status).json({ error: err.message });
  if (err && err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid request data' });
  if (err && err.code === '23505') return res.status(409).json({ error: 'That value already exists' });
  if (err && ['23514', '22P02', '22007', '22008', '23502', '22003', '22001'].includes(err.code)) {
    return res.status(400).json({ error: 'Some values are not valid: ' + (err.detail || err.message).slice(0, 160) });
  }
  console.error('[error]', req.method, req.originalUrl, err);
  res.status(500).json({ error: 'Something went wrong on the server. It has been logged.' });
});

async function main() {
  await db.connect();
  await migrate();
  await seed();
  const server = http.createServer(app);
  realtime.init(server);
  schedule.start();
  server.listen(config.port, config.host, () => {
    console.log(`\nAndromeda DSR is running:  http://localhost:${config.port}`);
    const nets = require('os').networkInterfaces();
    for (const list of Object.values(nets)) for (const n of list || []) {
      if (n.family === 'IPv4' && !n.internal) console.log(`  Other computers on your network: http://${n.address}:${config.port}`);
    }
    console.log(`  Business time zone: ${config.timezone}\n`);
  });
  server.on('error', (e) => {
    if (e.code === 'EADDRINUSE') console.error(`\n[error] Port ${config.port} is already in use. Close the other program or change PORT in .env\n`);
    else console.error('[error]', e);
    shutdown(1);
  });
  let closing = false;
  async function shutdown(code = 0) {
    if (closing) return; closing = true;
    console.log('\nShutting down…');
    schedule.stop();
    server.close();
    await db.close();
    process.exit(code);
  }
  process.on('SIGINT', () => shutdown(0));
  process.on('SIGTERM', () => shutdown(0));
}

main().catch(async (e) => {
  console.error('\n[startup failed]', e && e.message ? e.message : e);
  console.error('See the Troubleshooting guide, section "The server does not start".\n');
  await db.close();
  process.exit(1);
});
