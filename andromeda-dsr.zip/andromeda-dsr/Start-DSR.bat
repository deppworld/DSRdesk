@echo off
title Andromeda DSR server
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Node.js is not installed. Download the LTS version from https://nodejs.org and run this file again.
  echo.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Installing components for the first time. This needs internet and takes 1-3 minutes...
  call npm install --omit=dev
  if errorlevel 1 (
    echo.
    echo  Installation failed. See the Troubleshooting guide, "npm install fails".
    pause
    exit /b 1
  )
)
start "" cmd /c "timeout /t 8 >nul & start http://localhost:8080"
echo.
echo  Keep this window open while people use the DSR system. Close it (or press Ctrl+C) to stop.
echo.
node server\index.js
echo.
echo  The server stopped. Read the message above, then see the Troubleshooting guide.
pause
